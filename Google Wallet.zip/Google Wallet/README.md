# Google Wallet

Standalone Android app (Google Wallet only). App ID: `com.aistudio.liquidwallet.qxvnrp.googlewallet`.

## Build without a PC (GitHub)
1. Create a free GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab > **Build APK** > **Run workflow**.
3. When it finishes, open the run and download the **GoogleWallet-apk** artifact (a zip containing `app-debug.apk`).
4. Unzip it on your phone and install the APK.
