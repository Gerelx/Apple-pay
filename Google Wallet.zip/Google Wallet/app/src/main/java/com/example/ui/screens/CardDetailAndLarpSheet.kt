package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contactless
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.WalletCardEntity
import com.example.data.WalletTransactionEntity
import com.example.hardware.rememberDeviceTiltOffset
import com.example.ui.LarpPreferences
import com.example.ui.PaymentOutcome
import com.example.ui.WalletEcosystemTheme
import com.example.ui.components.ConfirmationIconType
import com.example.ui.components.GoogleBluePrimary
import com.example.ui.components.GoogleProfileAvatarButton
import com.example.ui.components.LiquidGlassButton
import com.example.ui.components.LiquidGlassSecondaryButton
import com.example.ui.components.ThemeAppIconBadge
import com.example.ui.components.WalletCardArtwork
import com.example.ui.components.liquidGlassSurface
import com.example.ui.components.liquidPressable
import com.example.ui.theme.IosPrimaryBlue
import com.example.ui.theme.MonoFontFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardDetailModalSheet(
    card: WalletCardEntity,
    transactions: List<WalletTransactionEntity>,
    darkTheme: Boolean = false,
    isGoogleWallet: Boolean = false,
    onReplacePhotoFromCameraRoll: () -> Unit,
    onEditCard: () -> Unit,
    onTriggerApplePayNow: () -> Unit,
    onRequestBiometricReveal: (onSuccess: () -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var isCardNumberRevealed by remember { mutableStateOf(false) }
    val deviceTilt by rememberDeviceTiltOffset()
    val accentBlue = if (isGoogleWallet) GoogleBluePrimary else IosPrimaryBlue

    val cardFlipRotationY by animateFloatAsState(
        targetValue = if (isCardNumberRevealed) 360f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "cardRevealSpinY"
    )
    val cardRevealScale by animateFloatAsState(
        targetValue = if (isCardNumberRevealed) 1.02f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "cardRevealScale"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = card.title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .liquidGlassSurface(
                                shape = CircleShape,
                                darkTheme = darkTheme,
                                elevation = 5.dp
                            )
                            .liquidPressable(pressScale = 0.86f, onClick = onEditCard)
                            .testTag("edit_card_from_detail_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Card",
                            tint = accentBlue,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .liquidGlassSurface(
                                shape = CircleShape,
                                darkTheme = darkTheme,
                                elevation = 5.dp
                            )
                            .liquidPressable(pressScale = 0.86f, onClick = onDismiss),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        scaleX = cardRevealScale
                        scaleY = cardRevealScale
                        rotationY = cardFlipRotationY - (deviceTilt.x * 4.5f)
                        rotationX = deviceTilt.y * 3.8f
                        cameraDistance = 16f * density
                    }
            ) {
                WalletCardArtwork(
                    card = card,
                    modifier = Modifier.fillMaxWidth(),
                    shadowElevation = 12.dp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LiquidGlassButton(
                    onClick = {
                        onDismiss()
                        onTriggerApplePayNow()
                    },
                    darkTheme = darkTheme,
                    tintColor = accentBlue,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("detail_pay_with_nfc_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Contactless,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(19.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isGoogleWallet) "Pay with Google" else "Pay with Card",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                LiquidGlassSecondaryButton(
                    onClick = onReplacePhotoFromCameraRoll,
                    darkTheme = darkTheme,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("detail_replace_photo_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = null,
                        tint = accentBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Set Photo Skin",
                        color = accentBlue,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassSurface(
                        shape = RoundedCornerShape(20.dp),
                        darkTheme = darkTheme,
                        elevation = 6.dp
                    )
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Card Balance",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = card.balanceDisplay,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Row(
                        modifier = Modifier
                            .liquidGlassSurface(
                                shape = RoundedCornerShape(50),
                                darkTheme = darkTheme,
                                elevation = 4.dp,
                                tintColor = accentBlue.copy(alpha = 0.20f)
                            )
                            .liquidPressable(
                                pressScale = 0.90f,
                                onClick = {
                                    if (isCardNumberRevealed) {
                                        isCardNumberRevealed = false
                                    } else {
                                        onRequestBiometricReveal {
                                            isCardNumberRevealed = true
                                        }
                                    }
                                }
                            )
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("reveal_card_info_button"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = if (isCardNumberRevealed) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = null,
                            tint = if (darkTheme) Color.White else accentBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (isCardNumberRevealed) "Hide Number" else "Reveal Card Info",
                            color = if (darkTheme) Color.White else accentBlue,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                AnimatedContent(
                    targetState = isCardNumberRevealed,
                    transitionSpec = {
                        (fadeIn(tween(220)) + scaleIn(initialScale = 0.94f)) togetherWith
                            (fadeOut(tween(150)) + scaleOut(targetScale = 0.94f))
                    },
                    label = "virtualCardInfoTransition"
                ) { revealed ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Virtual Card Number",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (revealed) {
                                    "4532  8910  7421  ${card.lastFourDigits}"
                                } else {
                                    "••••  ••••  ••••  ${card.lastFourDigits}"
                                },
                                fontFamily = MonoFontFamily,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "EXP / CVV",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = if (revealed) "${card.expiryDate} • ${card.cvv}" else "${card.expiryDate} • •••",
                                fontFamily = MonoFontFamily,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = stringResource(R.string.latest_transactions),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(10.dp))

            val cardTransactions = transactions.filter { it.cardId == card.id }.ifEmpty { transactions.take(4) }
            val dateFormat = remember { SimpleDateFormat("MMM d, h:mm a", Locale.US) }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassSurface(
                        shape = RoundedCornerShape(20.dp),
                        darkTheme = darkTheme,
                        elevation = 6.dp
                    )
            ) {
                cardTransactions.forEachIndexed { index, tx ->
                    val displayCategory = if (isGoogleWallet) {
                        tx.locationOrCategory.replace("Apple Pay", "Google Pay")
                    } else {
                        tx.locationOrCategory
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 13.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = tx.merchantName,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "$displayCategory • ${dateFormat.format(Date(tx.timestamp))}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = tx.amountText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = if (tx.amountText.startsWith("+")) Color(0xFF34C759) else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    if (index < cardTransactions.lastIndex) {
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(26.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LarpStudioSettingsSheet(
    prefs: LarpPreferences,
    onUpdatePrefs: ((LarpPreferences) -> LarpPreferences) -> Unit,
    onPickGoogleProfilePhotoClick: () -> Unit = {},
    onResetGoogleProfilePhotoClick: () -> Unit = {},
    onTestSoundClick: () -> Unit,
    onImportCustomSoundClick: () -> Unit,
    onResetCustomSoundClick: () -> Unit = {},
    onLockWalletNow: () -> Unit,
    onResetDefaultCards: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val isGoogleWallet = prefs.ecosystemTheme == WalletEcosystemTheme.GOOGLE_WALLET
    val accentBlue = if (isGoogleWallet) GoogleBluePrimary else IosPrimaryBlue

    var merchantInput by remember(prefs.simulatedMerchantName) { mutableStateOf(prefs.simulatedMerchantName) }
    var amountInput by remember(prefs.simulatedAmountText) { mutableStateOf(prefs.simulatedAmountText) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isGoogleWallet) "Google Wallet Settings" else "Apple Pay Settings",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .liquidGlassSurface(
                            shape = CircleShape,
                            darkTheme = prefs.darkTheme,
                            elevation = 5.dp
                        )
                        .liquidPressable(pressScale = 0.86f, onClick = onDismiss),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (isGoogleWallet) {
                    "Customize Google Wallet payment settings, terminal outcome, NFC duration, and sounds."
                } else {
                    "Customize Apple Pay confirmation style, terminal outcome, NFC duration, and sounds."
                },
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 1. OFFICIAL APP LOGO & NAME (from folder assets)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassSurface(
                        shape = RoundedCornerShape(20.dp),
                        darkTheme = prefs.darkTheme,
                        elevation = 6.dp
                    )
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                ThemeAppIconBadge(
                    isGoogleWallet = isGoogleWallet,
                    customIconPath = null,
                    size = 46.dp
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isGoogleWallet) "Google Wallet (Official)" else "Apple Pay (Official)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Official logos and launcher identity applied directly from project assets",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 2. APP SPECIFIC CONTROLS: Google Profile Picture OR Apple Confirmation Icon
            if (isGoogleWallet) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .liquidGlassSurface(
                            shape = RoundedCornerShape(18.dp),
                            darkTheme = prefs.darkTheme,
                            elevation = 5.dp
                        )
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        GoogleProfileAvatarButton(
                            photoPath = prefs.googleProfilePhotoPath,
                            size = 44.dp,
                            onClick = onPickGoogleProfilePhotoClick
                        )
                        Column {
                            Text(
                                text = "Google Profile Picture",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Top-right button in Google Wallet",
                                fontSize = 11.sp,
                                lineHeight = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        LiquidGlassSecondaryButton(
                            onClick = onPickGoogleProfilePhotoClick,
                            darkTheme = prefs.darkTheme,
                            modifier = Modifier.testTag("change_google_pic_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoLibrary,
                                contentDescription = null,
                                tint = accentBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "Custom Pic",
                                color = accentBlue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (!prefs.googleProfilePhotoPath.isNullOrBlank()) {
                            LiquidGlassSecondaryButton(
                                onClick = onResetGoogleProfilePhotoClick,
                                darkTheme = prefs.darkTheme
                            ) {
                                Text(
                                    text = "Reset",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            } else {
                Text(
                    text = "Apple Pay Confirmation Icon Type",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ConfirmationTypeOptionCard(
                        title = "Face ID",
                        subtitle = "Blue Face ID icon",
                        selected = prefs.confirmationIconType == ConfirmationIconType.FACE_ID,
                        darkTheme = prefs.darkTheme,
                        accentColor = IosPrimaryBlue,
                        onClick = {
                            onUpdatePrefs { it.copy(confirmationIconType = ConfirmationIconType.FACE_ID) }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("confirm_type_face_id")
                    )

                    ConfirmationTypeOptionCard(
                        title = "Side Button",
                        subtitle = "Confirm with Side Button + Double Click",
                        selected = prefs.confirmationIconType == ConfirmationIconType.SIDE_BUTTON,
                        darkTheme = prefs.darkTheme,
                        accentColor = IosPrimaryBlue,
                        onClick = {
                            onUpdatePrefs { it.copy(confirmationIconType = ConfirmationIconType.SIDE_BUTTON) }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("confirm_type_side_button")
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // 5. Appearance, Haptics, Per-Theme Chime & Biometric Security Toggles inside Liquid Glass Container
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassSurface(
                        shape = RoundedCornerShape(20.dp),
                        darkTheme = prefs.darkTheme,
                        elevation = 6.dp
                    )
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                LarpToggleRow(
                    title = "Dark OLED Appearance",
                    subtitle = "Switch between Light and Dark OLED mode",
                    checked = prefs.darkTheme,
                    accentColor = accentBlue,
                    onCheckedChange = { dark ->
                        onUpdatePrefs { it.copy(darkTheme = dark) }
                    }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
                LarpToggleRow(
                    title = "Tactile Haptic Feedback",
                    subtitle = "Crisp vibration pulses on card swipe, 7s NFC radar, and Done",
                    checked = prefs.hapticsEnabled,
                    accentColor = accentBlue,
                    onCheckedChange = { enabled ->
                        onUpdatePrefs { it.copy(hapticsEnabled = enabled) }
                    }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
                LarpToggleRow(
                    title = if (isGoogleWallet) "Google Wallet Payment Sound" else "Apple Pay Payment Sound",
                    subtitle = if (isGoogleWallet) {
                        if (prefs.googleCustomSoundPath != null) "Using custom saved audio for Google Wallet"
                        else "Using Google Wallet 3-note chime (changes automatically per theme)"
                    } else {
                        if (prefs.appleCustomSoundPath != null) "Using custom saved audio for Apple Pay"
                        else "Using Apple Pay 2-note chime (changes automatically per theme)"
                    },
                    checked = prefs.chimeSoundEnabled,
                    accentColor = accentBlue,
                    onCheckedChange = { enabled ->
                        onUpdatePrefs { it.copy(chimeSoundEnabled = enabled) }
                    }
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
                LarpToggleRow(
                    title = "Hardware Biometric Prompt on Pay",
                    subtitle = "Verify with real Android Fingerprint before 7s NFC & Done",
                    checked = prefs.requireHardwareBiometricOnPay,
                    accentColor = accentBlue,
                    onCheckedChange = { enabled ->
                        onUpdatePrefs { it.copy(requireHardwareBiometricOnPay = enabled) }
                    }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 6. Per-Theme Sound Test & Custom Audio File Import Row
            val activeThemeLabel = if (isGoogleWallet) "Google" else "Apple"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LiquidGlassSecondaryButton(
                    onClick = onTestSoundClick,
                    darkTheme = prefs.darkTheme,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("test_pay_sound_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = accentBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Test $activeThemeLabel Sound",
                        color = accentBlue,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                LiquidGlassSecondaryButton(
                    onClick = onImportCustomSoundClick,
                    darkTheme = prefs.darkTheme,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("import_custom_sound_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AudioFile,
                        contentDescription = null,
                        tint = accentBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = if (prefs.currentThemeSoundPath != null) "Change $activeThemeLabel Audio" else "Set $activeThemeLabel Audio",
                        color = accentBlue,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (prefs.currentThemeSoundPath != null) {
                    LiquidGlassSecondaryButton(
                        onClick = onResetCustomSoundClick,
                        darkTheme = prefs.darkTheme,
                        modifier = Modifier.height(48.dp)
                    ) {
                        Text(
                            text = "Reset",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 6. Payment Duration (Customizable Hold Time) & Payment Outcome (Done vs Decline)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassSurface(
                        shape = RoundedCornerShape(20.dp),
                        darkTheme = prefs.darkTheme,
                        elevation = 6.dp
                    )
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Payment NFC Hold Duration",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Set contactless hold time (no countdown displayed on pay)",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = "${prefs.paymentDurationSeconds}s",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = accentBlue
                    )
                }

                Slider(
                    value = prefs.paymentDurationSeconds.toFloat(),
                    onValueChange = { newVal ->
                        val roundedSecs = newVal.toInt().coerceIn(1, 15)
                        onUpdatePrefs { it.copy(paymentDurationSeconds = roundedSecs) }
                    },
                    valueRange = 1f..15f,
                    steps = 13,
                    colors = SliderDefaults.colors(
                        thumbColor = accentBlue,
                        activeTrackColor = accentBlue
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))

                Text(
                    text = "Payment Outcome on Terminal End",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ConfirmationTypeOptionCard(
                        title = "Payment Done",
                        subtitle = "Green/Blue Done checkmark & success chime",
                        selected = prefs.paymentOutcome == PaymentOutcome.APPROVED,
                        darkTheme = prefs.darkTheme,
                        accentColor = accentBlue,
                        onClick = {
                            onUpdatePrefs { it.copy(paymentOutcome = PaymentOutcome.APPROVED) }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("outcome_approved")
                    )

                    ConfirmationTypeOptionCard(
                        title = "Decline",
                        subtitle = "Red 'X' decline animation & buzzer feedback",
                        selected = prefs.paymentOutcome == PaymentOutcome.DECLINED,
                        darkTheme = prefs.darkTheme,
                        accentColor = Color(0xFFD93025),
                        onClick = {
                            onUpdatePrefs { it.copy(paymentOutcome = PaymentOutcome.DECLINED) }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("outcome_declined")
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 7. Simulated Merchant & Amount for Notification & Receipt
            Text(
                text = "Simulated NFC Payment Notification & Receipt",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = merchantInput,
                    onValueChange = {
                        merchantInput = it
                        onUpdatePrefs { p -> p.copy(simulatedMerchantName = it) }
                    },
                    label = { Text("Merchant") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = {
                        amountInput = it
                        onUpdatePrefs { p -> p.copy(simulatedAmountText = it) }
                    },
                    label = { Text("Amount") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LiquidGlassButton(
                    onClick = {
                        onDismiss()
                        onLockWalletNow()
                    },
                    darkTheme = prefs.darkTheme,
                    tintColor = accentBlue,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("lock_wallet_biometric_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Lock ${if (isGoogleWallet) "Google Wallet" else "Apple Pay"}",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }

                LiquidGlassSecondaryButton(
                    onClick = {
                        onResetDefaultCards()
                        onDismiss()
                    },
                    darkTheme = prefs.darkTheme,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("reset_default_cards_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = accentBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Reset Cards",
                        color = accentBlue,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            // 8. Footer signature requested by user: "made by anas (alg_bl)"
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassSurface(
                        shape = RoundedCornerShape(16.dp),
                        darkTheme = prefs.darkTheme,
                        elevation = 4.dp
                    )
                    .padding(vertical = 12.dp, horizontal = 16.dp)
                    .testTag("settings_footer_made_by_anas"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "made by anas (alg_bl)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.4.sp,
                    color = accentBlue,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ConfirmationTypeOptionCard(
    title: String,
    subtitle: String,
    selected: Boolean,
    darkTheme: Boolean,
    accentColor: Color = IosPrimaryBlue,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedScale by animateFloatAsState(
        targetValue = if (selected) 1.02f else 0.98f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "confirmOptionScale"
    )

    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = selectedScale
                scaleY = selectedScale
            }
            .liquidGlassSurface(
                shape = RoundedCornerShape(18.dp),
                darkTheme = darkTheme,
                elevation = if (selected) 8.dp else 4.dp,
                tintColor = if (selected) accentColor else null
            )
            .liquidPressable(pressScale = 0.92f, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 11.sp,
                lineHeight = 14.sp,
                color = if (selected) Color.White.copy(alpha = 0.88f) else MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun LarpToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    accentColor: Color = IosPrimaryBlue,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        ) {
            Text(
                text = title,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = accentColor)
        )
    }
}
