package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Authentic iOS / Apple Wallet System Palette (matches reference screenshots)
val IosLightBackground = Color(0xFFF2F2F7)
val IosLightSurface = Color(0xFFFFFFFF)
val IosLightPillGlass = Color(0xEBFFFFFF)
val IosPrimaryBlue = Color(0xFF007AFF)
val IosTextPrimaryLight = Color(0xFF000000)
val IosTextSecondaryLight = Color(0xFF8E8E93)

// Dark OLED Palette
val IosDarkBackground = Color(0xFF000000)
val IosDarkSurface = Color(0xFF1C1C1E)
val IosDarkPillGlass = Color(0xD92C2C2E)
val IosTextPrimaryDark = Color(0xFFFFFFFF)
val IosTextSecondaryDark = Color(0xFF98989D)

// Card Specific Brand Colors from Screenshots
val AlrajhiRoyalBlue = Color(0xFF0047BA)
val SnbEmeraldGreen = Color(0xFF006C35)
val SnbLimePattern = Color(0xFF58B947)
val StcDeepPurple = Color(0xFF4F008C)
val StcLavender = Color(0xFFE2D4F0)
val StcMintGreen = Color(0xFF00C48C)
val AlinmaPearlWhite = Color(0xFFF4F3EF)
val AlinmaCocoaBrown = Color(0xFF523228)
val RiyadObsidian = Color(0xFF121317)
val Trading212Black = Color(0xFF070709)
val Trading212Cyan = Color(0xFF00A8FF)
val MastercardRed = Color(0xFFEB001B)
val MastercardAmber = Color(0xFFF79E1B)
val VisaRoyalBlue = Color(0xFF1434CB)
