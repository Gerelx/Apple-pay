package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.WalletCardEntity
import com.example.hardware.BiometricAndNfcController
import com.example.ui.HomeDisplayMode
import com.example.ui.WalletEcosystemTheme
import com.example.ui.WalletViewModel
import com.example.ui.screens.AddOrEditCardSheet
import com.example.ui.screens.CardDetailModalSheet
import com.example.ui.screens.LarpStudioSettingsSheet
import com.example.ui.screens.WalletHomeScreen
import com.example.ui.theme.MyApplicationTheme

private enum class PhotoImportTarget {
    SHEET_PREVIEW,
    REPLACE_EXISTING_CARD,
    GOOGLE_PROFILE_PIC
}

class MainActivity : ComponentActivity() {

    private lateinit var biometricAndNfcController: BiometricAndNfcController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        biometricAndNfcController = BiometricAndNfcController(this)

        // Which wallet this app is, fixed at build time (applePay / googleWallet flavor).
        val startThemeName = BuildConfig.ECOSYSTEM

        setContent {
            val walletViewModel: WalletViewModel = viewModel()
            val uiState by walletViewModel.uiState.collectAsStateWithLifecycle()

            androidx.compose.runtime.LaunchedEffect(startThemeName) {
                if (startThemeName == WalletEcosystemTheme.GOOGLE_WALLET.name) {
                    walletViewModel.setEcosystemTheme(WalletEcosystemTheme.GOOGLE_WALLET)
                } else {
                    walletViewModel.setEcosystemTheme(WalletEcosystemTheme.APPLE_PAY)
                }
            }

            var showAddOrEditSheet by remember { mutableStateOf(false) }
            var editingCard by remember { mutableStateOf<WalletCardEntity?>(null) }
            var sheetImportedPhotoPath by remember { mutableStateOf<String?>(null) }
            var cardTargetForPhotoReplace by remember { mutableStateOf<WalletCardEntity?>(null) }
            var photoImportTarget by remember { mutableStateOf(PhotoImportTarget.SHEET_PREVIEW) }

            var inspectingCard by remember { mutableStateOf<WalletCardEntity?>(null) }
            var showLarpStudioSheet by remember { mutableStateOf(false) }

            val startBiometricPayVerification = {
                if (uiState.larpPrefs.requireHardwareBiometricOnPay) {
                    biometricAndNfcController.authenticateWithHardwareBiometrics(
                        title = uiState.larpPrefs.currentThemeAppName,
                        subtitle = "Verify with Fingerprint to Pay",
                        onAuthenticated = {
                            walletViewModel.onBiometricVerifiedStartNfcAndDoneSequence()
                        },
                        onNoHardwareFallback = {
                            walletViewModel.onBiometricVerifiedStartNfcAndDoneSequence()
                        },
                        onCancelled = {
                            walletViewModel.hapticAndSound.performErrorShake(uiState.larpPrefs.hapticsEnabled)
                        }
                    )
                } else {
                    walletViewModel.onBiometricVerifiedStartNfcAndDoneSequence()
                }
            }

            // Zero-permission Android Photo Picker for importing from Phone's Camera Roll
            val cameraRollPickerLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.PickVisualMedia()
            ) { uri ->
                if (uri != null) {
                    when (photoImportTarget) {
                        PhotoImportTarget.SHEET_PREVIEW -> {
                            walletViewModel.importCardPhotoFromUri(uri) { savedPath ->
                                sheetImportedPhotoPath = savedPath
                            }
                        }
                        PhotoImportTarget.REPLACE_EXISTING_CARD -> {
                            val target = cardTargetForPhotoReplace ?: uiState.activeHeroCard
                            walletViewModel.importCardPhotoFromUri(
                                uri = uri,
                                replaceCard = target,
                                purePhotoMode = true
                            )
                        }
                        PhotoImportTarget.GOOGLE_PROFILE_PIC -> {
                            walletViewModel.importGoogleProfilePhotoFromUri(uri)
                        }
                    }
                }
            }

            // Local Files Image Picker
            val localFilesPickerLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) {
                    walletViewModel.importCardPhotoFromUri(uri) { savedPath ->
                        sheetImportedPhotoPath = savedPath
                    }
                }
            }

            // Custom Payment Audio File Picker (saves for the currently active theme)
            val customSoundPickerLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) {
                    walletViewModel.importCustomSoundFromUri(uri)
                }
            }

            // Physical NFC Reader Mode when in Apple Pay Express Screen or Google Wallet Home
            DisposableEffect(uiState.displayMode, uiState.larpPrefs.ecosystemTheme) {
                val isGoogleWallet = uiState.larpPrefs.ecosystemTheme == WalletEcosystemTheme.GOOGLE_WALLET
                if (isGoogleWallet || uiState.displayMode == HomeDisplayMode.APPLE_PAY_EXPRESS) {
                    biometricAndNfcController.enableNfcReaderMode {
                        if (isGoogleWallet) {
                            uiState.activeHeroCard?.let { card ->
                                walletViewModel.onGoogleWalletCardChosenStartNfcAndDone(card)
                            }
                        } else {
                            startBiometricPayVerification()
                        }
                    }
                }
                onDispose {
                    biometricAndNfcController.disableNfcReaderMode()
                }
            }

            MyApplicationTheme(darkTheme = uiState.larpPrefs.darkTheme) {
                WalletHomeScreen(
                    uiState = uiState,
                    onAddCardClick = {
                        editingCard = null
                        sheetImportedPhotoPath = null
                        showAddOrEditSheet = true
                    },
                    onSearchToggle = { walletViewModel.toggleSearchBar() },
                    onSearchQueryChange = { walletViewModel.updateSearchQuery(it) },
                    onMoreOptionsClick = { showLarpStudioSheet = true },
                    onCardChosenFromStack = { card ->
                        walletViewModel.selectCardAndOpenExpress(card)
                    },
                    onCardLongPress = { card ->
                        inspectingCard = card
                    },
                    onSwapCardInExpress = { card ->
                        walletViewModel.swapActiveCardInExpressMode(card)
                    },
                    onStartFaceIdVerification = {
                        startBiometricPayVerification()
                    },
                    onGoogleWalletCardSwiped = { card ->
                        walletViewModel.onGoogleWalletCardSwiped(card)
                    },
                    onGoogleWalletCardChosenPay = { card ->
                        walletViewModel.onGoogleWalletCardChosenStartNfcAndDone(card)
                    },
                    onCancelGoogleWalletPay = {
                        walletViewModel.cancelGoogleWalletPaymentAnimation()
                    },
                    onSwitchDisplayMode = { mode ->
                        walletViewModel.setDisplayMode(mode)
                    },
                    onSetStackFilter = { filter ->
                        walletViewModel.setStackPresetFilter(filter)
                    },
                    onUnlockWalletWithBiometrics = {
                        val prefs = uiState.larpPrefs
                        biometricAndNfcController.authenticateWithHardwareBiometrics(
                            title = "Unlock ${prefs.currentThemeAppName}",
                            subtitle = "Authenticate with Fingerprint or Biometrics",
                            onAuthenticated = {
                                walletViewModel.updateLarpPreferences { it.copy(isAppLocked = false) }
                                walletViewModel.hapticAndSound.performPaymentSuccess(
                                    hapticsEnabled = prefs.hapticsEnabled,
                                    soundEnabled = prefs.chimeSoundEnabled,
                                    isGoogleWalletTheme = prefs.isGoogleWallet,
                                    customSoundPath = prefs.currentThemeSoundPath
                                )
                            },
                            onNoHardwareFallback = {
                                walletViewModel.updateLarpPreferences { it.copy(isAppLocked = false) }
                                walletViewModel.hapticAndSound.performPaymentSuccess(
                                    hapticsEnabled = prefs.hapticsEnabled,
                                    soundEnabled = prefs.chimeSoundEnabled,
                                    isGoogleWalletTheme = prefs.isGoogleWallet,
                                    customSoundPath = prefs.currentThemeSoundPath
                                )
                            }
                        )
                    }
                )

                if (showAddOrEditSheet) {
                    AddOrEditCardSheet(
                        editingCard = editingCard,
                        importedPhotoPath = sheetImportedPhotoPath,
                        darkTheme = uiState.larpPrefs.darkTheme,
                        onPickFromCameraRoll = {
                            photoImportTarget = PhotoImportTarget.SHEET_PREVIEW
                            cameraRollPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onPickFromLocalFiles = {
                            photoImportTarget = PhotoImportTarget.SHEET_PREVIEW
                            localFilesPickerLauncher.launch(arrayOf("image/*"))
                        },
                        onClearImportedPhoto = {
                            sheetImportedPhotoPath = null
                        },
                        onSaveCard = { title, subtitle, holder, lastFour, network, style, primHex, secHex, imgPath, purePhoto, balance ->
                            val existing = editingCard
                            if (existing != null) {
                                walletViewModel.updateExistingCard(
                                    existing.copy(
                                        title = title,
                                        arabicSubtitle = subtitle,
                                        cardHolderName = holder,
                                        lastFourDigits = lastFour,
                                        network = network,
                                        presetStyle = style,
                                        primaryColorHex = primHex,
                                        secondaryColorHex = secHex,
                                        customImagePath = imgPath,
                                        purePhotoMode = purePhoto,
                                        balanceDisplay = balance
                                    )
                                )
                            } else {
                                walletViewModel.addCustomCard(
                                    title = title,
                                    arabicSubtitle = subtitle,
                                    cardHolderName = holder,
                                    lastFourDigits = lastFour,
                                    network = network,
                                    presetStyle = style,
                                    primaryColorHex = primHex,
                                    secondaryColorHex = secHex,
                                    customImagePath = imgPath,
                                    purePhotoMode = purePhoto,
                                    balanceDisplay = balance
                                )
                            }
                        },
                        onDeleteCard = if (editingCard != null) {
                            { cardId -> walletViewModel.deleteCard(cardId) }
                        } else {
                            null
                        },
                        onDismiss = {
                            showAddOrEditSheet = false
                            editingCard = null
                            sheetImportedPhotoPath = null
                        }
                    )
                }

                inspectingCard?.let { card ->
                    val liveCard = uiState.allCards.find { it.id == card.id } ?: card
                    CardDetailModalSheet(
                        card = liveCard,
                        transactions = uiState.recentTransactions,
                        darkTheme = uiState.larpPrefs.darkTheme,
                        isGoogleWallet = uiState.larpPrefs.isGoogleWallet,
                        onReplacePhotoFromCameraRoll = {
                            cardTargetForPhotoReplace = liveCard
                            photoImportTarget = PhotoImportTarget.REPLACE_EXISTING_CARD
                            cameraRollPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onEditCard = {
                            inspectingCard = null
                            editingCard = liveCard
                            sheetImportedPhotoPath = liveCard.customImagePath
                            showAddOrEditSheet = true
                        },
                        onTriggerApplePayNow = {
                            inspectingCard = null
                            if (uiState.larpPrefs.ecosystemTheme == WalletEcosystemTheme.GOOGLE_WALLET) {
                                walletViewModel.onGoogleWalletCardChosenStartNfcAndDone(liveCard)
                            } else {
                                walletViewModel.selectCardAndOpenExpress(liveCard)
                            }
                        },
                        onRequestBiometricReveal = { onSuccess ->
                            biometricAndNfcController.authenticateWithHardwareBiometrics(
                                title = "Reveal Virtual Card Details",
                                subtitle = "Authenticate with Fingerprint or Biometrics",
                                onAuthenticated = {
                                    walletViewModel.hapticAndSound.performFaceIdScanPulse(uiState.larpPrefs.hapticsEnabled)
                                    onSuccess()
                                },
                                onNoHardwareFallback = {
                                    walletViewModel.hapticAndSound.performFaceIdScanPulse(uiState.larpPrefs.hapticsEnabled)
                                    onSuccess()
                                }
                            )
                        },
                        onDismiss = { inspectingCard = null }
                    )
                }

                if (showLarpStudioSheet) {
                    LarpStudioSettingsSheet(
                        prefs = uiState.larpPrefs,
                        onUpdatePrefs = { transform -> walletViewModel.updateLarpPreferences(transform) },
                        onPickGoogleProfilePhotoClick = {
                            photoImportTarget = PhotoImportTarget.GOOGLE_PROFILE_PIC
                            cameraRollPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onResetGoogleProfilePhotoClick = {
                            walletViewModel.clearGoogleProfilePhoto()
                        },
                        onTestSoundClick = {
                            walletViewModel.hapticAndSound.performPaymentSuccess(
                                hapticsEnabled = uiState.larpPrefs.hapticsEnabled,
                                soundEnabled = true,
                                isGoogleWalletTheme = uiState.larpPrefs.isGoogleWallet,
                                customSoundPath = uiState.larpPrefs.currentThemeSoundPath
                            )
                        },
                        onImportCustomSoundClick = {
                            customSoundPickerLauncher.launch(arrayOf("audio/*"))
                        },
                        onResetCustomSoundClick = {
                            walletViewModel.resetCustomSoundForTheme()
                        },
                        onLockWalletNow = {
                            walletViewModel.updateLarpPreferences { it.copy(isAppLocked = true) }
                        },
                        onResetDefaultCards = {
                            walletViewModel.resetAllCardsToScreenshotDefaults()
                        },
                        onDismiss = { showLarpStudioSheet = false }
                    )
                }
            }
        }
    }
}
