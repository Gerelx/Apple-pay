package com.example.hardware

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext

/**
 * Listens to the device's accelerometer/gravity sensor to provide smooth, low-pass-filtered
 * 3D tilt offsets (x in -1f..1f, y in -1f..1f) for Liquid Glass refraction and metallic card glare.
 */
@Composable
fun rememberDeviceTiltOffset(): State<Offset> {
    val context = LocalContext.current
    val tiltState = remember { mutableStateOf(Offset.Zero) }

    DisposableEffect(context) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        var smoothedX = 0f
        var smoothedY = 0f

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                val values = event?.values ?: return
                if (values.size >= 2) {
                    val rawX = (values[0] / 9.81f).coerceIn(-1f, 1f)
                    val rawY = ((values[1] - 4.5f) / 9.81f).coerceIn(-1f, 1f)
                    // Smooth low-pass filter for buttery 60/120fps motion
                    smoothedX += (rawX - smoothedX) * 0.14f
                    smoothedY += (rawY - smoothedY) * 0.14f
                    tiltState.value = Offset(smoothedX, smoothedY)
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        if (sensor != null) {
            try {
                sensorManager?.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
            } catch (_: Exception) {
            }
        }

        onDispose {
            try {
                sensorManager?.unregisterListener(listener)
            } catch (_: Exception) {
            }
        }
    }

    return tiltState
}
