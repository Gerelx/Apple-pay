package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallet_cards ORDER BY sortOrder ASC, id ASC")
    fun getAllCards(): Flow<List<WalletCardEntity>>

    @Query("SELECT COUNT(*) FROM wallet_cards")
    suspend fun getCardCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCard(card: WalletCardEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCards(cards: List<WalletCardEntity>)

    @Update
    suspend fun updateCard(card: WalletCardEntity)

    @Query("DELETE FROM wallet_cards WHERE id = :cardId")
    suspend fun deleteCardById(cardId: Int)

    @Query("DELETE FROM wallet_cards")
    suspend fun deleteAllCards()

    @Query("SELECT * FROM wallet_transactions WHERE cardId = :cardId ORDER BY timestamp DESC")
    fun getTransactionsForCard(cardId: Int): Flow<List<WalletTransactionEntity>>

    @Query("SELECT * FROM wallet_transactions ORDER BY timestamp DESC LIMIT 30")
    fun getRecentTransactions(): Flow<List<WalletTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: WalletTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<WalletTransactionEntity>)

    @Query("DELETE FROM wallet_transactions")
    suspend fun deleteAllTransactions()
}
