package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.WalletCardEntity
import com.example.ui.theme.IosPrimaryBlue
import java.io.File

/**
 * Applies an iOS 26 / visionOS Liquid Glass frosted surface with animated optical caustic
 * refraction, chromatic rim catchlight, and soft elevation depth.
 */
fun Modifier.liquidGlassSurface(
    shape: Shape = RoundedCornerShape(28.dp),
    darkTheme: Boolean = false,
    elevation: Dp = 8.dp,
    tintColor: Color? = null
): Modifier = composed {
    val infiniteTransition = rememberInfiniteTransition(label = "liquidGlassCaustic")
    val shimmerPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmerPhase"
    )

    val baseFill = if (tintColor != null) {
        Brush.linearGradient(
            colors = listOf(
                tintColor.copy(alpha = 0.90f),
                tintColor.copy(alpha = 0.76f),
                tintColor.copy(alpha = 0.94f)
            ),
            start = Offset(0f, 0f),
            end = Offset(400f * (0.4f + shimmerPhase * 0.6f), 260f)
        )
    } else if (darkTheme) {
        Brush.linearGradient(
            colors = listOf(
                Color(0xE634353C),
                Color(0xCC202127),
                Color(0xE62B2D35)
            ),
            start = Offset(0f, 0f),
            end = Offset(300f * (0.5f + shimmerPhase * 0.5f), 200f)
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                Color(0xFCFFFFFF),
                Color(0xF0F2F7FF),
                Color(0xFAFFFFFF)
            ),
            start = Offset(0f, 0f),
            end = Offset(300f * (0.5f + shimmerPhase * 0.5f), 200f)
        )
    }

    val rimBrush = if (tintColor != null) {
        Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.72f),
                Color(0xFFB3E0FF).copy(alpha = 0.38f),
                Color.White.copy(alpha = 0.18f),
                Color.White.copy(alpha = 0.60f)
            ),
            start = Offset(0f, 0f),
            end = Offset(260f + 120f * shimmerPhase, 180f)
        )
    } else if (darkTheme) {
        Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.45f),
                Color(0xFF70B8FF).copy(alpha = 0.22f),
                Color.White.copy(alpha = 0.08f),
                Color.White.copy(alpha = 0.35f)
            ),
            start = Offset(0f, 0f),
            end = Offset(260f + 120f * shimmerPhase, 180f)
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = 1.0f),
                Color(0xFFCCE2FF).copy(alpha = 0.68f),
                Color.Black.copy(alpha = 0.06f),
                Color.White.copy(alpha = 0.95f)
            ),
            start = Offset(0f, 0f),
            end = Offset(260f + 120f * shimmerPhase, 180f)
        )
    }

    this
        .shadow(
            elevation = elevation,
            shape = shape,
            ambientColor = (tintColor ?: Color.Black).copy(alpha = if (darkTheme) 0.55f else 0.16f),
            spotColor = (tintColor ?: Color.Black).copy(alpha = if (darkTheme) 0.55f else 0.22f)
        )
        .clip(shape)
        .background(brush = baseFill, shape = shape)
        .drawWithContent {
            drawContent()
            // Top inner optical glass specular sheen
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = if (darkTheme || tintColor != null) 0.22f else 0.55f),
                        Color.Transparent
                    ),
                    startY = 0f,
                    endY = size.height * 0.48f
                )
            )
        }
        .border(width = 1.15.dp, brush = rimBrush, shape = shape)
}

/**
 * Adds elastic Liquid Glass press physics (bounces down on press and springs back with low damping
 * and a luminous press highlight).
 */
fun Modifier.liquidPressable(
    enabled: Boolean = true,
    pressScale: Float = 0.92f,
    onClick: () -> Unit
): Modifier = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) pressScale else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "liquidPressScale"
    )
    val glowAlpha by animateFloatAsState(
        targetValue = if (isPressed && enabled) 0.18f else 0f,
        animationSpec = tween(durationMillis = 120),
        label = "liquidPressGlow"
    )

    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .drawWithContent {
            drawContent()
            if (glowAlpha > 0.001f) {
                drawRect(color = Color.White.copy(alpha = glowAlpha))
            }
        }
        .clickable(
            interactionSource = interactionSource,
            indication = null,
            enabled = enabled,
            onClick = onClick
        )
}

/**
 * Primary Liquid Glass Button with optical specular top catchlight and bouncy spring physics.
 */
@Composable
fun LiquidGlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tintColor: Color = IosPrimaryBlue,
    darkTheme: Boolean = false,
    shape: Shape = RoundedCornerShape(16.dp),
    content: @Composable RowScope.() -> Unit
) {
    Row(
        modifier = modifier
            .liquidGlassSurface(
                shape = shape,
                darkTheme = darkTheme,
                elevation = 8.dp,
                tintColor = tintColor
            )
            .liquidPressable(pressScale = 0.94f, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

/**
 * Secondary Translucent Frosted Liquid Glass Button.
 */
@Composable
fun LiquidGlassSecondaryButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    darkTheme: Boolean = false,
    shape: Shape = RoundedCornerShape(16.dp),
    content: @Composable RowScope.() -> Unit
) {
    Row(
        modifier = modifier
            .liquidGlassSurface(
                shape = shape,
                darkTheme = darkTheme,
                elevation = 5.dp,
                tintColor = null
            )
            .liquidPressable(pressScale = 0.94f, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

/**
 * Renders the theme's custom App Icon (or the built-in Apple Pay / Google Wallet icon if not customized).
 */
@Composable
fun ThemeAppIconBadge(
    isGoogleWallet: Boolean,
    customIconPath: String?,
    size: Dp = 32.dp,
    modifier: Modifier = Modifier
) {
    val imageModel = remember(customIconPath) {
        if (customIconPath.isNullOrBlank()) {
            null
        } else if (customIconPath.startsWith("content://") || customIconPath.startsWith("file://") || customIconPath.startsWith("http")) {
            Uri.parse(customIconPath)
        } else {
            File(customIconPath)
        }
    }

    val shape = RoundedCornerShape((size.value * 0.26f).dp)

    if (imageModel != null) {
        Box(
            modifier = modifier
                .size(size)
                .shadow(2.dp, shape)
                .clip(shape)
        ) {
            AsyncImage(
                model = imageModel,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    } else if (isGoogleWallet) {
        Box(
            modifier = modifier
                .size(size)
                .shadow(2.dp, shape)
                .clip(shape)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_google_wallet_logo),
                contentDescription = "Google Wallet",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    } else {
        Box(
            modifier = modifier
                .size(size)
                .shadow(2.dp, shape)
                .clip(shape)
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_apple_pay_logo),
                contentDescription = "Apple Pay",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

/**
 * Renders the "Wallet" title on the left and the Liquid Glass "+" circle + "🔍  •••" pill
 * on the right with elastic liquid press physics.
 */
@Composable
fun WalletHeaderBar(
    darkTheme: Boolean,
    appName: String = stringResource(R.string.wallet_title),
    customIconPath: String? = null,
    onAddCardClick: () -> Unit,
    onSearchClick: () -> Unit,
    onMoreOptionsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val iconTint = if (darkTheme) Color.White else Color(0xFF1C1C1E)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (!customIconPath.isNullOrBlank()) {
                ThemeAppIconBadge(
                    isGoogleWallet = false,
                    customIconPath = customIconPath,
                    size = 34.dp
                )
            }
            Text(
                text = if (appName == "Apple Pay") stringResource(R.string.wallet_title) else appName,
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.9).sp
                ),
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.testTag("wallet_header_title")
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Circular Liquid Glass "+" Button with elastic bounce
            Box(
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .size(44.dp)
                    .liquidGlassSurface(
                        shape = CircleShape,
                        darkTheme = darkTheme,
                        elevation = 8.dp
                    )
                    .liquidPressable(pressScale = 0.88f, onClick = onAddCardClick)
                    .testTag("add_card_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = stringResource(R.string.cd_add_card),
                    tint = iconTint,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Combined Liquid Glass Capsule Pill with Search ("🔍") and More ("•••")
            Row(
                modifier = Modifier
                    .height(44.dp)
                    .liquidGlassSurface(
                        shape = RoundedCornerShape(22.dp),
                        darkTheme = darkTheme,
                        elevation = 8.dp
                    )
                    .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .liquidPressable(pressScale = 0.86f, onClick = onSearchClick)
                        .testTag("search_cards_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = stringResource(R.string.cd_search_cards),
                        tint = iconTint,
                        modifier = Modifier.size(21.dp)
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .liquidPressable(pressScale = 0.86f, onClick = onMoreOptionsClick)
                        .testTag("more_options_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreHoriz,
                        contentDescription = stringResource(R.string.cd_more_options),
                        tint = iconTint,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

/**
 * Slides down from the top of the screen with spring physics when a payment succeeds ("Done").
 * Automatically adapts to the active theme:
 * - In Google Wallet Theme: shows Google Wallet icon (or custom Google theme icon) + Google Wallet name
 *   ("Google Wallet" / custom name) + Google Blue badge ("Paid with Google Pay").
 * - In Apple Pay Theme: shows Apple Pay icon (or custom Apple theme icon) + Apple Pay name
 *   ("Apple Pay" / custom name).
 */
@Composable
fun LiquidGlassPaymentNotificationBanner(
    visible: Boolean,
    card: WalletCardEntity?,
    merchantName: String,
    amountText: String,
    isGoogleWallet: Boolean,
    appName: String,
    appIconPath: String?,
    darkTheme: Boolean,
    isDeclined: Boolean = false,
    modifier: Modifier = Modifier
) {
    val accentColor = if (isDeclined) {
        Color(0xFFD93025)
    } else if (isGoogleWallet) {
        GoogleBluePrimary
    } else {
        IosPrimaryBlue
    }

    AnimatedVisibility(
        visible = visible && card != null,
        enter = slideInVertically(
            initialOffsetY = { -it - 48 },
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioLowBouncy,
                stiffness = Spring.StiffnessMediumLow
            )
        ) + scaleIn(
            initialScale = 0.90f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioLowBouncy,
                stiffness = Spring.StiffnessMediumLow
            )
        ) + fadeIn(tween(220, easing = FastOutSlowInEasing)),
        exit = slideOutVertically(
            targetOffsetY = { -it - 48 },
            animationSpec = tween(240)
        ) + scaleOut(targetScale = 0.92f) + fadeOut(tween(180)),
        modifier = modifier
    ) {
        if (card != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .liquidGlassSurface(
                        shape = RoundedCornerShape(24.dp),
                        darkTheme = darkTheme,
                        elevation = 16.dp
                    )
                    .padding(horizontal = 14.dp, vertical = 12.dp)
                    .testTag("payment_notification_banner"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    // Theme App Icon Badge + Mini Card Thumbnail
                    Box(contentAlignment = Alignment.BottomEnd) {
                        Box(modifier = Modifier.width(52.dp)) {
                            WalletCardArtwork(
                                card = card,
                                cornerRadius = 6.dp,
                                shadowElevation = 2.dp,
                                enableLiquidShimmer = false
                            )
                        }
                        ThemeAppIconBadge(
                            isGoogleWallet = isGoogleWallet,
                            customIconPath = appIconPath,
                            size = 18.dp
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text(
                                text = appName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = accentColor
                            )
                            Icon(
                                imageVector = if (isDeclined) Icons.Default.Close else Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = if (isDeclined) {
                                    if (isGoogleWallet) "Google Pay • Declined" else "Apple Pay • Declined"
                                } else {
                                    if (isGoogleWallet) "Google Pay • now" else "Apple Pay • now"
                                },
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.78f)
                            )
                        }
                        Text(
                            text = merchantName,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${card.title} (•••• ${card.lastFourDigits.takeLast(4)})",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Text(
                    text = if (isDeclined) "Declined" else amountText,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = accentColor
                )
            }
        }
    }
}
