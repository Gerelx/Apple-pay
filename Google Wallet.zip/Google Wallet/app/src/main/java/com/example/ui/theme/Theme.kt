package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkWalletColorScheme = darkColorScheme(
    primary = IosPrimaryBlue,
    onPrimary = Color.White,
    secondary = Trading212Cyan,
    onSecondary = Color.White,
    background = IosDarkBackground,
    onBackground = IosTextPrimaryDark,
    surface = IosDarkSurface,
    onSurface = IosTextPrimaryDark,
    surfaceVariant = Color(0xFF2C2C2E),
    onSurfaceVariant = IosTextSecondaryDark
)

private val LightWalletColorScheme = lightColorScheme(
    primary = IosPrimaryBlue,
    onPrimary = Color.White,
    secondary = AlrajhiRoyalBlue,
    onSecondary = Color.White,
    background = IosLightBackground,
    onBackground = IosTextPrimaryLight,
    surface = IosLightSurface,
    onSurface = IosTextPrimaryLight,
    surfaceVariant = Color(0xFFE5E5EA),
    onSurfaceVariant = IosTextSecondaryLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkWalletColorScheme else LightWalletColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
