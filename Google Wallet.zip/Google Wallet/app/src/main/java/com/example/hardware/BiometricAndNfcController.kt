package com.example.hardware

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.nfc.NfcAdapter
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal

class BiometricAndNfcController(private val activity: Activity) {

    private var nfcAdapter: NfcAdapter? = try {
        NfcAdapter.getDefaultAdapter(activity)
    } catch (_: Exception) {
        null
    }

    fun isNfcHardwareAvailable(): Boolean = nfcAdapter != null

    /**
     * Triggers the real Android hardware BiometricPrompt (Fingerprint / Biometrics).
     * Requires real fingerprint recognition on devices with enrolled biometrics.
     * Only falls back if the device/emulator has no enrolled biometrics or no hardware sensor.
     */
    fun authenticateWithHardwareBiometrics(
        title: String = "Apple Pay",
        subtitle: String = "Verify with Fingerprint to Pay",
        onAuthenticated: () -> Unit,
        onNoHardwareFallback: () -> Unit,
        onCancelled: () -> Unit = {}
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            onNoHardwareFallback()
            return
        }

        val keyguard = activity.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        if (keyguard?.isDeviceSecure != true) {
            onNoHardwareFallback()
            return
        }

        try {
            val cancellationSignal = CancellationSignal()
            val executor = activity.mainExecutor
            val promptBuilder = BiometricPrompt.Builder(activity)
                .setTitle(title)
                .setSubtitle(subtitle)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                promptBuilder.setAllowedAuthenticators(
                    BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.BIOMETRIC_WEAK
                )
            }

            promptBuilder.setNegativeButton("Cancel", executor) { _, _ ->
                onCancelled()
            }

            val prompt = promptBuilder.build()

            prompt.authenticate(
                cancellationSignal,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        super.onAuthenticationSucceeded(result)
                        onAuthenticated()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                        super.onAuthenticationError(errorCode, errString)
                        if (errorCode == BiometricPrompt.BIOMETRIC_ERROR_NO_BIOMETRICS ||
                            errorCode == BiometricPrompt.BIOMETRIC_ERROR_HW_NOT_PRESENT ||
                            errorCode == BiometricPrompt.BIOMETRIC_ERROR_HW_UNAVAILABLE
                        ) {
                            onNoHardwareFallback()
                        } else {
                            // User cancelled or locked out — do not bypass!
                            onCancelled()
                        }
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        // Fingerprint not recognized — BiometricPrompt stays open for retry
                    }
                }
            )
        } catch (_: Exception) {
            onNoHardwareFallback()
        }
    }

    fun enableNfcReaderMode(onTagDetected: (String) -> Unit) {
        val adapter = nfcAdapter ?: return
        try {
            val flags = NfcAdapter.FLAG_READER_NFC_A or
                NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or
                NfcAdapter.FLAG_READER_NFC_V or
                NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK or
                NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS

            val extras = Bundle().apply {
                putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 250)
            }

            adapter.enableReaderMode(
                activity,
                { tag ->
                    val tagHex = tag?.id?.joinToString("") { "%02X".format(it) } ?: "NFC-READER"
                    activity.runOnUiThread {
                        onTagDetected(tagHex)
                    }
                },
                flags,
                extras
            )
        } catch (_: Exception) {
        }
    }

    fun disableNfcReaderMode() {
        try {
            nfcAdapter?.disableReaderMode(activity)
        } catch (_: Exception) {
        }
    }
}
