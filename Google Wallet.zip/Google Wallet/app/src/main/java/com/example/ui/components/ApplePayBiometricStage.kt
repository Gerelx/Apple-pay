package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.IosPrimaryBlue
import com.example.ui.theme.IosTextSecondaryLight

enum class PaymentStage {
    FACE_ID_SCANNING,
    NFC_HOLD_NEAR_READER,
    PROCESSING,
    DONE,
    DECLINED
}

enum class ConfirmationIconType {
    FACE_ID,
    SIDE_BUTTON
}

/**
 * Renders the center payment authentication stage with spring-choreographed transitions
 * and Liquid Glass aura effects.
 */
@Composable
fun ApplePayBiometricStage(
    stage: PaymentStage,
    confirmationIconType: ConfirmationIconType = ConfirmationIconType.FACE_ID,
    nfcProgress: Float = 0f,
    onStageClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .liquidPressable(
                enabled = stage == PaymentStage.FACE_ID_SCANNING,
                pressScale = 0.90f,
                onClick = onStageClick
            )
            .padding(vertical = 12.dp, horizontal = 24.dp)
            .testTag("apple_pay_biometric_stage"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        AnimatedContent(
            targetState = Pair(stage, confirmationIconType),
            transitionSpec = {
                (fadeIn(tween(260, easing = FastOutSlowInEasing)) +
                    scaleIn(
                        initialScale = 0.72f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioLowBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        )
                    ))
                    .togetherWith(
                        fadeOut(tween(160)) +
                            scaleOut(targetScale = 0.85f, animationSpec = tween(160))
                    )
            },
            label = "paymentStageTransition"
        ) { (currentStage, iconType) ->
            when (currentStage) {
                PaymentStage.FACE_ID_SCANNING -> {
                    if (iconType == ConfirmationIconType.SIDE_BUTTON) {
                        ConfirmWithSideButtonIconAndLabel()
                    } else {
                        FaceIdIconAndLabel()
                    }
                }
                PaymentStage.NFC_HOLD_NEAR_READER -> {
                    NfcAnimatedWavesAndLabel(
                        nfcProgress = nfcProgress
                    )
                }
                PaymentStage.PROCESSING -> {
                    ProcessingSpinnerAndLabel()
                }
                PaymentStage.DONE -> {
                    DoneCheckmarkCircleAndLabel()
                }
                PaymentStage.DECLINED -> {
                    ApplePayDeclinedCircleAndLabel()
                }
            }
        }
    }
}

@Composable
fun ConfirmWithSideButtonIconAndLabel() {
    val infiniteTransition = rememberInfiniteTransition(label = "sideButtonArrowPulse")
    val arrowOffsetPx by infiniteTransition.animateFloat(
        initialValue = 1.5f,
        targetValue = -4.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(680, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "arrowOffset"
    )
    val auraAlpha by infiniteTransition.animateFloat(
        initialValue = 0.08f,
        targetValue = 0.22f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "auraAlpha"
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.size(74.dp),
            contentAlignment = Alignment.Center
        ) {
            // Soft Liquid Glass radial aura behind the circle
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                IosPrimaryBlue.copy(alpha = auraAlpha),
                                Color.Transparent
                            )
                        )
                    )
            )

            Canvas(modifier = Modifier.size(56.dp)) {
                val strokeW = 2.6.dp.toPx()
                val innerStrokeW = 2.2.dp.toPx()
                val w = size.width
                val h = size.height
                val radius = (size.minDimension - strokeW) / 2f
                val center = Offset(w / 2f, h / 2f)

                val circleClipPath = Path().apply {
                    addOval(Rect(center = center, radius = radius))
                }

                clipPath(circleClipPath) {
                    val phoneRightX = w * 0.46f
                    val phoneTopY = h * 0.17f
                    val phoneCornerR = 6.dp.toPx()

                    val phoneRect = RoundRect(
                        left = -w * 0.15f,
                        top = phoneTopY,
                        right = phoneRightX,
                        bottom = h * 1.05f,
                        topRightCornerRadius = CornerRadius(phoneCornerR, phoneCornerR)
                    )
                    val phonePath = Path().apply { addRoundRect(phoneRect) }

                    drawPath(
                        path = phonePath,
                        color = IosPrimaryBlue.copy(alpha = 0.12f)
                    )

                    drawPath(
                        path = phonePath,
                        color = IosPrimaryBlue,
                        style = Stroke(width = innerStrokeW, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )

                    drawLine(
                        color = IosPrimaryBlue,
                        start = Offset(w * 0.08f, h * 0.28f),
                        end = Offset(w * 0.21f, h * 0.28f),
                        strokeWidth = innerStrokeW,
                        cap = StrokeCap.Round
                    )

                    // Side Button bump with animated glow when arrow approaches
                    drawRoundRect(
                        color = IosPrimaryBlue,
                        topLeft = Offset(phoneRightX - 0.5.dp.toPx(), h * 0.41f),
                        size = Size(3.4.dp.toPx(), h * 0.18f),
                        cornerRadius = CornerRadius(1.5.dp.toPx(), 1.5.dp.toPx())
                    )

                    val arrowShift = arrowOffsetPx.dp.toPx() * 0.42f
                    val arrowTipX = w * 0.56f + arrowShift
                    val arrowTailX = w * 0.84f + arrowShift
                    val arrowY = h * 0.50f
                    val headSize = w * 0.10f

                    drawLine(
                        color = IosPrimaryBlue,
                        start = Offset(arrowTailX, arrowY),
                        end = Offset(arrowTipX, arrowY),
                        strokeWidth = innerStrokeW,
                        cap = StrokeCap.Round
                    )

                    val arrowHeadPath = Path().apply {
                        moveTo(arrowTipX + headSize, arrowY - headSize * 0.82f)
                        lineTo(arrowTipX, arrowY)
                        lineTo(arrowTipX + headSize, arrowY + headSize * 0.82f)
                    }
                    drawPath(
                        path = arrowHeadPath,
                        color = IosPrimaryBlue,
                        style = Stroke(
                            width = innerStrokeW,
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )
                }

                drawCircle(
                    color = IosPrimaryBlue,
                    radius = radius,
                    center = center,
                    style = Stroke(width = strokeW)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = stringResource(R.string.confirm_with_side_button),
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.84f),
            fontSize = 16.sp,
            fontWeight = FontWeight.Normal,
            letterSpacing = (-0.2).sp
        )
    }
}

@Composable
fun DoubleClickToPaySideIndicator(
    darkTheme: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "sideBarPulse")
    val barScaleY by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(720, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "barScaleY"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(720, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    Row(
        modifier = modifier
            .liquidPressable(pressScale = 0.92f, onClick = onClick)
            .padding(end = 3.dp)
            .testTag("double_click_to_pay_side_indicator"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.End
    ) {
        Text(
            text = stringResource(R.string.double_click_to_pay_side),
            color = if (darkTheme) Color.White.copy(alpha = 0.92f) else Color(0xFF1C1C1E).copy(alpha = 0.86f),
            fontSize = 15.sp,
            lineHeight = 19.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.End
        )

        Spacer(modifier = Modifier.width(10.dp))

        Box(
            contentAlignment = Alignment.Center
        ) {
            // Outer liquid glow halo
            Box(
                modifier = Modifier
                    .width(12.dp)
                    .height(84.dp)
                    .graphicsLayer { scaleY = barScaleY }
                    .clip(RoundedCornerShape(50))
                    .background(IosPrimaryBlue.copy(alpha = glowAlpha * 0.32f))
            )
            // Inner crisp side bar pill
            Box(
                modifier = Modifier
                    .width(5.dp)
                    .height(76.dp)
                    .graphicsLayer { scaleY = barScaleY }
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (darkTheme) {
                            Color.White.copy(alpha = 0.95f)
                        } else {
                            IosPrimaryBlue
                        }
                    )
            )
        }
    }
}

@Composable
private fun FaceIdIconAndLabel() {
    val infiniteTransition = rememberInfiniteTransition(label = "faceIdPulse")
    val bracketScale by infiniteTransition.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(820, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bracketScale"
    )
    val scanLineProgress by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scanLineProgress"
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.size(74.dp),
            contentAlignment = Alignment.Center
        ) {
            // Subtle Liquid Glass radial glow behind Face ID
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                IosPrimaryBlue.copy(alpha = 0.14f),
                                Color.Transparent
                            )
                        )
                    )
            )

            Canvas(
                modifier = Modifier
                    .size(52.dp)
                    .graphicsLayer {
                        scaleX = bracketScale
                        scaleY = bracketScale
                    }
            ) {
                val strokeW = 3.2.dp.toPx()
                val w = size.width
                val h = size.height
                val cornerLen = w * 0.26f
                val radius = w * 0.17f
                val stroke = Stroke(width = strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round)

                val tlPath = Path().apply {
                    moveTo(0f, cornerLen)
                    lineTo(0f, radius)
                    arcTo(
                        rect = Rect(0f, 0f, radius * 2f, radius * 2f),
                        startAngleDegrees = 180f,
                        sweepAngleDegrees = 90f,
                        forceMoveTo = false
                    )
                    lineTo(cornerLen, 0f)
                }
                drawPath(tlPath, color = IosPrimaryBlue, style = stroke)

                val trPath = Path().apply {
                    moveTo(w - cornerLen, 0f)
                    lineTo(w - radius, 0f)
                    arcTo(
                        rect = Rect(w - radius * 2f, 0f, w, radius * 2f),
                        startAngleDegrees = 270f,
                        sweepAngleDegrees = 90f,
                        forceMoveTo = false
                    )
                    lineTo(w, cornerLen)
                }
                drawPath(trPath, color = IosPrimaryBlue, style = stroke)

                val blPath = Path().apply {
                    moveTo(0f, h - cornerLen)
                    lineTo(0f, h - radius)
                    arcTo(
                        rect = Rect(0f, h - radius * 2f, radius * 2f, h),
                        startAngleDegrees = 180f,
                        sweepAngleDegrees = -90f,
                        forceMoveTo = false
                    )
                    lineTo(cornerLen, h)
                }
                drawPath(blPath, color = IosPrimaryBlue, style = stroke)

                val brPath = Path().apply {
                    moveTo(w - cornerLen, h)
                    lineTo(w - radius, h)
                    arcTo(
                        rect = Rect(w - radius * 2f, h - radius * 2f, w, h),
                        startAngleDegrees = 90f,
                        sweepAngleDegrees = -90f,
                        forceMoveTo = false
                    )
                    lineTo(w, h - cornerLen)
                }
                drawPath(brPath, color = IosPrimaryBlue, style = stroke)

                drawLine(
                    color = IosPrimaryBlue,
                    start = Offset(w * 0.33f, h * 0.30f),
                    end = Offset(w * 0.33f, h * 0.41f),
                    strokeWidth = strokeW,
                    cap = StrokeCap.Round
                )

                drawLine(
                    color = IosPrimaryBlue,
                    start = Offset(w * 0.67f, h * 0.30f),
                    end = Offset(w * 0.67f, h * 0.41f),
                    strokeWidth = strokeW,
                    cap = StrokeCap.Round
                )

                val nosePath = Path().apply {
                    moveTo(w * 0.51f, h * 0.33f)
                    lineTo(w * 0.51f, h * 0.52f)
                    quadraticTo(w * 0.51f, h * 0.57f, w * 0.44f, h * 0.56f)
                }
                drawPath(nosePath, color = IosPrimaryBlue, style = stroke)

                drawArc(
                    color = IosPrimaryBlue,
                    startAngle = 25f,
                    sweepAngle = 130f,
                    useCenter = false,
                    topLeft = Offset(w * 0.28f, h * 0.42f),
                    size = Size(w * 0.44f, h * 0.34f),
                    style = stroke
                )

                // Subtle biometric laser shimmer line
                val scanY = h * scanLineProgress
                drawLine(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            IosPrimaryBlue.copy(alpha = 0.32f),
                            Color.Transparent
                        )
                    ),
                    start = Offset(w * 0.12f, scanY),
                    end = Offset(w * 0.88f, scanY),
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = stringResource(R.string.face_id_label),
            color = IosTextSecondaryLight,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = (-0.2).sp
        )
    }
}

@Composable
private fun DoneCheckmarkCircleAndLabel() {
    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        triggered = true
    }

    val checkProgress by animateFloatAsState(
        targetValue = if (triggered) 1f else 0f,
        animationSpec = tween(durationMillis = 420, easing = FastOutSlowInEasing),
        label = "checkmarkProgress"
    )
    val circleScale by animateFloatAsState(
        targetValue = if (triggered) 1f else 0.65f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "doneCircleScale"
    )
    val burstProgress by animateFloatAsState(
        targetValue = if (triggered) 1f else 0f,
        animationSpec = tween(durationMillis = 680, easing = FastOutSlowInEasing),
        label = "burstProgress"
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.size(80.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .size(72.dp)
                    .graphicsLayer {
                        scaleX = circleScale
                        scaleY = circleScale
                    }
            ) {
                val strokeW = 3.2.dp.toPx()
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseRadius = size.minDimension * 0.39f

                // Celebratory expanding Liquid Glass halo ring
                if (burstProgress < 0.99f) {
                    drawCircle(
                        color = IosPrimaryBlue.copy(alpha = (1f - burstProgress) * 0.45f),
                        radius = baseRadius * (1f + burstProgress * 0.42f),
                        center = center,
                        style = Stroke(width = 2.dp.toPx())
                    )
                }

                // Soft inner blue glow fill
                drawCircle(
                    color = IosPrimaryBlue.copy(alpha = 0.08f),
                    radius = baseRadius,
                    center = center
                )

                // Outer Blue Circle
                drawCircle(
                    color = IosPrimaryBlue,
                    radius = baseRadius,
                    center = center,
                    style = Stroke(width = strokeW)
                )

                val fullCheckPath = Path().apply {
                    moveTo(size.width * 0.33f, size.height * 0.52f)
                    lineTo(size.width * 0.45f, size.height * 0.64f)
                    lineTo(size.width * 0.68f, size.height * 0.38f)
                }
                val pathMeasure = PathMeasure()
                pathMeasure.setPath(fullCheckPath, false)
                val animatedCheckPath = Path()
                pathMeasure.getSegment(
                    0f,
                    pathMeasure.length * checkProgress,
                    animatedCheckPath,
                    true
                )

                drawPath(
                    path = animatedCheckPath,
                    color = IosPrimaryBlue,
                    style = Stroke(
                        width = strokeW,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = stringResource(R.string.payment_done),
            color = IosTextSecondaryLight,
            fontSize = 17.sp,
            fontWeight = FontWeight.Normal,
            letterSpacing = (-0.2).sp
        )
    }
}

@Composable
private fun NfcAnimatedWavesAndLabel(
    nfcProgress: Float = 0f
) {
    val infiniteTransition = rememberInfiniteTransition(label = "nfcWaves")
    val waveProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "waveProgress"
    )
    val orbitAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbitAngle"
    )
    val animatedProgress by animateFloatAsState(
        targetValue = nfcProgress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 120, easing = LinearEasing),
        label = "appleNfcProgress"
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.size(92.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(88.dp)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val maxRadius = size.minDimension / 2f
                val coreRadius = size.minDimension * 0.28f

                // 4 Concentric Liquid Glass expanding ripples
                for (i in 0..3) {
                    val phase = (waveProgress + i * 0.25f) % 1f
                    val radius = coreRadius + (maxRadius - coreRadius) * phase
                    val alpha = (1f - phase) * (1f - phase) * 0.72f
                    drawCircle(
                        color = IosPrimaryBlue.copy(alpha = alpha),
                        radius = radius,
                        center = center,
                        style = Stroke(width = 2.2.dp.toPx())
                    )
                }

                // Inner core liquid circle
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            IosPrimaryBlue.copy(alpha = 0.22f),
                            IosPrimaryBlue.copy(alpha = 0.08f)
                        ),
                        center = center,
                        radius = coreRadius
                    ),
                    radius = coreRadius,
                    center = center
                )
                drawCircle(
                    color = IosPrimaryBlue.copy(alpha = 0.30f),
                    radius = coreRadius,
                    center = center,
                    style = Stroke(width = 2.2.dp.toPx())
                )



                // Rotating orbital highlight arc
                drawArc(
                    color = Color.White.copy(alpha = 0.55f),
                    startAngle = orbitAngle,
                    sweepAngle = 55f,
                    useCenter = false,
                    topLeft = Offset(center.x - coreRadius, center.y - coreRadius),
                    size = Size(coreRadius * 2f, coreRadius * 2f),
                    style = Stroke(width = 2.0.dp.toPx(), cap = StrokeCap.Round)
                )

                // Sequential lighting contactless wave arcs inside core
                val activeWaveIndex = ((waveProgress * 3f).toInt()) % 3
                for (arcIdx in 0..2) {
                    val arcSize = (9 + arcIdx * 7).dp.toPx()
                    val isLit = arcIdx <= activeWaveIndex
                    drawArc(
                        color = IosPrimaryBlue.copy(alpha = if (isLit) 1.0f else 0.35f),
                        startAngle = -42f,
                        sweepAngle = 84f,
                        useCenter = false,
                        topLeft = Offset(
                            center.x - arcSize / 2f - 2.dp.toPx(),
                            center.y - arcSize / 2f
                        ),
                        size = Size(arcSize, arcSize),
                        style = Stroke(width = 2.1.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = stringResource(R.string.hold_near_reader),
            color = IosTextSecondaryLight,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = (-0.2).sp
        )
    }
}

@Composable
private fun ApplePayDeclinedCircleAndLabel() {
    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        triggered = true
    }

    val crossProgress by animateFloatAsState(
        targetValue = if (triggered) 1f else 0f,
        animationSpec = tween(durationMillis = 420, easing = FastOutSlowInEasing),
        label = "declineCrossProgress"
    )
    val circleScale by animateFloatAsState(
        targetValue = if (triggered) 1f else 0.65f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "declineCircleScale"
    )
    val burstProgress by animateFloatAsState(
        targetValue = if (triggered) 1f else 0f,
        animationSpec = tween(durationMillis = 680, easing = FastOutSlowInEasing),
        label = "declineBurstProgress"
    )

    val declineRed = Color(0xFFFF3B30)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.size(80.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .size(72.dp)
                    .graphicsLayer {
                        scaleX = circleScale
                        scaleY = circleScale
                    }
            ) {
                val strokeW = 3.2.dp.toPx()
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseRadius = size.minDimension * 0.39f

                // Celebratory/error expanding halo ring
                if (burstProgress < 0.99f) {
                    drawCircle(
                        color = declineRed.copy(alpha = (1f - burstProgress) * 0.50f),
                        radius = baseRadius * (1f + burstProgress * 0.42f),
                        center = center,
                        style = Stroke(width = 2.2.dp.toPx())
                    )
                }

                // Soft inner red glow fill
                drawCircle(
                    color = declineRed.copy(alpha = 0.10f),
                    radius = baseRadius,
                    center = center
                )

                // Outer Red Circle
                drawCircle(
                    color = declineRed,
                    radius = baseRadius,
                    center = center,
                    style = Stroke(width = strokeW)
                )

                // Animated Red 'X'
                val crossArm = baseRadius * 0.44f
                val p1 = Path().apply {
                    moveTo(center.x - crossArm, center.y - crossArm)
                    lineTo(center.x + crossArm, center.y + crossArm)
                }
                val p2 = Path().apply {
                    moveTo(center.x + crossArm, center.y - crossArm)
                    lineTo(center.x - crossArm, center.y + crossArm)
                }

                val pm1 = PathMeasure().apply { setPath(p1, false) }
                val seg1 = Path()
                pm1.getSegment(0f, pm1.length * crossProgress, seg1, true)
                drawPath(
                    path = seg1,
                    color = declineRed,
                    style = Stroke(width = strokeW, cap = StrokeCap.Round)
                )

                if (crossProgress > 0.45f) {
                    val p2Progress = ((crossProgress - 0.45f) / 0.55f).coerceIn(0f, 1f)
                    val pm2 = PathMeasure().apply { setPath(p2, false) }
                    val seg2 = Path()
                    pm2.getSegment(0f, pm2.length * p2Progress, seg2, true)
                    drawPath(
                        path = seg2,
                        color = declineRed,
                        style = Stroke(width = strokeW, cap = StrokeCap.Round)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Payment Not Completed",
            color = declineRed,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = (-0.2).sp
        )
    }
}

@Composable
private fun ProcessingSpinnerAndLabel() {
    val infiniteTransition = rememberInfiniteTransition(label = "spinner")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(750, easing = LinearEasing)
        ),
        label = "spinnerAngle"
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.size(68.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(56.dp)) {
                val strokeW = 3.2.dp.toPx()
                drawCircle(
                    color = IosPrimaryBlue.copy(alpha = 0.2f),
                    style = Stroke(width = strokeW)
                )
                drawArc(
                    color = IosPrimaryBlue,
                    startAngle = angle,
                    sweepAngle = 110f,
                    useCenter = false,
                    style = Stroke(width = strokeW, cap = StrokeCap.Round)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = stringResource(R.string.payment_processing),
            color = IosTextSecondaryLight,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
