package com.example.hardware

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class HapticAndSoundEngine(context: Context) {
    private val appContext = context.applicationContext
    private val audioScope = CoroutineScope(Dispatchers.IO)

    private val vibrator: Vibrator? by lazy {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                manager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        } catch (_: Exception) {
            null
        }
    }

    fun performCardTick(enabled: Boolean = true) {
        if (!enabled) return
        vibrateWaveform(longArrayOf(0, 9), intArrayOf(0, 95))
    }

    fun performCardSnap(enabled: Boolean = true) {
        if (!enabled) return
        vibrateWaveform(longArrayOf(0, 14, 30, 10), intArrayOf(0, 170, 0, 90))
    }

    fun performFaceIdScanPulse(enabled: Boolean = true) {
        if (!enabled) return
        vibrateWaveform(longArrayOf(0, 12, 45, 16), intArrayOf(0, 110, 0, 150))
    }

    fun performNfcRadarPulse(enabled: Boolean = true) {
        if (!enabled) return
        vibrateWaveform(longArrayOf(0, 8), intArrayOf(0, 65))
    }

    fun performPaymentSuccess(
        hapticsEnabled: Boolean = true,
        soundEnabled: Boolean = true,
        isGoogleWalletTheme: Boolean = false,
        customSoundPath: String? = null
    ) {
        if (hapticsEnabled) {
            if (isGoogleWalletTheme) {
                vibrateWaveform(longArrayOf(0, 14, 50, 26, 40, 18), intArrayOf(0, 160, 0, 240, 0, 180))
            } else {
                vibrateWaveform(longArrayOf(0, 18, 65, 32), intArrayOf(0, 190, 0, 255))
            }
        }
        if (soundEnabled) {
            audioScope.launch {
                playThemePaymentSound(
                    isGoogleWalletTheme = isGoogleWalletTheme,
                    customSoundPath = customSoundPath
                )
            }
        }
    }

    fun performApplePaySuccess(
        hapticsEnabled: Boolean = true,
        soundEnabled: Boolean = true,
        customSoundPath: String? = null
    ) {
        performPaymentSuccess(
            hapticsEnabled = hapticsEnabled,
            soundEnabled = soundEnabled,
            isGoogleWalletTheme = false,
            customSoundPath = customSoundPath
        )
    }

    fun performErrorShake(enabled: Boolean = true) {
        if (!enabled) return
        vibrateWaveform(longArrayOf(0, 22, 40, 22, 40, 28), intArrayOf(0, 220, 0, 220, 0, 255))
    }

    fun performPaymentDeclined(
        hapticsEnabled: Boolean = true,
        soundEnabled: Boolean = true
    ) {
        if (hapticsEnabled) {
            vibrateWaveform(longArrayOf(0, 45, 60, 55, 60, 65), intArrayOf(0, 240, 0, 255, 0, 255))
        }
        if (soundEnabled) {
            audioScope.launch {
                playDeclineBuzzerSound()
            }
        }
    }

    private fun vibrateWaveform(timings: LongArray, amplitudes: IntArray) {
        try {
            val vib = vibrator ?: return
            if (!vib.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = if (vib.hasAmplitudeControl()) {
                    VibrationEffect.createWaveform(timings, amplitudes, -1)
                } else {
                    VibrationEffect.createOneShot(timings.sum().coerceAtLeast(10L), VibrationEffect.DEFAULT_AMPLITUDE)
                }
                vib.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(15L)
            }
        } catch (_: Exception) {
        }
    }

    /**
     * Plays the theme-specific payment sound:
     * - If the current theme has a saved custom audio file (`customSoundPath`), plays that file.
     * - Otherwise, plays the built-in Apple Pay chime (`R.raw.apple_pay_chime`) for Apple Pay theme,
     *   or the distinct Google Wallet harmonic chime for Google Wallet theme.
     */
    fun playThemePaymentSound(
        isGoogleWalletTheme: Boolean,
        customSoundPath: String? = null
    ) {
        try {
            val customFile = customSoundPath?.let { File(it) }
            if (customFile != null && customFile.exists() && customFile.length() > 0L) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()

                val mediaPlayer = MediaPlayer()
                mediaPlayer.setAudioAttributes(attrs)
                mediaPlayer.setDataSource(appContext, Uri.fromFile(customFile))
                mediaPlayer.prepare()
                mediaPlayer.setVolume(1.0f, 1.0f)
                mediaPlayer.setOnCompletionListener { mp ->
                    try {
                        mp.release()
                    } catch (_: Exception) {
                    }
                }
                mediaPlayer.start()
                return
            }

            if (isGoogleWalletTheme) {
                playSynthesizedGoogleWalletChime()
            } else {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()

                val mediaPlayer = MediaPlayer()
                mediaPlayer.setAudioAttributes(attrs)
                val afd = appContext.resources.openRawResourceFd(R.raw.apple_pay_chime) ?: return
                mediaPlayer.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                mediaPlayer.prepare()
                mediaPlayer.setVolume(1.0f, 1.0f)
                mediaPlayer.setOnCompletionListener { mp ->
                    try {
                        mp.release()
                    } catch (_: Exception) {
                    }
                }
                mediaPlayer.start()
            }
        } catch (_: Exception) {
        }
    }

    /**
     * Synthesizes a bright, cheerful Google Wallet / Google Pay 3-note ascending marimba-bell chime
     * (D6 -> F#6 -> A6 harmonic triad) so Google Wallet has its own unmistakable default payment sound.
     */
    private fun playSynthesizedGoogleWalletChime() {
        try {
            val sampleRate = 44100
            val durationSec = 0.72
            val numSamples = (sampleRate * durationSec).toInt()
            val pcm = ShortArray(numSamples)

            val note1Freq = 1174.66 // D6
            val note2Freq = 1479.98 // F#6
            val note3Freq = 1760.00 // A6

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                var sample = 0.0

                // Note 1 at t = 0.00s
                if (t >= 0.0) {
                    val dt = t
                    val env = exp(-dt * 9.5) * (1.0 - exp(-dt * 140.0))
                    sample += env * (0.55 * sin(2.0 * PI * note1Freq * dt) + 0.18 * sin(4.0 * PI * note1Freq * dt))
                }
                // Note 2 at t = 0.085s
                if (t >= 0.085) {
                    val dt = t - 0.085
                    val env = exp(-dt * 8.5) * (1.0 - exp(-dt * 140.0))
                    sample += env * (0.58 * sin(2.0 * PI * note2Freq * dt) + 0.20 * sin(4.0 * PI * note2Freq * dt))
                }
                // Note 3 at t = 0.175s (warm sustained bell)
                if (t >= 0.175) {
                    val dt = t - 0.175
                    val env = exp(-dt * 5.2) * (1.0 - exp(-dt * 150.0))
                    sample += env * (0.68 * sin(2.0 * PI * note3Freq * dt) + 0.24 * sin(4.0 * PI * note3Freq * dt))
                }

                val clamped = (sample * 0.65).coerceIn(-0.98, 0.98)
                pcm[i] = (clamped * Short.MAX_VALUE).toInt().toShort()
            }

            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()

            val format = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            val track = AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(format)
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(pcm, 0, pcm.size)
            track.play()
        } catch (_: Exception) {
        }
    }

    /**
     * Synthesizes an unmistakable POS payment declined double-buzz tone (240Hz / 180Hz)
     * for realistic simulation of declined payments.
     */
    private fun playDeclineBuzzerSound() {
        try {
            val sampleRate = 44100
            val durationSec = 0.52
            val numSamples = (sampleRate * durationSec).toInt()
            val pcm = ShortArray(numSamples)

            val freq1 = 260.0
            val freq2 = 195.0

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                var sample = 0.0

                // Pulse 1 at t = 0..0.18s
                if (t in 0.0..0.18) {
                    val dt = t
                    val env = (1.0 - exp(-dt * 60.0)) * exp(-dt * 4.5)
                    sample += env * (0.75 * sin(2.0 * PI * freq1 * dt) + 0.35 * sin(4.0 * PI * freq1 * dt))
                }
                // Pulse 2 at t = 0.24..0.48s (lower tone)
                if (t in 0.24..0.48) {
                    val dt = t - 0.24
                    val env = (1.0 - exp(-dt * 60.0)) * exp(-dt * 4.5)
                    sample += env * (0.80 * sin(2.0 * PI * freq2 * dt) + 0.40 * sin(4.0 * PI * freq2 * dt))
                }

                val clamped = (sample * 0.70).coerceIn(-0.98, 0.98)
                pcm[i] = (clamped * Short.MAX_VALUE).toInt().toShort()
            }

            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()

            val format = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            val track = AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(format)
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(pcm, 0, pcm.size)
            track.play()
        } catch (_: Exception) {
        }
    }
}

