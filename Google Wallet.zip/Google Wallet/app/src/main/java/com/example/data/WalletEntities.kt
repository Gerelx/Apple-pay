package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wallet_cards")
data class WalletCardEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val arabicSubtitle: String = "",
    val cardHolderName: String = "ALEXANDER MERCER",
    val lastFourDigits: String = "1234",
    val expiryDate: String = "08/29",
    val cvv: String = "892",
    val network: String = "VISA", // VISA, MASTERCARD, MADA_VISA, VIRTUAL_MC
    val presetStyle: String = "ALRAJHI_BLUE",
    val primaryColorHex: Long = 0xFF0047BAL,
    val secondaryColorHex: Long = 0xFF002E80L,
    val accentColorHex: Long = 0xFFFFFFFFL,
    val customImagePath: String? = null,
    val purePhotoMode: Boolean = false,
    val balanceDisplay: String = "$18,450.00",
    val stackGroup: String = "MAIN",
    val sortOrder: Int = 0,
    val isDefaultCard: Boolean = false
)

@Entity(tableName = "wallet_transactions")
data class WalletTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val cardId: Int,
    val merchantName: String,
    val locationOrCategory: String,
    val amountText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "Approved • Apple Pay"
)
