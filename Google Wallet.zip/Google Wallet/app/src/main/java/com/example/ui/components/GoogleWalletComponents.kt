package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File

val GoogleBluePrimary = Color(0xFF0B57D0)
val GoogleBrightBlue = Color(0xFF1A73E8)
val GoogleNavyDark = Color(0xFF041E49)
val GoogleLightBluePill = Color(0xFFD3E3FD)
val GoogleLightBlueRing = Color(0xFFD2E3FC)
val GoogleAvatarAmber = Color(0xFFF9AB00)

/**
 * Top Bar for Google Wallet Theme:
 * - Left side: Button like Google to Add Card (customizable Google Wallet icon/name + "+ Add card" pill)
 * - Right side: Customizable Google Account Profile Picture with 4-color Google ring that opens General Settings
 */
@Composable
fun GoogleWalletHeaderBar(
    darkTheme: Boolean,
    appName: String = "Google Wallet",
    customAppIconPath: String? = null,
    googleProfilePhotoPath: String?,
    isPayingOrDone: Boolean,
    onAddCardClick: () -> Unit,
    onGoogleProfileSettingsClick: () -> Unit,
    onCancelPaymentClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isPayingOrDone) {
            // Matching Image 5: top-left 'X' and top-right '⋮' when in active payment / Done state
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .liquidPressable(pressScale = 0.88f, onClick = onCancelPaymentClick)
                    .testTag("google_wallet_close_pay_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close payment",
                    tint = if (darkTheme) Color.White else Color(0xFF1F1F1F),
                    modifier = Modifier.size(24.dp)
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .liquidPressable(pressScale = 0.88f, onClick = onGoogleProfileSettingsClick),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Settings",
                        tint = if (darkTheme) Color.White else Color(0xFF1F1F1F),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        } else {
            // Left Side: Google Wallet Title + Add Card Pill Button
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .liquidPressable(pressScale = 0.93f, onClick = onAddCardClick)
                    .padding(vertical = 4.dp, horizontal = 4.dp)
                    .testTag("google_wallet_left_add_card_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ThemeAppIconBadge(
                    isGoogleWallet = true,
                    customIconPath = customAppIconPath,
                    size = 30.dp
                )

                val headerTitle = if (appName.equals("Google Wallet", ignoreCase = true) || appName.isBlank()) {
                    "Wallet"
                } else {
                    appName
                }

                Text(
                    text = headerTitle,
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = (-0.2).sp,
                    color = if (darkTheme) Color(0xFFE3E3E3) else Color(0xFF1F1F1F)
                )

                // Google "+ Add to Wallet" Pill on the left side
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            if (darkTheme) Color(0xFF0842A0) else GoogleLightBluePill
                        )
                        .border(
                            width = 1.dp,
                            color = if (darkTheme) Color(0xFF8AB4F8).copy(alpha = 0.35f) else Color.White.copy(alpha = 0.8f),
                            shape = RoundedCornerShape(18.dp)
                        )
                        .padding(horizontal = 11.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add card",
                        tint = if (darkTheme) Color(0xFFD3E3FD) else GoogleNavyDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Add card",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (darkTheme) Color(0xFFD3E3FD) else GoogleNavyDark
                    )
                }
            }

            // Right Side: Customizable Google Profile Picture (opens General Settings when clicked)
            GoogleProfileAvatarButton(
                photoPath = googleProfilePhotoPath,
                size = 42.dp,
                onClick = onGoogleProfileSettingsClick,
                modifier = Modifier.testTag("google_profile_settings_button")
            )
        }
    }
}

/**
 * Renders the customizable Google Account profile picture circle with the authentic 4-color
 * Google ring (#4285F4, #EA4335, #FBBC04, #34A853).
 * Shows user-imported photo if set, or the classic Google "J" amber avatar from the reference photos.
 */
@Composable
fun GoogleProfileAvatarButton(
    photoPath: String?,
    size: Dp = 42.dp,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val imageModel = remember(photoPath) {
        if (photoPath.isNullOrBlank()) {
            null
        } else if (photoPath.startsWith("content://") || photoPath.startsWith("file://") || photoPath.startsWith("http")) {
            Uri.parse(photoPath)
        } else {
            File(photoPath)
        }
    }

    Box(
        modifier = modifier
            .size(size)
            .liquidPressable(pressScale = 0.86f, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        // Authentic 4-Color Google Account Ring
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeW = 2.2.dp.toPx()
            val inset = strokeW / 2f
            val arcSize = Size(this.size.width - strokeW, this.size.height - strokeW)
            val topLeft = Offset(inset, inset)
            val stroke = Stroke(width = strokeW, cap = StrokeCap.Round)

            // Red top-left
            drawArc(
                color = Color(0xFFEA4335),
                startAngle = 195f,
                sweepAngle = 75f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = stroke
            )
            // Blue top-right & right
            drawArc(
                color = Color(0xFF4285F4),
                startAngle = 280f,
                sweepAngle = 100f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = stroke
            )
            // Green bottom-right
            drawArc(
                color = Color(0xFF34A853),
                startAngle = 30f,
                sweepAngle = 80f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = stroke
            )
            // Yellow bottom-left
            drawArc(
                color = Color(0xFFFBBC04),
                startAngle = 120f,
                sweepAngle = 65f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = stroke
            )
        }

        val innerSize = size - 6.dp
        if (imageModel != null) {
            AsyncImage(
                model = imageModel,
                contentDescription = "Google Profile Picture Settings",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(innerSize)
                    .clip(CircleShape)
            )
        } else {
            // Default Google Account amber circle with "J" (exact match to uploaded Images 3 & 4)
            Box(
                modifier = Modifier
                    .size(innerSize)
                    .background(GoogleAvatarAmber, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "J",
                    color = Color.White,
                    fontSize = (innerSize.value * 0.48f).sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

/**
 * Official 4-color Google Wallet layered card icon (Green, Yellow, Red, Blue).
 */
@Composable
fun GoogleWalletLogoIcon(
    size: Dp = 28.dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val r = w * 0.22f

        // 1. Top Green card layer (#34A853)
        drawRoundRect(
            color = Color(0xFF34A853),
            topLeft = Offset(w * 0.06f, h * 0.08f),
            size = Size(w * 0.88f, h * 0.45f),
            cornerRadius = CornerRadius(r, r)
        )
        // 2. Second Yellow card layer (#FBBC04)
        drawRoundRect(
            color = Color(0xFFFBBC04),
            topLeft = Offset(w * 0.06f, h * 0.22f),
            size = Size(w * 0.88f, h * 0.45f),
            cornerRadius = CornerRadius(r, r)
        )
        // 3. Third Red card layer (#EA4335)
        drawRoundRect(
            color = Color(0xFFEA4335),
            topLeft = Offset(w * 0.06f, h * 0.36f),
            size = Size(w * 0.88f, h * 0.45f),
            cornerRadius = CornerRadius(r, r)
        )
        // 4. Front Blue wallet pocket (#4285F4) with curved dip in the top edge
        val pocketPath = Path().apply {
            moveTo(w * 0.06f, h * 0.48f)
            lineTo(w * 0.36f, h * 0.48f)
            quadraticTo(w * 0.56f, h * 0.64f, w * 0.94f, h * 0.46f)
            lineTo(w * 0.94f, h * 0.76f)
            quadraticTo(w * 0.94f, h * 0.92f, w * 0.76f, h * 0.92f)
            lineTo(w * 0.24f, h * 0.92f)
            quadraticTo(w * 0.06f, h * 0.92f, w * 0.06f, h * 0.76f)
            close()
        }
        drawPath(path = pocketPath, color = Color(0xFF4285F4))
    }
}

/**
 * Renders the top-center Google Wallet Contactless Circle (Images 1-4) and the
 * Google Wallet Blue Done Checkmark Circle (Image 5) above the horizontal card carousel,
 * with a smooth 7-second NFC progress arc and animated contactless energy waves.
 */
@Composable
fun GoogleWalletNfcAndDoneStage(
    stage: PaymentStage,
    nfcProgress: Float = 0f,
    nfcSecondsRemaining: Int = 7,
    darkTheme: Boolean,
    onTapCircle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .liquidPressable(
                enabled = stage == PaymentStage.FACE_ID_SCANNING,
                pressScale = 0.91f,
                onClick = onTapCircle
            )
            .testTag("google_wallet_nfc_stage"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnimatedContent(
            targetState = stage,
            transitionSpec = {
                (fadeIn(tween(240)) +
                    scaleIn(
                        initialScale = 0.70f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioLowBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        )
                    )) togetherWith
                    (fadeOut(tween(150)) + scaleOut(targetScale = 0.85f))
            },
            label = "googleWalletStageTransition"
        ) { currentStage ->
            when (currentStage) {
                PaymentStage.DONE -> {
                    GoogleWalletBlueDoneCheckmark(darkTheme = darkTheme)
                }
                PaymentStage.DECLINED -> {
                    GoogleWalletRedDeclineCross(darkTheme = darkTheme)
                }
                PaymentStage.NFC_HOLD_NEAR_READER, PaymentStage.PROCESSING -> {
                    GoogleWalletContactlessCircle(
                        isActivelyTransmitting = true,
                        nfcProgress = nfcProgress,
                        darkTheme = darkTheme
                    )
                }
                PaymentStage.FACE_ID_SCANNING -> {
                    GoogleWalletContactlessCircle(
                        isActivelyTransmitting = false,
                        nfcProgress = 0f,
                        darkTheme = darkTheme
                    )
                }
            }
        }
    }
}

/**
 * Exact Google Wallet Contactless Symbol inside the light-blue ring (Images 1, 2, 3, 4).
 * When `isActivelyTransmitting` is true (during the NFC contactless payment):
 * - Card swiping is locked
 * - 4 contactless wave arcs animate in sequence
 * - Expanding Google Blue radar rings pulse outward
 * - A 360-degree Google Blue progress ring sweeps smoothly
 */
@Composable
private fun GoogleWalletContactlessCircle(
    isActivelyTransmitting: Boolean,
    nfcProgress: Float,
    darkTheme: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition(label = "googleNfcPulse")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isActivelyTransmitting) 950 else 2400,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "googleWavePhase"
    )
    val breatheScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isActivelyTransmitting) 1.08f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(680, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "googleBreatheScale"
    )

    val animatedProgress by animateFloatAsState(
        targetValue = nfcProgress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 120, easing = LinearEasing),
        label = "googleNfcSmoothProgress"
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.size(104.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .size(100.dp)
                    .graphicsLayer {
                        scaleX = breatheScale
                        scaleY = breatheScale
                    }
            ) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val circleRadius = 34.dp.toPx()

                // Expanding Google Blue radar ripples during NFC transmission
                if (isActivelyTransmitting) {
                    for (i in 0..3) {
                        val phase = (wavePhase + i * 0.25f) % 1f
                        val r = circleRadius + (size.minDimension / 2f - circleRadius) * phase
                        val alpha = (1f - phase) * (1f - phase) * 0.72f
                        drawCircle(
                            color = GoogleBrightBlue.copy(alpha = alpha),
                            radius = r,
                            center = center,
                            style = Stroke(width = 2.4.dp.toPx())
                        )
                    }
                }

                // Soft elevated surface fill inside circle
                drawCircle(
                    color = if (darkTheme) Color(0xFF1E1F22) else Color.White,
                    radius = circleRadius,
                    center = center
                )

                // Outer base light-blue ring
                drawCircle(
                    color = if (darkTheme) {
                        Color(0xFF444746)
                    } else {
                        GoogleLightBlueRing
                    },
                    radius = circleRadius,
                    center = center,
                    style = Stroke(width = 2.5.dp.toPx())
                )



                // 4 Curved Contactless Wave Arcs inside the circle
                val waveOrigin = Offset(center.x - 11.dp.toPx(), center.y)
                val activeArcCount = if (isActivelyTransmitting) {
                    ((wavePhase * 4f).toInt() % 4) + 1
                } else {
                    4
                }

                val waveColor = if (darkTheme) Color(0xFFA8C7FA) else Color(0xFF062E6F)
                for (i in 0..3) {
                    val arcRadius = (6.5f + i * 5.2f).dp.toPx()
                    val isLit = i < activeArcCount
                    drawArc(
                        color = if (isActivelyTransmitting && isLit) {
                            GoogleBrightBlue
                        } else {
                            waveColor.copy(alpha = if (isLit) 1f else 0.25f)
                        },
                        startAngle = -36f,
                        sweepAngle = 72f,
                        useCenter = false,
                        topLeft = Offset(waveOrigin.x - arcRadius, waveOrigin.y - arcRadius),
                        size = Size(arcRadius * 2f, arcRadius * 2f),
                        style = Stroke(width = 2.7.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
        }

        if (isActivelyTransmitting) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (darkTheme) Color(0xFF0842A0).copy(alpha = 0.55f) else GoogleLightBluePill.copy(alpha = 0.85f)
                    )
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = if (darkTheme) Color(0xFFA8C7FA) else GoogleBluePrimary,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = "Hold to reader",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (darkTheme) Color(0xFFD3E3FD) else GoogleBluePrimary
                )
            }
        }
    }
}

/**
 * Exact Google Wallet Blue Done Checkmark Circle from Image 5:
 * Elevated white/frosted circle with a soft blue ring, celebratory shockwave burst,
 * and an animated Google Blue/Navy checkmark.
 */
@Composable
private fun GoogleWalletBlueDoneCheckmark(
    darkTheme: Boolean
) {
    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        triggered = true
    }

    val checkProgress by animateFloatAsState(
        targetValue = if (triggered) 1f else 0f,
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "googleDoneCheckProgress"
    )
    val circleScale by animateFloatAsState(
        targetValue = if (triggered) 1f else 0.62f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "googleDoneScale"
    )
    val shockwaveProgress by animateFloatAsState(
        targetValue = if (triggered) 1f else 0f,
        animationSpec = tween(durationMillis = 720, easing = FastOutSlowInEasing),
        label = "googleDoneShockwave"
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(104.dp)
                .graphicsLayer {
                    scaleX = circleScale
                    scaleY = circleScale
                },
            contentAlignment = Alignment.Center
        ) {
            // Celebratory Google Blue expanding shockwave ring
            Canvas(modifier = Modifier.fillMaxSize()) {
                if (shockwaveProgress < 0.99f) {
                    val baseR = 36.dp.toPx()
                    drawCircle(
                        color = GoogleBrightBlue.copy(alpha = (1f - shockwaveProgress) * 0.55f),
                        radius = baseR * (1f + shockwaveProgress * 0.45f),
                        center = Offset(size.width / 2f, size.height / 2f),
                        style = Stroke(width = 2.8.dp.toPx())
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(74.dp)
                    .shadow(
                        elevation = 10.dp,
                        shape = CircleShape,
                        ambientColor = GoogleBrightBlue.copy(alpha = 0.28f),
                        spotColor = GoogleBrightBlue.copy(alpha = 0.36f)
                    )
                    .clip(CircleShape)
                    .background(if (darkTheme) Color(0xFF1E1F22) else Color.White)
                    .border(
                        width = 2.2.dp,
                        color = if (darkTheme) GoogleBrightBlue else GoogleLightBlueRing,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(38.dp)) {
                    val checkPath = Path().apply {
                        moveTo(size.width * 0.16f, size.height * 0.54f)
                        lineTo(size.width * 0.40f, size.height * 0.76f)
                        lineTo(size.width * 0.85f, size.height * 0.26f)
                    }
                    val pathMeasure = PathMeasure()
                    pathMeasure.setPath(checkPath, false)
                    val animatedSegment = Path()
                    pathMeasure.getSegment(
                        0f,
                        pathMeasure.length * checkProgress,
                        animatedSegment,
                        true
                    )

                    drawPath(
                        path = animatedSegment,
                        color = if (darkTheme) Color(0xFF8AB4F8) else GoogleBluePrimary,
                        style = Stroke(
                            width = 3.5.dp.toPx(),
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )
                }
            }
        }
    }
}

/**
 * Google Wallet Payment Declined Red Cross Circle:
 * Shows a red expanding shockwave ring and animated Red 'X' when payment is declined.
 */
@Composable
private fun GoogleWalletRedDeclineCross(
    darkTheme: Boolean
) {
    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        triggered = true
    }

    val crossProgress by animateFloatAsState(
        targetValue = if (triggered) 1f else 0f,
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "googleDeclineCrossProgress"
    )
    val circleScale by animateFloatAsState(
        targetValue = if (triggered) 1f else 0.62f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "googleDeclineScale"
    )
    val shockwaveProgress by animateFloatAsState(
        targetValue = if (triggered) 1f else 0f,
        animationSpec = tween(durationMillis = 720, easing = FastOutSlowInEasing),
        label = "googleDeclineShockwave"
    )

    val declineRed = Color(0xFFD93025)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(104.dp)
                .graphicsLayer {
                    scaleX = circleScale
                    scaleY = circleScale
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                if (shockwaveProgress < 0.99f) {
                    val baseR = 36.dp.toPx()
                    drawCircle(
                        color = declineRed.copy(alpha = (1f - shockwaveProgress) * 0.55f),
                        radius = baseR * (1f + shockwaveProgress * 0.45f),
                        center = Offset(size.width / 2f, size.height / 2f),
                        style = Stroke(width = 2.8.dp.toPx())
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(74.dp)
                    .shadow(
                        elevation = 10.dp,
                        shape = CircleShape,
                        ambientColor = declineRed.copy(alpha = 0.28f),
                        spotColor = declineRed.copy(alpha = 0.36f)
                    )
                    .clip(CircleShape)
                    .background(if (darkTheme) Color(0xFF1E1F22) else Color.White)
                    .border(
                        width = 2.2.dp,
                        color = declineRed.copy(alpha = 0.75f),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(34.dp)) {
                    val strokeW = 3.6.dp.toPx()
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val arm = size.width * 0.38f

                    val p1 = Path().apply {
                        moveTo(center.x - arm, center.y - arm)
                        lineTo(center.x + arm, center.y + arm)
                    }
                    val p2 = Path().apply {
                        moveTo(center.x + arm, center.y - arm)
                        lineTo(center.x - arm, center.y + arm)
                    }

                    val pm1 = PathMeasure().apply { setPath(p1, false) }
                    val seg1 = Path()
                    pm1.getSegment(0f, pm1.length * crossProgress, seg1, true)
                    drawPath(path = seg1, color = declineRed, style = Stroke(width = strokeW, cap = StrokeCap.Round))

                    if (crossProgress > 0.45f) {
                        val p2Progress = ((crossProgress - 0.45f) / 0.55f).coerceIn(0f, 1f)
                        val pm2 = PathMeasure().apply { setPath(p2, false) }
                        val seg2 = Path()
                        pm2.getSegment(0f, pm2.length * p2Progress, seg2, true)
                        drawPath(path = seg2, color = declineRed, style = Stroke(width = strokeW, cap = StrokeCap.Round))
                    }
                }
            }
        }
    }
}

/**
 * Renders the large concentric Google Blue background rings behind the card during active NFC / Done
 * exactly as seen in uploaded Image 5 (`Enable-these-settings-and-Google-Wallet...jpg`).
 */
@Composable
fun GoogleWalletConcentricBlueBackdrop(
    visible: Boolean,
    isDone: Boolean,
    modifier: Modifier = Modifier
) {
    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(durationMillis = 360),
        label = "backdropAlpha"
    )
    if (alpha <= 0.01f) return

    val infiniteTransition = rememberInfiniteTransition(label = "googleRingsBackdrop")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1050, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ringPulse"
    )
    val doneScale by animateFloatAsState(
        targetValue = if (isDone) 1.08f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "doneBackdropScale"
    )

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer {
                this.alpha = alpha
                scaleX = (if (isDone) 1.0f else pulse) * doneScale
                scaleY = (if (isDone) 1.0f else pulse) * doneScale
            }
    ) {
        val center = Offset(size.width / 2f, size.height * 0.45f)
        val maxR = size.width * 0.68f

        // 1. Outermost pale blue aura (#E8F0FE)
        drawCircle(
            color = Color(0xFFE8F0FE).copy(alpha = 0.42f),
            radius = maxR * 1.12f,
            center = center
        )
        // 2. Outer soft pale blue ring (#D2E3FC)
        drawCircle(
            color = Color(0xFFD2E3FC).copy(alpha = 0.54f),
            radius = maxR,
            center = center
        )
        // 3. Middle sky blue ring (#8AB4F8)
        drawCircle(
            color = Color(0xFF8AB4F8).copy(alpha = 0.58f),
            radius = maxR * 0.80f,
            center = center
        )
        // 4. Inner vibrant Google Blue ring (#1A73E8)
        drawCircle(
            color = Color(0xFF1A73E8).copy(alpha = 0.72f),
            radius = maxR * 0.62f,
            center = center
        )
    }
}
