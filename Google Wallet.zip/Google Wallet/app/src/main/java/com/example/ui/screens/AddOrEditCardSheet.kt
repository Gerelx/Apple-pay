package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.WalletCardEntity
import com.example.hardware.rememberDeviceTiltOffset
import com.example.ui.components.LiquidGlassButton
import com.example.ui.components.LiquidGlassSecondaryButton
import com.example.ui.components.WalletCardArtwork
import com.example.ui.components.liquidGlassSurface
import com.example.ui.components.liquidPressable
import com.example.ui.theme.IosPrimaryBlue

data class CardColorChoice(
    val label: String,
    val primaryHex: Long,
    val secondaryHex: Long
)

private val cardColorChoices = listOf(
    CardColorChoice("Titanium Black", 0xFF0D0E11L, 0xFF1C1D24L),
    CardColorChoice("Midnight Blue", 0xFF0A2540L, 0xFF123B64L),
    CardColorChoice("Emerald Green", 0xFF0B3B24L, 0xFF135D3BL),
    CardColorChoice("Imperial Purple", 0xFF2D0B44L, 0xFF4A186DL),
    CardColorChoice("Crimson Burgundy", 0xFF3D0C18L, 0xFF611728L),
    CardColorChoice("Champagne Gold", 0xFFC5A059L, 0xFFE0C588L),
    CardColorChoice("Brushed Silver", 0xFFD8D9DDL, 0xFFAEB1B7L)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddOrEditCardSheet(
    editingCard: WalletCardEntity?,
    importedPhotoPath: String?,
    darkTheme: Boolean = false,
    onPickFromCameraRoll: () -> Unit,
    onPickFromLocalFiles: () -> Unit,
    onClearImportedPhoto: () -> Unit,
    onSaveCard: (
        title: String,
        arabicSubtitle: String,
        cardHolderName: String,
        lastFourDigits: String,
        network: String,
        presetStyle: String,
        primaryColorHex: Long,
        secondaryColorHex: Long,
        customImagePath: String?,
        purePhotoMode: Boolean,
        balanceDisplay: String
    ) -> Unit,
    onDeleteCard: ((Int) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val deviceTilt by rememberDeviceTiltOffset()

    var title by remember(editingCard) { mutableStateOf(editingCard?.title ?: "") }
    var arabicSubtitle by remember(editingCard) { mutableStateOf(editingCard?.arabicSubtitle ?: "") }
    var cardHolderName by remember(editingCard) { mutableStateOf(editingCard?.cardHolderName ?: "") }
    var lastFourDigits by remember(editingCard) { mutableStateOf(editingCard?.lastFourDigits ?: "") }
    var network by remember(editingCard) { mutableStateOf(editingCard?.network ?: "MASTERCARD") }
    var presetStyle by remember(editingCard) { mutableStateOf(editingCard?.presetStyle ?: "CUSTOM_COLOR") }
    var primaryColorHex by remember(editingCard) { mutableLongStateOf(editingCard?.primaryColorHex ?: 0xFF0D0E11L) }
    var secondaryColorHex by remember(editingCard) { mutableLongStateOf(editingCard?.secondaryColorHex ?: 0xFF1C1D24L) }
    var customImagePath by remember(editingCard) { mutableStateOf(editingCard?.customImagePath) }
    var purePhotoMode by remember(editingCard) { mutableStateOf(editingCard?.purePhotoMode ?: true) }
    var balanceDisplay by remember(editingCard) { mutableStateOf(editingCard?.balanceDisplay ?: "$1,000.00") }

    // Update customImagePath whenever the user selects a new image from Camera Roll or Files
    LaunchedEffect(importedPhotoPath) {
        if (!importedPhotoPath.isNullOrBlank()) {
            customImagePath = importedPhotoPath
        }
    }

    val previewCard = WalletCardEntity(
        id = editingCard?.id ?: 999,
        title = title,
        arabicSubtitle = arabicSubtitle,
        cardHolderName = cardHolderName,
        lastFourDigits = lastFourDigits,
        network = network,
        presetStyle = presetStyle,
        primaryColorHex = primaryColorHex,
        secondaryColorHex = secondaryColorHex,
        customImagePath = customImagePath,
        purePhotoMode = purePhotoMode,
        balanceDisplay = balanceDisplay
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
        ) {
            // Sheet Header with Liquid Glass Close Circle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (editingCard != null) "Customize Card" else stringResource(R.string.add_to_wallet_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .liquidGlassSurface(
                            shape = CircleShape,
                            darkTheme = darkTheme,
                            elevation = 5.dp
                        )
                        .liquidPressable(pressScale = 0.86f, onClick = onDismiss)
                        .testTag("close_add_card_sheet_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Live Interactive 3D Gyroscope + Spring Card Preview
            AnimatedContent(
                targetState = Pair(presetStyle, customImagePath),
                transitionSpec = {
                    (fadeIn(tween(220)) +
                        scaleIn(
                            initialScale = 0.90f,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioLowBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            )
                        )) togetherWith
                        (fadeOut(tween(150)) + scaleOut(targetScale = 0.94f))
                },
                label = "previewCardStyleTransition"
            ) { _ ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer {
                            rotationX = deviceTilt.y * 4.2f
                            rotationY = -deviceTilt.x * 4.8f
                            cameraDistance = 16f * density
                        }
                        .testTag("add_card_live_preview")
                ) {
                    WalletCardArtwork(
                        card = previewCard,
                        modifier = Modifier.fillMaxWidth(),
                        shadowElevation = 14.dp
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Primary Camera Roll & Local Files Import Actions with Liquid Glass Buttons
            Text(
                text = "Card Photo Skin (Camera Roll or Local Files)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LiquidGlassButton(
                    onClick = onPickFromCameraRoll,
                    darkTheme = darkTheme,
                    tintColor = IosPrimaryBlue,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("import_camera_roll_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Camera Roll",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }

                LiquidGlassSecondaryButton(
                    onClick = onPickFromLocalFiles,
                    darkTheme = darkTheme,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("import_local_files_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = IosPrimaryBlue
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Local Files",
                        color = IosPrimaryBlue,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }

            // If a photo is imported, show Pure Photo Mode toggle & Remove Photo button
            if (!customImagePath.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .liquidGlassSurface(
                            shape = RoundedCornerShape(16.dp),
                            darkTheme = darkTheme,
                            elevation = 4.dp
                        )
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Photo + Last 4 Only (Hide Title & Logo)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Always keeps •••• $lastFourDigits at bottom-left of your photo",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = purePhotoMode,
                        onCheckedChange = { purePhotoMode = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = IosPrimaryBlue),
                        modifier = Modifier.testTag("pure_photo_mode_switch")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                LiquidGlassSecondaryButton(
                    onClick = {
                        customImagePath = null
                        onClearImportedPhoto()
                    },
                    darkTheme = darkTheme,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Remove Photo",
                        color = IosPrimaryBlue,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (customImagePath.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Card Background Color",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    cardColorChoices.forEach { choice ->
                        val isSelected = primaryColorHex == choice.primaryHex
                        val chipScale by animateFloatAsState(
                            targetValue = if (isSelected) 1.04f else 1f,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioLowBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            ),
                            label = "colorChoiceScale_${choice.label}"
                        )

                        Box(
                            modifier = Modifier
                                .graphicsLayer {
                                    scaleX = chipScale
                                    scaleY = chipScale
                                }
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(choice.primaryHex))
                                .border(
                                    width = if (isSelected) 2.5.dp else 1.dp,
                                    color = if (isSelected) IosPrimaryBlue else Color.White.copy(alpha = 0.25f),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .liquidPressable(
                                    pressScale = 0.90f,
                                    onClick = {
                                        presetStyle = "CUSTOM_COLOR"
                                        primaryColorHex = choice.primaryHex
                                        secondaryColorHex = choice.secondaryHex
                                    }
                                )
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                                .testTag("color_choice_${choice.label}")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clip(CircleShape)
                                            .background(IosPrimaryBlue),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(11.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = choice.label,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Card Text & Metadata Fields
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Card / Bank Name") },
                    placeholder = { Text("e.g. Chase Sapphire, Trading 212") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_title_input")
                )
                OutlinedTextField(
                    value = arabicSubtitle,
                    onValueChange = { arabicSubtitle = it },
                    label = { Text("Arabic / Subtitle") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_subtitle_input")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = lastFourDigits,
                    onValueChange = { if (it.length <= 4) lastFourDigits = it },
                    label = { Text("Last 4 Digits") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_last_four_input")
                )
                OutlinedTextField(
                    value = balanceDisplay,
                    onValueChange = { balanceDisplay = it },
                    label = { Text("Simulated Balance") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_balance_input")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Network Selection
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("VISA", "MASTERCARD", "MADA_VISA").forEach { net ->
                    FilterChip(
                        selected = network == net,
                        onClick = { network = net },
                        label = {
                            Text(
                                when (net) {
                                    "MADA_VISA" -> "mada + VISA"
                                    "MASTERCARD" -> "Mastercard"
                                    else -> "VISA"
                                }
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Save & Delete Actions with Liquid Glass Buttons
            LiquidGlassButton(
                onClick = {
                    onSaveCard(
                        title,
                        arabicSubtitle,
                        cardHolderName,
                        lastFourDigits,
                        network,
                        presetStyle,
                        primaryColorHex,
                        secondaryColorHex,
                        customImagePath,
                        purePhotoMode,
                        balanceDisplay
                    )
                    onDismiss()
                },
                darkTheme = darkTheme,
                tintColor = IosPrimaryBlue,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("save_card_button")
            ) {
                Text(
                    text = if (editingCard != null) "Save Card Changes" else "Add to Apple Wallet",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            if (editingCard != null && onDeleteCard != null) {
                Spacer(modifier = Modifier.height(10.dp))
                LiquidGlassSecondaryButton(
                    onClick = {
                        onDeleteCard(editingCard.id)
                        onDismiss()
                    },
                    darkTheme = darkTheme,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("delete_card_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = null,
                        tint = Color(0xFFFF3B30)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Remove Card from Wallet",
                        color = Color(0xFFFF3B30),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
