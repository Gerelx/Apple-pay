package com.example.ui

import com.example.BuildConfig
import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.WalletCardEntity
import com.example.data.WalletDatabase
import com.example.data.WalletRepository
import com.example.data.WalletTransactionEntity
import com.example.hardware.HapticAndSoundEngine
import com.example.ui.components.ConfirmationIconType
import com.example.ui.components.PaymentStage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class HomeDisplayMode {
    WALLET_STACK_HOME,
    APPLE_PAY_EXPRESS
}

enum class StackPresetFilter {
    SCREENSHOT_2_STACK,
    ALL_CARDS
}

enum class WalletEcosystemTheme {
    APPLE_PAY,
    GOOGLE_WALLET
}

enum class PaymentOutcome {
    APPROVED,
    DECLINED
}

data class LarpPreferences(
    val ecosystemTheme: WalletEcosystemTheme = WalletEcosystemTheme.APPLE_PAY,
    val googleProfilePhotoPath: String? = null,
    val confirmationIconType: ConfirmationIconType = ConfirmationIconType.SIDE_BUTTON,
    val darkTheme: Boolean = false,
    val hapticsEnabled: Boolean = true,
    val chimeSoundEnabled: Boolean = true,
    val appleCustomSoundPath: String? = null,
    val googleCustomSoundPath: String? = null,
    val paymentDurationSeconds: Int = 4,
    val paymentOutcome: PaymentOutcome = PaymentOutcome.APPROVED,
    val requireHardwareBiometricOnPay: Boolean = true,
    val isAppLocked: Boolean = false,
    val simulatedMerchantName: String = "Apple Store",
    val simulatedAmountText: String = "$1,299.00"
) {
    val isGoogleWallet: Boolean
        get() = ecosystemTheme == WalletEcosystemTheme.GOOGLE_WALLET

    val currentThemeSoundPath: String?
        get() = if (isGoogleWallet) googleCustomSoundPath else appleCustomSoundPath

    val currentThemeAppName: String
        get() = if (isGoogleWallet) "Google Wallet" else "Apple Pay"
}

data class WalletUiState(
    val allCards: List<WalletCardEntity> = emptyList(),
    val visibleStackCards: List<WalletCardEntity> = emptyList(),
    val activeHeroCard: WalletCardEntity? = null,
    val recentTransactions: List<WalletTransactionEntity> = emptyList(),
    val displayMode: HomeDisplayMode = HomeDisplayMode.WALLET_STACK_HOME,
    val stackFilter: StackPresetFilter = StackPresetFilter.ALL_CARDS,
    val paymentStage: PaymentStage = PaymentStage.FACE_ID_SCANNING,
    val isAutoAnimatingPayment: Boolean = false,
    val nfcProgress: Float = 0f,
    val nfcSecondsRemaining: Int = 4,
    val searchQuery: String = "",
    val isSearchVisible: Boolean = false,
    val larpPrefs: LarpPreferences = LarpPreferences(),
    val lastImportedPhotoPath: String? = null
)

class WalletViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val sharedPrefs = appContext.getSharedPreferences("apple_pay_wallet_prefs", Context.MODE_PRIVATE)
    private val database = WalletDatabase.getInstance(application)
    private val repository = WalletRepository(database.walletDao(), application)
    val hapticAndSound = HapticAndSoundEngine(application)

    private val _displayMode = MutableStateFlow(HomeDisplayMode.WALLET_STACK_HOME)
    private val _stackFilter = MutableStateFlow(loadSavedStackFilter())
    private val _selectedCardId = MutableStateFlow<Int?>(null)
    private val _paymentStage = MutableStateFlow(PaymentStage.FACE_ID_SCANNING)
    private val _isAutoAnimating = MutableStateFlow(false)
    private val _nfcProgress = MutableStateFlow(0f)
    private val _nfcSecondsRemaining = MutableStateFlow(4)
    private val _searchQuery = MutableStateFlow("")
    private val _isSearchVisible = MutableStateFlow(false)
    private val _larpPrefs = MutableStateFlow(loadSavedLarpPreferences())
    private val _lastImportedPhotoPath = MutableStateFlow<String?>(null)

    private var paymentAnimationJob: Job? = null

    init {
        val hasClearedInitially = sharedPrefs.getBoolean("cards_cleared_for_clean_start_v3", false)
        if (!hasClearedInitially) {
            sharedPrefs.edit().putBoolean("cards_cleared_for_clean_start_v3", true).apply()
            viewModelScope.launch {
                repository.clearAllCards()
            }
        }
    }

    private fun loadSavedStackFilter(): StackPresetFilter {
        val savedName = sharedPrefs.getString("stack_filter", StackPresetFilter.ALL_CARDS.name)
        return try {
            StackPresetFilter.valueOf(savedName ?: StackPresetFilter.ALL_CARDS.name)
        } catch (_: Exception) {
            StackPresetFilter.ALL_CARDS
        }
    }

    private fun validFileOrNull(path: String?): String? {
        if (path.isNullOrBlank()) return null
        val f = File(path)
        return if (f.exists() && f.length() > 0L) path else null
    }

    private fun loadSavedLarpPreferences(): LarpPreferences {
        // Fixed by the build flavor: the Apple Pay app is always Apple Pay, the Google Wallet app
        // is always Google Wallet.
        val ecosystem = if (BuildConfig.ECOSYSTEM == WalletEcosystemTheme.GOOGLE_WALLET.name) {
            WalletEcosystemTheme.GOOGLE_WALLET
        } else {
            WalletEcosystemTheme.APPLE_PAY
        }

        val confirmTypeStr = sharedPrefs.getString("confirmation_icon_type", ConfirmationIconType.SIDE_BUTTON.name)
        val confirmType = try {
            ConfirmationIconType.valueOf(confirmTypeStr ?: ConfirmationIconType.SIDE_BUTTON.name)
        } catch (_: Exception) {
            ConfirmationIconType.SIDE_BUTTON
        }

        val outcomeStr = sharedPrefs.getString("payment_outcome", PaymentOutcome.APPROVED.name)
        val outcome = try {
            PaymentOutcome.valueOf(outcomeStr ?: PaymentOutcome.APPROVED.name)
        } catch (_: Exception) {
            PaymentOutcome.APPROVED
        }

        val legacySound = validFileOrNull(sharedPrefs.getString("custom_sound_path", null))
        val appleSound = validFileOrNull(sharedPrefs.getString("apple_custom_sound_path", null)) ?: legacySound
        val googleSound = validFileOrNull(sharedPrefs.getString("google_custom_sound_path", null))

        return LarpPreferences(
            ecosystemTheme = ecosystem,
            googleProfilePhotoPath = validFileOrNull(sharedPrefs.getString("google_profile_photo_path", null)),
            confirmationIconType = confirmType,
            darkTheme = sharedPrefs.getBoolean("dark_theme", false),
            hapticsEnabled = sharedPrefs.getBoolean("haptics_enabled", true),
            chimeSoundEnabled = sharedPrefs.getBoolean("chime_sound_enabled", true),
            appleCustomSoundPath = appleSound,
            googleCustomSoundPath = googleSound,
            paymentDurationSeconds = sharedPrefs.getInt("payment_duration_seconds", 4).coerceIn(1, 15),
            paymentOutcome = outcome,
            requireHardwareBiometricOnPay = sharedPrefs.getBoolean("require_hardware_biometric_on_pay", true),
            isAppLocked = sharedPrefs.getBoolean("is_app_locked", false),
            simulatedMerchantName = sharedPrefs.getString("simulated_merchant_name", "Apple Store") ?: "Apple Store",
            simulatedAmountText = sharedPrefs.getString("simulated_amount_text", "$1,299.00") ?: "$1,299.00"
        )
    }

    private fun persistLarpPreferences(prefs: LarpPreferences) {
        sharedPrefs.edit()
            .putString("ecosystem_theme", prefs.ecosystemTheme.name)
            .putString("google_profile_photo_path", prefs.googleProfilePhotoPath)
            .putString("confirmation_icon_type", prefs.confirmationIconType.name)
            .putBoolean("dark_theme", prefs.darkTheme)
            .putBoolean("haptics_enabled", prefs.hapticsEnabled)
            .putBoolean("chime_sound_enabled", prefs.chimeSoundEnabled)
            .putString("apple_custom_sound_path", prefs.appleCustomSoundPath)
            .putString("google_custom_sound_path", prefs.googleCustomSoundPath)
            .putInt("payment_duration_seconds", prefs.paymentDurationSeconds)
            .putString("payment_outcome", prefs.paymentOutcome.name)
            .putBoolean("require_hardware_biometric_on_pay", prefs.requireHardwareBiometricOnPay)
            .putBoolean("is_app_locked", prefs.isAppLocked)
            .putString("simulated_merchant_name", prefs.simulatedMerchantName)
            .putString("simulated_amount_text", prefs.simulatedAmountText)
            .apply()
    }

    private val firstFlow = combine(
        repository.allCards,
        repository.recentTransactions,
        _displayMode,
        _stackFilter,
        _selectedCardId
    ) { cards, transactions, mode, filter, selectedId ->
        Quintuple(cards, transactions, mode, filter, selectedId)
    }

    private val secondFlow = combine(
        _paymentStage,
        _isAutoAnimating,
        _searchQuery,
        _isSearchVisible,
        _larpPrefs
    ) { stage, animating, query, searchVis, prefs ->
        Quintuple(stage, animating, query, searchVis, prefs)
    }

    private val nfcFlow = combine(_nfcProgress, _nfcSecondsRemaining) { prog, secs ->
        prog to secs
    }

    val uiState: StateFlow<WalletUiState> = combine(
        firstFlow,
        secondFlow,
        nfcFlow
    ) { first, second, nfcPair ->
        val (cards, transactions, mode, filter, selectedId) = first
        val (stage, animating, query, searchVis, prefs) = second
        val (nfcProg, nfcSecs) = nfcPair

        val ecosystemCards = cards.filter {
            if (prefs.ecosystemTheme == WalletEcosystemTheme.GOOGLE_WALLET) {
                it.stackGroup == "GOOGLE_WALLET"
            } else {
                it.stackGroup == "APPLE_PAY" || (it.stackGroup != "GOOGLE_WALLET")
            }
        }

        val filteredCards = if (query.isBlank()) {
            ecosystemCards
        } else {
            ecosystemCards.filter {
                it.title.contains(query, ignoreCase = true) ||
                    it.arabicSubtitle.contains(query, ignoreCase = true) ||
                    it.lastFourDigits.contains(query, ignoreCase = true) ||
                    it.network.contains(query, ignoreCase = true)
            }
        }

        val activeCard = filteredCards.find { it.id == selectedId }
            ?: ecosystemCards.find { it.id == selectedId }
            ?: filteredCards.lastOrNull()
            ?: ecosystemCards.lastOrNull()

        WalletUiState(
            allCards = cards,
            visibleStackCards = filteredCards,
            activeHeroCard = activeCard,
            recentTransactions = transactions,
            displayMode = mode,
            stackFilter = filter,
            paymentStage = stage,
            isAutoAnimatingPayment = animating,
            nfcProgress = nfcProg,
            nfcSecondsRemaining = nfcSecs,
            searchQuery = query,
            isSearchVisible = searchVis,
            larpPrefs = prefs,
            lastImportedPhotoPath = _lastImportedPhotoPath.value
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = WalletUiState(
            stackFilter = _stackFilter.value,
            larpPrefs = _larpPrefs.value
        )
    )

    fun selectCardAndOpenExpress(card: WalletCardEntity) {
        paymentAnimationJob?.cancel()
        _isAutoAnimating.value = false
        _nfcProgress.value = 0f
        _nfcSecondsRemaining.value = _larpPrefs.value.paymentDurationSeconds
        hapticAndSound.performCardSnap(_larpPrefs.value.hapticsEnabled)
        _selectedCardId.value = card.id
        _paymentStage.value = PaymentStage.FACE_ID_SCANNING
        _displayMode.value = HomeDisplayMode.APPLE_PAY_EXPRESS
        viewModelScope.launch {
            repository.bringCardToFrontOfStack(card, uiState.value.allCards)
        }
    }

    fun swapActiveCardInExpressMode(card: WalletCardEntity) {
        if (_isAutoAnimating.value) return
        paymentAnimationJob?.cancel()
        _isAutoAnimating.value = false
        _nfcProgress.value = 0f
        _nfcSecondsRemaining.value = _larpPrefs.value.paymentDurationSeconds
        hapticAndSound.performCardSnap(_larpPrefs.value.hapticsEnabled)
        _selectedCardId.value = card.id
        _paymentStage.value = PaymentStage.FACE_ID_SCANNING
    }

    fun onGoogleWalletCardSwiped(card: WalletCardEntity) {
        if (_isAutoAnimating.value) return
        if (_selectedCardId.value != card.id) {
            _selectedCardId.value = card.id
            hapticAndSound.performCardTick(_larpPrefs.value.hapticsEnabled)
        }
    }

    /**
     * In Google Wallet Theme: automatically starts contactless transmission.
     * Uses customizable duration and outcome (Approved vs Declined).
     */
    fun onGoogleWalletCardChosenStartNfcAndDone(card: WalletCardEntity) {
        if (_isAutoAnimating.value) return
        paymentAnimationJob?.cancel()
        _selectedCardId.value = card.id
        paymentAnimationJob = viewModelScope.launch {
            _isAutoAnimating.value = true
            _nfcProgress.value = 0f
            val durationSecs = _larpPrefs.value.paymentDurationSeconds.coerceIn(1, 15)
            _nfcSecondsRemaining.value = durationSecs
            val prefs = _larpPrefs.value

            _paymentStage.value = PaymentStage.NFC_HOLD_NEAR_READER
            hapticAndSound.performFaceIdScanPulse(prefs.hapticsEnabled)

            val totalSteps = durationSecs * 10
            for (step in 1..totalSteps) {
                delay(100L)
                _nfcProgress.value = step.toFloat() / totalSteps.toFloat()
                if (step % 10 == 0) {
                    hapticAndSound.performNfcRadarPulse(_larpPrefs.value.hapticsEnabled)
                }
            }

            val latestPrefs = _larpPrefs.value
            if (latestPrefs.paymentOutcome == PaymentOutcome.DECLINED) {
                _paymentStage.value = PaymentStage.DECLINED
                hapticAndSound.performPaymentDeclined(
                    hapticsEnabled = latestPrefs.hapticsEnabled,
                    soundEnabled = latestPrefs.chimeSoundEnabled
                )
                repository.recordPaymentTransaction(
                    card = card,
                    merchantName = latestPrefs.simulatedMerchantName,
                    locationOrCategory = "Google Pay • Declined by Issuer",
                    amountText = latestPrefs.simulatedAmountText
                )
                delay(2400L)
            } else {
                _paymentStage.value = PaymentStage.DONE
                hapticAndSound.performPaymentSuccess(
                    hapticsEnabled = latestPrefs.hapticsEnabled,
                    soundEnabled = latestPrefs.chimeSoundEnabled,
                    isGoogleWalletTheme = true,
                    customSoundPath = latestPrefs.googleCustomSoundPath
                )
                repository.recordPaymentTransaction(
                    card = card,
                    merchantName = latestPrefs.simulatedMerchantName,
                    locationOrCategory = "Google Pay • Contactless NFC",
                    amountText = latestPrefs.simulatedAmountText
                )
                delay(2400L)
            }

            _isAutoAnimating.value = false
            _nfcProgress.value = 0f
            _paymentStage.value = PaymentStage.FACE_ID_SCANNING
        }
    }

    fun cancelGoogleWalletPaymentAnimation() {
        paymentAnimationJob?.cancel()
        _isAutoAnimating.value = false
        _nfcProgress.value = 0f
        _paymentStage.value = PaymentStage.FACE_ID_SCANNING
        hapticAndSound.performCardTick(_larpPrefs.value.hapticsEnabled)
    }

    fun setDisplayMode(mode: HomeDisplayMode) {
        paymentAnimationJob?.cancel()
        _isAutoAnimating.value = false
        _nfcProgress.value = 0f
        hapticAndSound.performCardTick(_larpPrefs.value.hapticsEnabled)
        _displayMode.value = mode
        if (mode == HomeDisplayMode.WALLET_STACK_HOME) {
            _paymentStage.value = PaymentStage.FACE_ID_SCANNING
        }
    }

    fun setStackPresetFilter(filter: StackPresetFilter) {
        hapticAndSound.performCardTick(_larpPrefs.value.hapticsEnabled)
        _stackFilter.value = filter
        sharedPrefs.edit().putString("stack_filter", filter.name).apply()
    }

    fun onBiometricVerifiedStartNfcAndDoneSequence() {
        if (_isAutoAnimating.value) return
        paymentAnimationJob?.cancel()
        paymentAnimationJob = viewModelScope.launch {
            _isAutoAnimating.value = true
            _nfcProgress.value = 0f
            val durationSecs = _larpPrefs.value.paymentDurationSeconds.coerceIn(1, 15)
            _nfcSecondsRemaining.value = durationSecs
            val prefs = _larpPrefs.value

            _paymentStage.value = PaymentStage.NFC_HOLD_NEAR_READER
            hapticAndSound.performFaceIdScanPulse(prefs.hapticsEnabled)

            val totalSteps = durationSecs * 10
            for (step in 1..totalSteps) {
                delay(100L)
                _nfcProgress.value = step.toFloat() / totalSteps.toFloat()
                if (step % 10 == 0) {
                    hapticAndSound.performNfcRadarPulse(_larpPrefs.value.hapticsEnabled)
                }
            }

            val latestPrefs = _larpPrefs.value
            if (latestPrefs.paymentOutcome == PaymentOutcome.DECLINED) {
                _paymentStage.value = PaymentStage.DECLINED
                hapticAndSound.performPaymentDeclined(
                    hapticsEnabled = latestPrefs.hapticsEnabled,
                    soundEnabled = latestPrefs.chimeSoundEnabled
                )
                uiState.value.activeHeroCard?.let { card ->
                    repository.recordPaymentTransaction(
                        card = card,
                        merchantName = latestPrefs.simulatedMerchantName,
                        locationOrCategory = "Apple Pay • Payment Declined",
                        amountText = latestPrefs.simulatedAmountText
                    )
                }
                delay(2200L)
            } else {
                _paymentStage.value = PaymentStage.DONE
                hapticAndSound.performPaymentSuccess(
                    hapticsEnabled = latestPrefs.hapticsEnabled,
                    soundEnabled = latestPrefs.chimeSoundEnabled,
                    isGoogleWalletTheme = false,
                    customSoundPath = latestPrefs.appleCustomSoundPath
                )
                uiState.value.activeHeroCard?.let { card ->
                    repository.recordPaymentTransaction(
                        card = card,
                        merchantName = latestPrefs.simulatedMerchantName,
                        locationOrCategory = "Apple Pay • Biometric NFC",
                        amountText = latestPrefs.simulatedAmountText
                    )
                }
                delay(2000L)
            }

            _isAutoAnimating.value = false
            _nfcProgress.value = 0f
            _displayMode.value = HomeDisplayMode.WALLET_STACK_HOME
            _paymentStage.value = PaymentStage.FACE_ID_SCANNING
        }
    }

    fun toggleSearchBar() {
        hapticAndSound.performCardTick(_larpPrefs.value.hapticsEnabled)
        _isSearchVisible.update { !it }
        if (!_isSearchVisible.value) {
            _searchQuery.value = ""
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateLarpPreferences(transform: (LarpPreferences) -> LarpPreferences) {
        val oldTheme = _larpPrefs.value.ecosystemTheme
        hapticAndSound.performCardTick(_larpPrefs.value.hapticsEnabled)
        _larpPrefs.update { current ->
            val updated = transform(current)
            persistLarpPreferences(updated)
            updated
        }
        val newPrefs = _larpPrefs.value
        if (oldTheme != newPrefs.ecosystemTheme) {
            paymentAnimationJob?.cancel()
            _isAutoAnimating.value = false
            _nfcProgress.value = 0f
            _paymentStage.value = PaymentStage.FACE_ID_SCANNING
            if (newPrefs.chimeSoundEnabled) {
                hapticAndSound.performPaymentSuccess(
                    hapticsEnabled = newPrefs.hapticsEnabled,
                    soundEnabled = true,
                    isGoogleWalletTheme = newPrefs.isGoogleWallet,
                    customSoundPath = newPrefs.currentThemeSoundPath
                )
            }
        }
    }

    fun importGoogleProfilePhotoFromUri(uri: Uri) {
        viewModelScope.launch {
            val savedPath = withContext(Dispatchers.IO) {
                try {
                    val avatarDir = File(appContext.filesDir, "google_profile")
                    if (!avatarDir.exists()) avatarDir.mkdirs()
                    avatarDir.listFiles()?.forEach { it.delete() }
                    val target = File(avatarDir, "google_avatar_${System.currentTimeMillis()}.jpg")
                    appContext.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(target).use { output ->
                            input.copyTo(output)
                        }
                    }
                    if (target.exists() && target.length() > 0L) target.absolutePath else null
                } catch (_: Exception) {
                    null
                }
            }
            if (savedPath != null) {
                _larpPrefs.update { current ->
                    val updated = current.copy(googleProfilePhotoPath = savedPath)
                    persistLarpPreferences(updated)
                    updated
                }
                hapticAndSound.performCardSnap(_larpPrefs.value.hapticsEnabled)
            }
        }
    }

    fun clearGoogleProfilePhoto() {
        _larpPrefs.update { current ->
            val updated = current.copy(googleProfilePhotoPath = null)
            persistLarpPreferences(updated)
            updated
        }
        hapticAndSound.performCardTick(_larpPrefs.value.hapticsEnabled)
    }

    fun importCustomSoundFromUri(
        uri: Uri,
        forTheme: WalletEcosystemTheme = _larpPrefs.value.ecosystemTheme
    ) {
        viewModelScope.launch {
            val savedPath = withContext(Dispatchers.IO) {
                try {
                    val soundDir = File(appContext.filesDir, "custom_sounds")
                    if (!soundDir.exists()) soundDir.mkdirs()
                    val prefix = if (forTheme == WalletEcosystemTheme.GOOGLE_WALLET) "google_pay_sound_" else "apple_pay_sound_"
                    soundDir.listFiles()?.filter { it.name.startsWith(prefix) }?.forEach { it.delete() }
                    val target = File(soundDir, "${prefix}${System.currentTimeMillis()}.mp3")
                    appContext.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(target).use { output ->
                            input.copyTo(output)
                        }
                    }
                    if (target.exists() && target.length() > 0L) target.absolutePath else null
                } catch (_: Exception) {
                    null
                }
            }
            if (savedPath != null) {
                _larpPrefs.update { current ->
                    val updated = if (forTheme == WalletEcosystemTheme.GOOGLE_WALLET) {
                        current.copy(googleCustomSoundPath = savedPath, chimeSoundEnabled = true)
                    } else {
                        current.copy(appleCustomSoundPath = savedPath, chimeSoundEnabled = true)
                    }
                    persistLarpPreferences(updated)
                    updated
                }
                hapticAndSound.performPaymentSuccess(
                    hapticsEnabled = _larpPrefs.value.hapticsEnabled,
                    soundEnabled = true,
                    isGoogleWalletTheme = forTheme == WalletEcosystemTheme.GOOGLE_WALLET,
                    customSoundPath = savedPath
                )
            }
        }
    }

    fun resetCustomSoundForTheme(forTheme: WalletEcosystemTheme = _larpPrefs.value.ecosystemTheme) {
        _larpPrefs.update { current ->
            val updated = if (forTheme == WalletEcosystemTheme.GOOGLE_WALLET) {
                current.copy(googleCustomSoundPath = null)
            } else {
                current.copy(appleCustomSoundPath = null)
            }
            persistLarpPreferences(updated)
            updated
        }
        hapticAndSound.performPaymentSuccess(
            hapticsEnabled = _larpPrefs.value.hapticsEnabled,
            soundEnabled = true,
            isGoogleWalletTheme = forTheme == WalletEcosystemTheme.GOOGLE_WALLET,
            customSoundPath = null
        )
    }

    fun importCardPhotoFromUri(
        uri: Uri,
        replaceCard: WalletCardEntity? = null,
        purePhotoMode: Boolean = true,
        onComplete: (String?) -> Unit = {}
    ) {
        viewModelScope.launch {
            val savedPath = repository.importImageFromUri(uri)
            _lastImportedPhotoPath.value = savedPath
            if (savedPath != null) {
                if (replaceCard != null) {
                    val updated = replaceCard.copy(
                        customImagePath = savedPath,
                        purePhotoMode = purePhotoMode
                    )
                    repository.updateCard(updated)
                    _selectedCardId.value = updated.id
                }
                hapticAndSound.performCardSnap(_larpPrefs.value.hapticsEnabled)
            }
            onComplete(savedPath)
        }
    }

    fun addCustomCard(
        title: String,
        arabicSubtitle: String,
        cardHolderName: String,
        lastFourDigits: String,
        network: String,
        presetStyle: String,
        primaryColorHex: Long,
        secondaryColorHex: Long,
        customImagePath: String?,
        purePhotoMode: Boolean,
        balanceDisplay: String
    ) {
        viewModelScope.launch {
            val currentMaxSort = uiState.value.allCards.maxOfOrNull { it.sortOrder } ?: 0
            val newCard = WalletCardEntity(
                title = title.ifBlank { "My Card" },
                arabicSubtitle = arabicSubtitle,
                cardHolderName = cardHolderName.ifBlank { "CARDHOLDER" },
                lastFourDigits = lastFourDigits.ifBlank { "1234" },
                network = network,
                presetStyle = presetStyle,
                primaryColorHex = primaryColorHex,
                secondaryColorHex = secondaryColorHex,
                customImagePath = customImagePath,
                purePhotoMode = purePhotoMode,
                balanceDisplay = balanceDisplay.ifBlank { "$1,000.00" },
                stackGroup = _larpPrefs.value.ecosystemTheme.name,
                sortOrder = currentMaxSort + 1,
                isDefaultCard = true
            )
            val newId = repository.insertCard(newCard).toInt()
            _selectedCardId.value = newId
            val prefs = _larpPrefs.value
            hapticAndSound.performCardSnap(prefs.hapticsEnabled)
        }
    }

    fun setEcosystemTheme(theme: WalletEcosystemTheme) {
        // Each app is locked to its own wallet; ignore attempts to switch.
        if (theme.name != BuildConfig.ECOSYSTEM) return
        updateLarpPreferences { it.copy(ecosystemTheme = theme) }
    }

    fun updateExistingCard(card: WalletCardEntity) {
        viewModelScope.launch {
            repository.updateCard(card)
            hapticAndSound.performCardSnap(_larpPrefs.value.hapticsEnabled)
        }
    }

    fun deleteCard(cardId: Int) {
        viewModelScope.launch {
            repository.deleteCard(cardId)
            hapticAndSound.performCardTick(_larpPrefs.value.hapticsEnabled)
        }
    }

    fun clearAllCards() {
        viewModelScope.launch {
            repository.clearAllCards()
            _selectedCardId.value = null
            hapticAndSound.performCardTick(_larpPrefs.value.hapticsEnabled)
        }
    }

    fun resetAllCardsToScreenshotDefaults() {
        viewModelScope.launch {
            repository.clearAllCards()
            _selectedCardId.value = null
            _stackFilter.value = StackPresetFilter.ALL_CARDS
            sharedPrefs.edit().putString("stack_filter", StackPresetFilter.ALL_CARDS.name).apply()
            hapticAndSound.performCardSnap(_larpPrefs.value.hapticsEnabled)
        }
    }
}

private data class Quintuple<A, B, C, D, E>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D,
    val fifth: E
)
