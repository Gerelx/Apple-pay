package com.example.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class WalletRepository(
    private val walletDao: WalletDao,
    private val appContext: Context
) {
    val allCards: Flow<List<WalletCardEntity>> = walletDao.getAllCards()
    val recentTransactions: Flow<List<WalletTransactionEntity>> = walletDao.getRecentTransactions()

    fun getTransactionsForCard(cardId: Int): Flow<List<WalletTransactionEntity>> =
        walletDao.getTransactionsForCard(cardId)

    suspend fun ensureSeedData() {
        // As requested by user: start with 0 cards so the user adds their own card and photo
    }

    suspend fun clearAllCards() {
        walletDao.deleteAllTransactions()
        walletDao.deleteAllCards()
    }

    suspend fun resetToDefaultCards() {
        walletDao.deleteAllTransactions()
        walletDao.deleteAllCards()
    }

    suspend fun insertCard(card: WalletCardEntity): Long = walletDao.insertCard(card)

    suspend fun updateCard(card: WalletCardEntity) = walletDao.updateCard(card)

    suspend fun deleteCard(cardId: Int) = walletDao.deleteCardById(cardId)

    suspend fun recordPaymentTransaction(
        card: WalletCardEntity,
        merchantName: String,
        locationOrCategory: String,
        amountText: String
    ) {
        walletDao.insertTransaction(
            WalletTransactionEntity(
                cardId = card.id,
                merchantName = merchantName,
                locationOrCategory = locationOrCategory,
                amountText = amountText,
                timestamp = System.currentTimeMillis(),
                status = "Done • Face ID & NFC"
            )
        )
    }

    suspend fun bringCardToFrontOfStack(selectedCard: WalletCardEntity, currentCards: List<WalletCardEntity>) {
        // In the stacked fan (Screenshot 2), the card with the highest sortOrder is rendered at the front (bottom of fan)
        val others = currentCards.filter { it.id != selectedCard.id }.sortedBy { it.sortOrder }
        others.forEachIndexed { index, card ->
            walletDao.updateCard(card.copy(sortOrder = index, isDefaultCard = false))
        }
        walletDao.updateCard(
            selectedCard.copy(
                sortOrder = others.size,
                isDefaultCard = true
            )
        )
    }

    /**
     * Copies a photo selected from the phone's Camera Roll or Local Files into persistent internal storage
     * so the image never disappears after device reboot or permission expiration.
     */
    suspend fun importImageFromUri(uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val directory = File(appContext.filesDir, "card_images")
            if (!directory.exists()) {
                directory.mkdirs()
            }
            val targetFile = File(directory, "card_art_${UUID.randomUUID()}.jpg")
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }
            if (targetFile.exists() && targetFile.length() > 0L) {
                targetFile.absolutePath
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun seedDefaultCardsAndTransactions() {
        // Seed the exact cards shown across the 3 reference screenshots:
        // Screenshot 2 Stack (from top-back to bottom-front):
        // 0: Riyad Bank (Black)
        // 1: Alinma Bank (Pearl White / Brown)
        // 2: Violet Mint Card (Purple / Lavender / Mint)
        // 3: SNB AlAhli (Emerald Green calligraphic)
        // 4: Alrajhi Bank (Royal Blue mada VISA - front of stack in Screenshot 2!)
        // Plus Screenshot 1 & 3 Hero Cards:
        // 5: Trading 212 (Pitch Black Mastercard - Screenshot 1 Hero!)
        // 6: Platinum Geometric Visa (Brushed Silver diagonal - Screenshot 3 Hero!)
        // 7: Sovereign Gold Reserve (Brushed Champagne Gold - Screenshot 3 bottom stack!)
        val defaultCards = listOf(
            WalletCardEntity(
                id = 1,
                title = "Sovereign Gold",
                arabicSubtitle = "PRIVATE RESERVE",
                cardHolderName = "ALEXANDER MERCER",
                lastFourDigits = "1234",
                expiryDate = "01/31",
                cvv = "999",
                network = "VISA",
                presetStyle = "GOLD_RESERVE",
                primaryColorHex = 0xFFD4B263L,
                secondaryColorHex = 0xFFB88D32L,
                accentColorHex = 0xFFFFFFFFL,
                balanceDisplay = "$250,000.00",
                stackGroup = "GLOBAL_STACK",
                sortOrder = 0,
                isDefaultCard = false
            ),
            WalletCardEntity(
                id = 2,
                title = "Platinum Geometric",
                arabicSubtitle = "SIGNATURE",
                cardHolderName = "ALEXANDER MERCER",
                lastFourDigits = "1234",
                expiryDate = "05/30",
                cvv = "204",
                network = "VISA",
                presetStyle = "SILVER_GEOMETRIC_VISA",
                primaryColorHex = 0xFFD4D5D9L,
                secondaryColorHex = 0xFF9E9FA5L,
                accentColorHex = 0xFF1434CBL,
                balanceDisplay = "$85,320.00",
                stackGroup = "GLOBAL_STACK",
                sortOrder = 1,
                isDefaultCard = false
            ),
            WalletCardEntity(
                id = 3,
                title = "TRADING 212",
                arabicSubtitle = "INVEST CARD",
                cardHolderName = "ALEXANDER MERCER",
                lastFourDigits = "1234",
                expiryDate = "10/30",
                cvv = "612",
                network = "MASTERCARD",
                presetStyle = "TRADING_212",
                primaryColorHex = 0xFF070709L,
                secondaryColorHex = 0xFF14151AL,
                accentColorHex = 0xFF00A8FFL,
                balanceDisplay = "£42,890.40",
                stackGroup = "GLOBAL_STACK",
                sortOrder = 2,
                isDefaultCard = false
            ),
            WalletCardEntity(
                id = 4,
                title = "Riyad Bank",
                arabicSubtitle = "بنك الرياض",
                cardHolderName = "ALEXANDER MERCER",
                lastFourDigits = "1234",
                expiryDate = "11/29",
                cvv = "904",
                network = "MASTERCARD",
                presetStyle = "RIYAD_BLACK",
                primaryColorHex = 0xFF121317L,
                secondaryColorHex = 0xFF282A30L,
                accentColorHex = 0xFFFFFFFFL,
                balanceDisplay = "SAR 64,200.00",
                stackGroup = "SAUDI_STACK",
                sortOrder = 3,
                isDefaultCard = false
            ),
            WalletCardEntity(
                id = 5,
                title = "alinma bank",
                arabicSubtitle = "مصرف الإنماء",
                cardHolderName = "ALEXANDER MERCER",
                lastFourDigits = "1234",
                expiryDate = "06/28",
                cvv = "418",
                network = "VISA",
                presetStyle = "ALINMA_WHITE",
                primaryColorHex = 0xFFF4F3F0L,
                secondaryColorHex = 0xFFE8E6E1L,
                accentColorHex = 0xFF523228L,
                balanceDisplay = "SAR 29,850.00",
                stackGroup = "SAUDI_STACK",
                sortOrder = 4,
                isDefaultCard = false
            ),
            WalletCardEntity(
                id = 6,
                title = "stc pay",
                arabicSubtitle = "بلاتينيوم",
                cardHolderName = "ALEXANDER MERCER",
                lastFourDigits = "1234",
                expiryDate = "03/30",
                cvv = "772",
                network = "VISA",
                presetStyle = "PURPLE_MINT",
                primaryColorHex = 0xFF4F008CL,
                secondaryColorHex = 0xFF00C48CL,
                accentColorHex = 0xFFE2D4F0L,
                balanceDisplay = "SAR 15,490.00",
                stackGroup = "SAUDI_STACK",
                sortOrder = 5,
                isDefaultCard = false
            ),
            WalletCardEntity(
                id = 7,
                title = "SNB",
                arabicSubtitle = "الأهلي",
                cardHolderName = "ALEXANDER MERCER",
                lastFourDigits = "1234",
                expiryDate = "09/29",
                cvv = "551",
                network = "MASTERCARD",
                presetStyle = "SNB_GREEN",
                primaryColorHex = 0xFF006C35L,
                secondaryColorHex = 0xFF58B947L,
                accentColorHex = 0xFFFFFFFFL,
                balanceDisplay = "SAR 92,110.00",
                stackGroup = "SAUDI_STACK",
                sortOrder = 6,
                isDefaultCard = false
            ),
            WalletCardEntity(
                id = 8,
                title = "alrajhi bank",
                arabicSubtitle = "مصرف الراجحي",
                cardHolderName = "ALEXANDER MERCER",
                lastFourDigits = "1234",
                expiryDate = "12/29",
                cvv = "309",
                network = "MADA_VISA",
                presetStyle = "ALRAJHI_BLUE",
                primaryColorHex = 0xFF0047BAL,
                secondaryColorHex = 0xFF003794L,
                accentColorHex = 0xFFFFFFFFL,
                balanceDisplay = "SAR 148,500.00",
                stackGroup = "SAUDI_STACK",
                sortOrder = 7,
                isDefaultCard = true
            )
        )
        walletDao.insertCards(defaultCards)

        val now = System.currentTimeMillis()
        val sampleTransactions = listOf(
            WalletTransactionEntity(
                cardId = 5,
                merchantName = "Apple Store • Riyadh Park",
                locationOrCategory = "Riyadh • Apple Pay NFC",
                amountText = "SAR 5,499.00",
                timestamp = now - 3600_000L * 2
            ),
            WalletTransactionEntity(
                cardId = 6,
                merchantName = "Harrods Knightsbridge",
                locationOrCategory = "London • Apple Pay NFC",
                amountText = "£1,240.00",
                timestamp = now - 3600_000L * 5
            ),
            WalletTransactionEntity(
                cardId = 7,
                merchantName = "Four Seasons Hotel",
                locationOrCategory = "Hospitality • Face ID Verified",
                amountText = "$1,890.00",
                timestamp = now - 3600_000L * 18
            ),
            WalletTransactionEntity(
                cardId = 5,
                merchantName = "Specialty Coffee Lounge",
                locationOrCategory = "Food & Drink • Contactless",
                amountText = "SAR 42.00",
                timestamp = now - 3600_000L * 26
            ),
            WalletTransactionEntity(
                cardId = 6,
                merchantName = "Trading 212 Cashback",
                locationOrCategory = "Daily 1.5% Reward • Credited",
                amountText = "+£18.60",
                timestamp = now - 3600_000L * 40,
                status = "Daily Cashback"
            )
        )
        walletDao.insertTransactions(sampleTransactions)
    }
}
