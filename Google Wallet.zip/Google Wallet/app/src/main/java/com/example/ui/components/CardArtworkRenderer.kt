package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.WalletCardEntity
import com.example.ui.theme.AlinmaCocoaBrown
import com.example.ui.theme.AlinmaPearlWhite
import com.example.ui.theme.AlrajhiRoyalBlue
import com.example.ui.theme.MastercardAmber
import com.example.ui.theme.MastercardRed
import com.example.ui.theme.RiyadObsidian
import com.example.ui.theme.SnbEmeraldGreen
import com.example.ui.theme.SnbLimePattern
import com.example.ui.theme.StcDeepPurple
import com.example.ui.theme.StcLavender
import com.example.ui.theme.StcMintGreen
import com.example.ui.theme.Trading212Black
import com.example.ui.theme.Trading212Cyan
import com.example.ui.theme.VisaRoyalBlue
import java.io.File

import com.example.hardware.rememberDeviceTiltOffset

/**
 * Renders an ISO/IEC 7810 ID-1 credit card (aspectRatio 1.586f) with Liquid Glass specular
 * edge highlights, gyroscope-reactive metallic glare, and either:
 * - User-imported Camera Roll / Local File photo (with optional Pure Photo Mode)
 * - Exact vector/Canvas recreation of the 8 reference screenshot cards
 */
@Composable
fun WalletCardArtwork(
    card: WalletCardEntity,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 18.dp,
    shadowElevation: Dp = 10.dp,
    enableLiquidShimmer: Boolean = true
) {
    val shape = RoundedCornerShape(cornerRadius)
    val deviceTilt by rememberDeviceTiltOffset()
    val infiniteTransition = rememberInfiniteTransition(label = "liquidCardSheen")
    val shimmerShift by infiniteTransition.animateFloat(
        initialValue = -0.35f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmerShift"
    )

    val isLightCard = card.presetStyle == "ALINMA_WHITE" || card.presetStyle == "SILVER_GEOMETRIC_VISA"
    val rimBrush = Brush.linearGradient(
        colors = if (isLightCard) {
            listOf(
                Color.White.copy(alpha = 0.98f),
                Color(0xFFCCE4FF).copy(alpha = 0.55f),
                Color.Black.copy(alpha = 0.10f),
                Color.White.copy(alpha = 0.88f)
            )
        } else {
            listOf(
                Color.White.copy(alpha = 0.48f),
                Color(0xFF8CC8FF).copy(alpha = 0.25f),
                Color.White.copy(alpha = 0.08f),
                Color.White.copy(alpha = 0.36f)
            )
        },
        start = Offset(0f, 0f),
        end = Offset(400f * (0.4f + shimmerShift.coerceIn(0f, 1f) * 0.6f), 260f)
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1.586f)
            .shadow(
                elevation = shadowElevation,
                shape = shape,
                ambientColor = Color.Black.copy(alpha = 0.28f),
                spotColor = Color.Black.copy(alpha = 0.34f)
            )
            .clip(shape)
            .border(width = 1.05.dp, brush = rimBrush, shape = shape)
    ) {
        // 1. Check if user imported a custom photo from Camera Roll / Local Files
        if (!card.customImagePath.isNullOrBlank()) {
            CustomPhotoCardContent(card = card)
        } else {
            // 2. Render exact preset card from screenshots
            when (card.presetStyle) {
                "ALRAJHI_BLUE" -> AlrajhiBlueCardContent(card)
                "SNB_GREEN" -> SnbGreenCardContent(card)
                "PURPLE_MINT" -> StcPurpleMintCardContent(card)
                "ALINMA_WHITE" -> AlinmaWhiteCardContent(card)
                "RIYAD_BLACK" -> RiyadBlackCardContent(card)
                "TRADING_212" -> Trading212CardContent(card)
                "SILVER_GEOMETRIC_VISA" -> SilverGeometricVisaCardContent(card)
                "GOLD_RESERVE" -> GoldReserveCardContent(card)
                "LIQUID_IRIDESCENT" -> LiquidIridescentCardContent(card)
                "CHASE_FREEDOM" -> ChaseFreedomCardContent(card)
                "TRAVELEX_NAVY" -> TravelexNavyCardContent(card)
                "GOOGLE_BLUE_CREDIT" -> GoogleBlueCreditCardContent(card)
                else -> CustomColorCardContent(card)
            }
        }

        // 3. Liquid Glass + Gyroscope-Reactive Specular Diagonal Sheen Overlay
        if (enableLiquidShimmer) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val tiltShift = (deviceTilt.x * 0.45f) + (deviceTilt.y * 0.25f)
                val startX = size.width * (shimmerShift + tiltShift)
                val sheenBrush = Brush.linearGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color.White.copy(alpha = 0.06f),
                        Color.White.copy(alpha = 0.16f),
                        Color(0xFFD6ECFF).copy(alpha = 0.09f),
                        Color.Transparent
                    ),
                    start = Offset(startX - size.width * 0.36f, 0f),
                    end = Offset(startX + size.width * 0.36f, size.height)
                )
                drawRect(brush = sheenBrush)
            }
        }
    }
}

@Composable
private fun CustomPhotoCardContent(card: WalletCardEntity) {
    val imageModel = remember(card.customImagePath) {
        val path = card.customImagePath.orEmpty()
        if (path.startsWith("content://") || path.startsWith("file://") || path.startsWith("http")) {
            Uri.parse(path)
        } else {
            File(path)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AsyncImage(
            model = imageModel,
            contentDescription = card.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Subtle bottom-left legibility gradient so the last 4 digits always pop clearly over any photo
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = if (!card.purePhotoMode) {
                            listOf(
                                Color.Black.copy(alpha = 0.25f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.42f)
                            )
                        } else {
                            listOf(
                                Color.Transparent,
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.28f)
                            )
                        }
                    )
                )
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            if (!card.purePhotoMode) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = card.title,
                        color = Color.White,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.4.sp
                    )
                    if (card.arabicSubtitle.isNotBlank()) {
                        Text(
                            text = card.arabicSubtitle,
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Always show the last 4 digits/letters (•••• 1234) at the bottom-left of photo cards!
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
                if (!card.purePhotoMode) {
                    CardNetworkBadge(network = card.network, visaTint = Color.White)
                }
            }
        }
    }
}

/**
 * Screenshot 2 Front Card: Alrajhi Bank (Royal Blue with Alrajhi knot logo, mada badge, •••• 1234, VISA)
 */
@Composable
private fun AlrajhiBlueCardContent(card: WalletCardEntity) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        AlrajhiRoyalBlue,
                        Color(0xFF003FA8),
                        Color(0xFF00348C)
                    )
                )
            )
            .padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        // Top-Right: Arabic + English title & Alrajhi geometric emblem
        Row(
            modifier = Modifier.align(Alignment.TopEnd),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = card.arabicSubtitle.ifBlank { "مصرف الراجحي" },
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 14.sp
                )
                Text(
                    text = card.title.ifBlank { "alrajhi bank" },
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 14.sp
                )
            }

            // Alrajhi 3-lobe geometric knot mark
            Canvas(modifier = Modifier.size(34.dp)) {
                val stroke = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                val cx = size.width / 2f
                val cy = size.height / 2f
                val r = size.minDimension * 0.36f
                // Outer hexagon-rounded knot
                val path = Path().apply {
                    moveTo(cx, cy - r)
                    lineTo(cx + r * 0.85f, cy - r * 0.35f)
                    lineTo(cx + r * 0.65f, cy + r * 0.75f)
                    lineTo(cx - r * 0.65f, cy + r * 0.75f)
                    lineTo(cx - r * 0.85f, cy - r * 0.35f)
                    close()
                }
                drawPath(path, color = Color.White, style = stroke)
                drawCircle(
                    color = Color.White,
                    radius = r * 0.42f,
                    center = Offset(cx, cy + r * 0.08f),
                    style = stroke
                )
            }
        }

        // Middle-Right: "مدى / mada" two-bar badge (exact Screenshot 2 placement)
        Row(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Box(
                    modifier = Modifier
                        .width(24.dp)
                        .height(6.dp)
                        .background(Color.White)
                )
                Box(
                    modifier = Modifier
                        .width(24.dp)
                        .height(6.dp)
                        .background(Color.White)
                )
            }
            Column(horizontalAlignment = Alignment.Start) {
                Text(
                    text = "مدى",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 10.sp
                )
                Text(
                    text = "mada",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 10.sp
                )
            }
        }

        // Bottom Row: •••• 1234 on left, VISA on right
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
            VisaWordmark(color = Color.White)
        }
    }
}

/**
 * Screenshot 2 4th Card: SNB AlAhli (Deep Emerald Green with Lime Calligraphic Pattern on Left & "SNB الأهلي" on Right)
 */
@Composable
private fun SnbGreenCardContent(card: WalletCardEntity) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SnbEmeraldGreen)
    ) {
        // Left-side Lime Green Calligraphic / Geometric Ribbon Pattern (exact Screenshot 2 look)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val patternWidth = size.width * 0.56f
            val ribbonStroke = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Square)
            val offsets = listOf(
                Offset(size.width * 0.05f, size.height * 0.08f) to Offset(size.width * 0.16f, size.height * 0.34f),
                Offset(size.width * 0.14f, size.height * 0.02f) to Offset(size.width * 0.28f, size.height * 0.28f),
                Offset(size.width * 0.25f, size.height * 0.12f) to Offset(size.width * 0.18f, size.height * 0.48f),
                Offset(size.width * 0.34f, size.height * 0.04f) to Offset(size.width * 0.44f, size.height * 0.26f),
                Offset(size.width * 0.08f, size.height * 0.36f) to Offset(size.width * 0.30f, size.height * 0.65f),
                Offset(size.width * 0.38f, size.height * 0.22f) to Offset(size.width * 0.49f, size.height * 0.46f)
            )
            offsets.forEach { (start, end) ->
                if (start.x < patternWidth) {
                    drawLine(
                        color = SnbLimePattern.copy(alpha = 0.85f),
                        start = start,
                        end = end,
                        strokeWidth = ribbonStroke.width,
                        cap = StrokeCap.Round
                    )
                }
            }
            // Subtle curved calligraphic arcs
            drawArc(
                color = SnbLimePattern.copy(alpha = 0.75f),
                startAngle = 190f,
                sweepAngle = 140f,
                useCenter = false,
                topLeft = Offset(size.width * 0.03f, size.height * 0.05f),
                size = Size(size.width * 0.24f, size.height * 0.36f),
                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Butt)
            )
            drawArc(
                color = SnbLimePattern.copy(alpha = 0.70f),
                startAngle = 20f,
                sweepAngle = 135f,
                useCenter = false,
                topLeft = Offset(size.width * 0.20f, -size.height * 0.04f),
                size = Size(size.width * 0.26f, size.height * 0.38f),
                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Butt)
            )
        }

        // Top-Right: "SNB الأهلي" with rooftop arch above N
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 14.dp, end = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Rooftop chevron arch over SNB
                Canvas(modifier = Modifier.size(width = 20.dp, height = 7.dp)) {
                    val path = Path().apply {
                        moveTo(0f, size.height)
                        lineTo(size.width / 2f, 0f)
                        lineTo(size.width, size.height)
                    }
                    drawPath(
                        path = path,
                        color = Color.White,
                        style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
                Text(
                    text = card.title.ifBlank { "SNB" },
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp,
                    lineHeight = 22.sp
                )
            }

            Text(
                text = card.arabicSubtitle.ifBlank { "الأهلي" },
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Bottom Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
            CardNetworkBadge(network = card.network, visaTint = Color.White)
        }
    }
}

/**
 * Screenshot 2 3rd Card: Deep Purple card with Lavender & Emerald Mint color blocks
 */
@Composable
private fun StcPurpleMintCardContent(card: WalletCardEntity) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(StcDeepPurple)
    ) {
        // Architectural color blocks matching Screenshot 2's 3rd card band
        Canvas(modifier = Modifier.fillMaxSize()) {
            val topBandHeight = size.height * 0.085f
            val blockHeight = size.height * 0.28f
            // Left Lavender block
            drawRect(
                color = StcLavender,
                topLeft = Offset(0f, topBandHeight),
                size = Size(size.width * 0.375f, blockHeight)
            )
            // Center Emerald Mint block
            drawRect(
                color = StcMintGreen,
                topLeft = Offset(size.width * 0.375f, topBandHeight),
                size = Size(size.width * 0.12f, blockHeight)
            )
        }

        // Bottom Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
            CardNetworkBadge(network = card.network, visaTint = Color.White)
        }
    }
}

/**
 * Screenshot 2 2nd Card: Alinma Bank (Pearl White with Cocoa Brown "مصرف الإنماء / alinma bank" & Square Pillar Logo)
 */
@Composable
private fun AlinmaWhiteCardContent(card: WalletCardEntity) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AlinmaPearlWhite)
            .padding(horizontal = 20.dp, vertical = 15.dp)
    ) {
        // Top-Right: مصرف الإنماء / alinma bank + brown square icon
        Row(
            modifier = Modifier.align(Alignment.TopEnd),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = card.arabicSubtitle.ifBlank { "مصرف الإنماء" },
                    color = AlinmaCocoaBrown,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 16.sp
                )
                Text(
                    text = card.title.ifBlank { "alinma bank" },
                    color = AlinmaCocoaBrown,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 16.sp
                )
            }

            // Brown square emblem with white vertical pillar (exact Screenshot 2 mark)
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .background(AlinmaCocoaBrown, RoundedCornerShape(3.dp)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .width(6.dp)
                        .height(18.dp)
                        .background(AlinmaPearlWhite, RoundedCornerShape(1.dp))
                )
            }
        }

        // Bottom Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = AlinmaCocoaBrown)
            CardNetworkBadge(network = card.network, visaTint = AlinmaCocoaBrown)
        }
    }
}

/**
 * Screenshot 2 Top Back Card: Riyad Bank (Obsidian Black with White S-Cube Logo & "بنك الرياض / Riyad Bank" at Top-Left)
 */
@Composable
private fun RiyadBlackCardContent(card: WalletCardEntity) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RiyadObsidian)
    ) {
        // Diagonal dark-gray sheen on right side (exact Screenshot 2 top card detail)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val sheenPath = Path().apply {
                moveTo(size.width * 0.86f, 0f)
                lineTo(size.width, 0f)
                lineTo(size.width, size.height)
                lineTo(size.width * 0.62f, size.height)
                close()
            }
            drawPath(path = sheenPath, color = Color(0xFF23252B))
        }

        // Top-Left: White geometric stepped emblem + "بنك الرياض / Riyad Bank"
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 22.dp, top = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Stepped S-Cube Emblem
            Canvas(modifier = Modifier.size(24.dp)) {
                val w = size.width
                val h = size.height
                drawRect(
                    color = Color.White.copy(alpha = 0.65f),
                    topLeft = Offset(w * 0.35f, 0f),
                    size = Size(w * 0.55f, h * 0.52f)
                )
                drawRect(
                    color = Color.White,
                    topLeft = Offset(0f, h * 0.32f),
                    size = Size(w * 0.58f, h * 0.58f)
                )
            }

            Column {
                Text(
                    text = card.arabicSubtitle.ifBlank { "بنك الرياض" },
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 13.sp
                )
                Text(
                    text = card.title.ifBlank { "Riyad Bank" },
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 13.sp
                )
            }
        }

        // Bottom Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
            CardNetworkBadge(network = card.network, visaTint = Color.White)
        }
    }
}

/**
 * Screenshot 1 Hero Card: TRADING 212 (Pitch Black card, "TR^DING 212" with blue chevron A, •••• 1234, Mastercard circles)
 */
@Composable
private fun Trading212CardContent(card: WalletCardEntity) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Trading212Black)
            .padding(horizontal = 22.dp, vertical = 20.dp)
    ) {
        // Top-Left: "TR^DING 212" with electric cyan/blue chevron for the 'A'
        Row(
            modifier = Modifier.align(Alignment.TopStart),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TR",
                color = Color.White,
                fontSize = 21.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.3.sp
            )
            // Blue chevron '^' for A
            Canvas(
                modifier = Modifier
                    .padding(horizontal = 1.dp)
                    .size(width = 15.dp, height = 16.dp)
            ) {
                val path = Path().apply {
                    moveTo(size.width * 0.12f, size.height * 0.78f)
                    lineTo(size.width * 0.50f, size.height * 0.16f)
                    lineTo(size.width * 0.88f, size.height * 0.78f)
                }
                drawPath(
                    path = path,
                    color = Trading212Cyan,
                    style = Stroke(width = 3.4.dp.toPx(), cap = StrokeCap.Square, join = StrokeJoin.Miter)
                )
            }
            Text(
                text = "DING 212",
                color = Color.White,
                fontSize = 21.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.3.sp
            )
        }

        // Bottom Row: •••• 1234 on left, large Mastercard overlapping circles on right (Screenshot 1)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
            MastercardCirclesLogo(circleDiameter = 42.dp)
        }
    }
}

/**
 * Screenshot 3 Hero Card: Silver / Platinum Geometric Visa Card with diagonal architectural planes,
 * royal blue "VISA" at top-right, and white "•••• 1234" at bottom-left.
 */
@Composable
private fun SilverGeometricVisaCardContent(card: WalletCardEntity) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFDADCE0),
                        Color(0xFFC2C4CA),
                        Color(0xFF9FA2A9)
                    )
                )
            )
    ) {
        // Exact 45-degree geometric folded planes from Screenshot 3
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Outer diagonal fold
            val fold1 = Path().apply {
                moveTo(w * 0.52f, 0f)
                lineTo(w * 0.78f, 0f)
                lineTo(w * 0.26f, h * 0.84f)
                lineTo(w * 0.42f, h)
                lineTo(w * 0.18f, h)
                lineTo(w * 0.04f, h * 0.68f)
                close()
            }
            drawPath(
                path = fold1,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFFC9CBD0), Color(0xFFA8ABB2))
                )
            )

            // Second inner diagonal fold
            val fold2 = Path().apply {
                moveTo(w * 0.78f, 0f)
                lineTo(w, 0f)
                lineTo(w * 0.46f, h * 0.76f)
                lineTo(w * 0.64f, h)
                lineTo(w * 0.36f, h)
                lineTo(w * 0.22f, h * 0.74f)
                close()
            }
            drawPath(
                path = fold2,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFFBABDC4), Color(0xFF94979E))
                )
            )

            // Third deepest右下 geometric plane
            val fold3 = Path().apply {
                moveTo(w, h * 0.16f)
                lineTo(w, h)
                lineTo(w * 0.56f, h)
                lineTo(w * 0.45f, h * 0.76f)
                close()
            }
            drawPath(
                path = fold3,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFF8E9198), Color(0xFFADB0B7))
                )
            )
        }

        // Top-Right: Royal Blue VISA logo (exact Screenshot 3 position!)
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 18.dp, end = 22.dp)
        ) {
            VisaWordmark(color = VisaRoyalBlue, fontSizeSp = 26f)
        }

        // Bottom-Left: •••• 1234 in crisp white (exact Screenshot 3 position!)
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 20.dp, bottom = 18.dp)
        ) {
            MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
        }
    }
}

/**
 * Screenshot 3 Bottom Peeking Card: Sovereign Champagne Gold Reserve
 */
@Composable
private fun GoldReserveCardContent(card: WalletCardEntity) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFD9BC73),
                        Color(0xFFC59B42),
                        Color(0xFFA87E28)
                    )
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val arcPath = Path().apply {
                moveTo(size.width * 0.55f, 0f)
                quadraticTo(
                    size.width * 0.78f,
                    size.height * 0.5f,
                    size.width * 0.48f,
                    size.height
                )
                lineTo(size.width, size.height)
                lineTo(size.width, 0f)
                close()
            }
            drawPath(
                path = arcPath,
                color = Color(0xFFE8CE89).copy(alpha = 0.35f)
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Text(
                text = card.title,
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopStart)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
                CardNetworkBadge(network = card.network, visaTint = Color.White)
            }
        }
    }
}

/**
 * AI-Generated Iridescent Liquid Glass Titanium Card
 */
@Composable
private fun LiquidIridescentCardContent(card: WalletCardEntity) {
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.img_liquid_iridescent_card_1791565427149),
            contentDescription = card.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.18f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.38f)
                        )
                    )
                )
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Text(
                text = card.title,
                color = Color.White,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopStart)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
                CardNetworkBadge(network = card.network, visaTint = Color.White)
            }
        }
    }
}

@Composable
private fun CustomColorCardContent(card: WalletCardEntity) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(card.primaryColorHex),
                        Color(card.secondaryColorHex)
                    )
                )
            )
            .padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Text(
                text = card.title,
                color = Color.White,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )
            if (card.arabicSubtitle.isNotBlank()) {
                Text(
                    text = card.arabicSubtitle,
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
            CardNetworkBadge(network = card.network, visaTint = Color.White)
        }
    }
}

/**
 * Uploaded Google Wallet Image 1 & 2 Card: Chase Freedom Unlimited (Deep sapphire navy with cyan wave,
 * white Chase octagon + italic "freedom" + green "UNLIMITED", •••• 1234, VISA)
 */
@Composable
private fun ChaseFreedomCardContent(card: WalletCardEntity) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF002D62),
                        Color(0xFF004B9B),
                        Color(0xFF001C42)
                    )
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val wavePath = Path().apply {
                moveTo(0f, h * 0.72f)
                quadraticTo(w * 0.48f, h * 0.65f, w, h * 0.28f)
                lineTo(w, h * 0.45f)
                quadraticTo(w * 0.50f, h * 0.78f, 0f, h * 0.84f)
                close()
            }
            drawPath(
                path = wavePath,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFF00A8E8).copy(alpha = 0.55f),
                        Color(0xFF48CAE4).copy(alpha = 0.75f),
                        Color(0xFF0077B6).copy(alpha = 0.25f)
                    )
                )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Row(
                modifier = Modifier.align(Alignment.TopStart),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Chase Octagon Emblem
                Canvas(modifier = Modifier.size(26.dp)) {
                    val s = size.minDimension
                    drawRoundRect(
                        color = Color.White,
                        topLeft = Offset(s * 0.08f, s * 0.08f),
                        size = Size(s * 0.84f, s * 0.84f),
                        cornerRadius = CornerRadius(s * 0.22f, s * 0.22f),
                        style = Stroke(width = 4.dp.toPx())
                    )
                }
                Column {
                    Text(
                        text = card.title.ifBlank { "freedom" },
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontStyle = FontStyle.Italic,
                        lineHeight = 20.sp
                    )
                    Text(
                        text = card.arabicSubtitle.ifBlank { "UNLIMITED" },
                        color = Color(0xFF68D345),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp,
                        lineHeight = 11.sp
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
                CardNetworkBadge(network = card.network, visaTint = Color.White)
            }
        }
    }
}

/**
 * Uploaded Google Wallet Image 3 & 4 Card: Travelex Money Card (Midnight navy with glowing cyan/teal open ring,
 * "Travelex Money Card" top-left, "platinum prepaid" top-right, •••• 1234, Mastercard)
 */
@Composable
private fun TravelexNavyCardContent(card: WalletCardEntity) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF15254B))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val ringCenter = Offset(size.width * 0.58f, size.height * 0.50f)
            val ringRadius = size.minDimension * 0.26f
            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        Color(0xFF1CB5E0),
                        Color(0xFF28B59B),
                        Color(0xFF0072FF),
                        Color.Transparent
                    ),
                    center = ringCenter
                ),
                startAngle = -65f,
                sweepAngle = 290f,
                useCenter = false,
                topLeft = Offset(ringCenter.x - ringRadius, ringCenter.y - ringRadius),
                size = Size(ringRadius * 2f, ringRadius * 2f),
                style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column {
                    Text(
                        text = "Travelex",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        lineHeight = 16.sp
                    )
                    Text(
                        text = card.title.ifBlank { "Money Card" },
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        lineHeight = 22.sp
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "platinum",
                        color = Color.White.copy(alpha = 0.92f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 16.sp
                    )
                    Text(
                        text = card.arabicSubtitle.ifBlank { "prepaid" },
                        color = Color.White.copy(alpha = 0.92f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 16.sp
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
                MastercardCirclesLogo(circleDiameter = 40.dp)
            }
        }
    }
}

/**
 * Uploaded Google Wallet Image 5 Card: Google Blue Credit Card with overlapping geometric blue circles,
 * white circular emblem top-left, "Credit" top-right, •••• 6789 bottom-left, stylized "V" bottom-right.
 */
@Composable
private fun GoogleBlueCreditCardContent(card: WalletCardEntity) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B57D0))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawCircle(
                color = Color(0xFF1B6EF3),
                radius = w * 0.48f,
                center = Offset(w * 0.72f, h * 0.42f)
            )
            drawCircle(
                color = Color(0xFF3B82F6).copy(alpha = 0.45f),
                radius = w * 0.36f,
                center = Offset(w * 0.56f, h * 0.85f)
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // White circular split emblem (exact match to Image 5)
                Canvas(modifier = Modifier.size(30.dp)) {
                    drawCircle(color = Color.White)
                    drawLine(
                        color = Color(0xFF0B57D0),
                        start = Offset(0f, size.height * 0.5f),
                        end = Offset(size.width * 0.65f, size.height * 0.5f),
                        strokeWidth = 3.dp.toPx()
                    )
                    drawCircle(
                        color = Color(0xFF0B57D0),
                        radius = size.minDimension * 0.16f,
                        center = Offset(size.width / 2f, size.height / 2f)
                    )
                }

                Text(
                    text = card.arabicSubtitle.ifBlank { "Credit" },
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                MaskedCardNumberBadge(lastFour = card.lastFourDigits, textColor = Color.White)
                CardNetworkBadge(network = card.network, visaTint = Color.White.copy(alpha = 0.88f))
            }
        }
    }
}

@Composable
fun MaskedCardNumberBadge(
    lastFour: String,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = "••••",
            color = textColor.copy(alpha = 0.92f),
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
        Text(
            text = lastFour.takeLast(4).ifBlank { "1234" },
            color = textColor,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun CardNetworkBadge(
    network: String,
    visaTint: Color = Color.White
) {
    when (network.uppercase()) {
        "MASTERCARD", "VIRTUAL_MC" -> MastercardCirclesLogo(circleDiameter = 34.dp)
        else -> VisaWordmark(color = visaTint)
    }
}

@Composable
fun VisaWordmark(
    color: Color,
    fontSizeSp: Float = 24f
) {
    Text(
        text = "VISA",
        color = color,
        fontSize = fontSizeSp.sp,
        fontWeight = FontWeight.ExtraBold,
        fontStyle = FontStyle.Italic,
        letterSpacing = (-0.8).sp,
        textAlign = TextAlign.End
    )
}

@Composable
fun MastercardCirclesLogo(
    circleDiameter: Dp = 38.dp
) {
    val overlapFactor = 0.62f
    val totalWidth = circleDiameter * (1f + overlapFactor)
    Canvas(modifier = Modifier.size(width = totalWidth, height = circleDiameter)) {
        val r = size.height / 2f
        val leftCenter = Offset(r, r)
        val rightCenter = Offset(size.width - r, r)

        drawCircle(
            color = MastercardRed,
            radius = r,
            center = leftCenter
        )
        drawCircle(
            color = MastercardAmber.copy(alpha = 0.90f),
            radius = r,
            center = rightCenter
        )
    }
}
