package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.R
import com.example.data.WalletCardEntity
import com.example.hardware.rememberDeviceTiltOffset
import com.example.ui.HomeDisplayMode
import com.example.ui.StackPresetFilter
import com.example.ui.WalletEcosystemTheme
import com.example.ui.WalletUiState
import com.example.ui.components.ApplePayBiometricStage
import com.example.ui.components.ConfirmationIconType
import com.example.ui.components.DoubleClickToPaySideIndicator
import com.example.ui.components.GoogleBluePrimary
import com.example.ui.components.GoogleBrightBlue
import com.example.ui.components.GoogleLightBluePill
import com.example.ui.components.GoogleWalletConcentricBlueBackdrop
import com.example.ui.components.GoogleWalletHeaderBar
import com.example.ui.components.GoogleWalletNfcAndDoneStage
import com.example.ui.components.LiquidGlassButton
import com.example.ui.components.LiquidGlassPaymentNotificationBanner
import com.example.ui.components.PaymentStage
import com.example.ui.components.ThemeAppIconBadge
import com.example.ui.components.WalletCardArtwork
import com.example.ui.components.WalletHeaderBar
import com.example.ui.components.liquidGlassSurface
import com.example.ui.components.liquidPressable
import com.example.ui.theme.IosPrimaryBlue
import kotlin.math.absoluteValue

@Composable
fun WalletHomeScreen(
    uiState: WalletUiState,
    onAddCardClick: () -> Unit,
    onSearchToggle: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onMoreOptionsClick: () -> Unit,
    onCardChosenFromStack: (WalletCardEntity) -> Unit,
    onCardLongPress: (WalletCardEntity) -> Unit,
    onSwapCardInExpress: (WalletCardEntity) -> Unit,
    onStartFaceIdVerification: () -> Unit,
    onGoogleWalletCardSwiped: (WalletCardEntity) -> Unit,
    onGoogleWalletCardChosenPay: (WalletCardEntity) -> Unit,
    onCancelGoogleWalletPay: () -> Unit,
    onSwitchDisplayMode: (HomeDisplayMode) -> Unit,
    onSetStackFilter: (StackPresetFilter) -> Unit,
    onUnlockWalletWithBiometrics: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isGoogleWallet = uiState.larpPrefs.ecosystemTheme == WalletEcosystemTheme.GOOGLE_WALLET

    BackHandler(
        enabled = (!isGoogleWallet && uiState.displayMode == HomeDisplayMode.APPLE_PAY_EXPRESS) ||
            uiState.isSearchVisible ||
            (isGoogleWallet && uiState.isAutoAnimatingPayment)
    ) {
        when {
            isGoogleWallet && uiState.isAutoAnimatingPayment -> onCancelGoogleWalletPay()
            uiState.isSearchVisible -> onSearchToggle()
            else -> onSwitchDisplayMode(HomeDisplayMode.WALLET_STACK_HOME)
        }
    }

    val deviceTilt by rememberDeviceTiltOffset()

    val backgroundColor = if (isGoogleWallet) {
        if (uiState.larpPrefs.darkTheme) Color(0xFF131314) else Color.White
    } else {
        MaterialTheme.colorScheme.background
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = backgroundColor,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        if (uiState.larpPrefs.isAppLocked) {
            BiometricLockedOverlay(
                isGoogleWallet = isGoogleWallet,
                appName = uiState.larpPrefs.currentThemeAppName,
                appIconPath = null,
                activeCard = uiState.activeHeroCard,
                darkTheme = uiState.larpPrefs.darkTheme,
                confirmationIconType = uiState.larpPrefs.confirmationIconType,
                onUnlockClick = onUnlockWalletWithBiometrics,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            )
            return@Scaffold
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            AnimatedContent(
                targetState = uiState.larpPrefs.ecosystemTheme,
                transitionSpec = {
                    (fadeIn(tween(260)) + scaleIn(initialScale = 0.96f)) togetherWith
                        (fadeOut(tween(180)) + scaleOut(targetScale = 0.96f))
                },
                label = "ecosystemThemeSwitch"
            ) { ecosystemTheme ->
                when (ecosystemTheme) {
                    WalletEcosystemTheme.GOOGLE_WALLET -> {
                        GoogleWalletHomeContent(
                            uiState = uiState,
                            deviceTilt = deviceTilt,
                            onAddCardClick = onAddCardClick,
                            onGoogleProfileSettingsClick = onMoreOptionsClick,
                            onCardSwiped = onGoogleWalletCardSwiped,
                            onCardChosenPay = onGoogleWalletCardChosenPay,
                            onCardLongPress = onCardLongPress,
                            onCancelPay = onCancelGoogleWalletPay
                        )
                    }
                    WalletEcosystemTheme.APPLE_PAY -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 600.dp)
                                .align(Alignment.TopCenter),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            AnimatedContent(
                                targetState = uiState.displayMode,
                                transitionSpec = {
                                    if (targetState == HomeDisplayMode.APPLE_PAY_EXPRESS) {
                                        (fadeIn(tween(240)) +
                                            scaleIn(
                                                initialScale = 0.92f,
                                                animationSpec = spring(
                                                    dampingRatio = Spring.DampingRatioLowBouncy,
                                                    stiffness = Spring.StiffnessMediumLow
                                                )
                                            ) +
                                            slideInVertically(
                                                initialOffsetY = { it / 9 },
                                                animationSpec = spring(
                                                    dampingRatio = Spring.DampingRatioLowBouncy,
                                                    stiffness = Spring.StiffnessMediumLow
                                                )
                                            )) togetherWith
                                            (fadeOut(tween(180)) + scaleOut(targetScale = 0.95f))
                                    } else {
                                        (fadeIn(tween(240)) +
                                            scaleIn(
                                                initialScale = 0.94f,
                                                animationSpec = spring(
                                                    dampingRatio = Spring.DampingRatioLowBouncy,
                                                    stiffness = Spring.StiffnessMediumLow
                                                )
                                            )) togetherWith
                                            (fadeOut(tween(180)) +
                                                slideOutVertically(targetOffsetY = { it / 10 }))
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                label = "walletModeTransition"
                            ) { mode ->
                                when (mode) {
                                    HomeDisplayMode.WALLET_STACK_HOME -> {
                                        AllCardsInOneStackContent(
                                            uiState = uiState,
                                            deviceTilt = deviceTilt,
                                            onAddCardClick = onAddCardClick,
                                            onSearchToggle = onSearchToggle,
                                            onSearchQueryChange = onSearchQueryChange,
                                            onMoreOptionsClick = onMoreOptionsClick,
                                            onCardChosenFromStack = onCardChosenFromStack,
                                            onCardLongPress = onCardLongPress,
                                            onSetStackFilter = onSetStackFilter
                                        )
                                    }
                                    HomeDisplayMode.APPLE_PAY_EXPRESS -> {
                                        ApplePayExpressContent(
                                            uiState = uiState,
                                            deviceTilt = deviceTilt,
                                            onBackToStack = { onSwitchDisplayMode(HomeDisplayMode.WALLET_STACK_HOME) },
                                            onCardInfoClick = { card -> onCardLongPress(card) },
                                            onSwapCard = onSwapCardInExpress,
                                            onStartFaceIdVerification = onStartFaceIdVerification
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Top Drop-Down Liquid Glass Payment Notification Banner when Payment Completes (Done or Declined)
            val isPaymentFinished = uiState.paymentStage == PaymentStage.DONE || uiState.paymentStage == PaymentStage.DECLINED
            LiquidGlassPaymentNotificationBanner(
                visible = (uiState.displayMode == HomeDisplayMode.APPLE_PAY_EXPRESS || isGoogleWallet) && isPaymentFinished,
                card = uiState.activeHeroCard,
                merchantName = uiState.larpPrefs.simulatedMerchantName,
                amountText = uiState.larpPrefs.simulatedAmountText,
                isGoogleWallet = isGoogleWallet,
                appName = uiState.larpPrefs.currentThemeAppName,
                appIconPath = null,
                darkTheme = uiState.larpPrefs.darkTheme,
                isDeclined = uiState.paymentStage == PaymentStage.DECLINED,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .widthIn(max = 600.dp)
            )
        }
    }
}

/**
 * Google Wallet Theme Home Screen:
 * - Top Left: Button like Google to Add Card (with custom/default Google Wallet icon & name)
 * - Top Right: Customizable Google Profile Picture (opens General Settings)
 * - Above Card: Google Contactless NFC circle -> 7s automatic NFC waves & progress arc -> Blue Done Checkmark
 * - Middle: Horizontal Swipeable Card Carousel (`HorizontalPager`) that locks card swiping during the 7s NFC chip process
 * - Animated EMV chip energy wave across the card while paying
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GoogleWalletHomeContent(
    uiState: WalletUiState,
    deviceTilt: Offset,
    onAddCardClick: () -> Unit,
    onGoogleProfileSettingsClick: () -> Unit,
    onCardSwiped: (WalletCardEntity) -> Unit,
    onCardChosenPay: (WalletCardEntity) -> Unit,
    onCardLongPress: (WalletCardEntity) -> Unit,
    onCancelPay: () -> Unit
) {
    val cards = uiState.allCards
    val isPayingOrDone = uiState.isAutoAnimatingPayment ||
        uiState.paymentStage == PaymentStage.NFC_HOLD_NEAR_READER ||
        uiState.paymentStage == PaymentStage.DONE

    val initialPageIndex = remember(cards.size) {
        val activeId = uiState.activeHeroCard?.id
        val foundIdx = cards.indexOfFirst { it.id == activeId }
        if (foundIdx >= 0) foundIdx else 0
    }

    val pagerState = rememberPagerState(
        initialPage = initialPageIndex.coerceIn(0, (cards.size - 1).coerceAtLeast(0)),
        pageCount = { cards.size }
    )

    LaunchedEffect(pagerState.currentPage, cards, isPayingOrDone) {
        if (!isPayingOrDone) {
            cards.getOrNull(pagerState.currentPage)?.let { currentCard ->
                onCardSwiped(currentCard)
            }
        }
    }

    // Animated EMV chip energy wave phase during the 7-second NFC scan
    val infiniteTransition = rememberInfiniteTransition(label = "googleCardChipWave")
    val chipEnergyWave by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "chipEnergyWave"
    )

    val activePayLiftDp by animateDpAsState(
        targetValue = when (uiState.paymentStage) {
            PaymentStage.NFC_HOLD_NEAR_READER -> (-8).dp
            PaymentStage.DONE -> (-14).dp
            else -> 0.dp
        },
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "googleCardPayLift"
    )

    val activePayScale by animateFloatAsState(
        targetValue = when (uiState.paymentStage) {
            PaymentStage.NFC_HOLD_NEAR_READER -> 1.02f
            PaymentStage.DONE -> 1.04f
            else -> 1f
        },
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "googleCardPayScale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("google_wallet_home_container")
    ) {
        // Concentric Blue Rings behind the card when paying or Done (exact match to Image 5)
        GoogleWalletConcentricBlueBackdrop(
            visible = isPayingOrDone,
            isDone = uiState.paymentStage == PaymentStage.DONE
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .align(Alignment.TopCenter),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Google Wallet Top Bar (Left: Add Card button, Right: Custom Google Profile Pic -> Settings)
            GoogleWalletHeaderBar(
                darkTheme = uiState.larpPrefs.darkTheme,
                appName = uiState.larpPrefs.currentThemeAppName,
                customAppIconPath = null,
                googleProfilePhotoPath = uiState.larpPrefs.googleProfilePhotoPath,
                isPayingOrDone = isPayingOrDone,
                onAddCardClick = onAddCardClick,
                onGoogleProfileSettingsClick = onGoogleProfileSettingsClick,
                onCancelPaymentClick = onCancelPay
            )

            Spacer(modifier = Modifier.weight(0.50f))

            // 2. Top-Center Google Contactless NFC Circle / Blue Done Checkmark Circle
            GoogleWalletNfcAndDoneStage(
                stage = uiState.paymentStage,
                nfcProgress = uiState.nfcProgress,
                nfcSecondsRemaining = uiState.nfcSecondsRemaining,
                darkTheme = uiState.larpPrefs.darkTheme,
                onTapCircle = {
                    val activeCard = cards.getOrNull(pagerState.currentPage) ?: uiState.activeHeroCard
                    if (activeCard != null && !isPayingOrDone) {
                        onCardChosenPay(activeCard)
                    }
                }
            )

            Spacer(modifier = Modifier.height(20.dp))

            // 3. Middle Horizontal Swipeable Card Carousel
            // LOCKED (`userScrollEnabled = !isPayingOrDone`) when NFC chip process is active!
            if (cards.isNotEmpty()) {
                HorizontalPager(
                    state = pagerState,
                    userScrollEnabled = !isPayingOrDone,
                    contentPadding = PaddingValues(horizontal = 24.dp),
                    pageSpacing = 12.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .offset(y = activePayLiftDp)
                        .testTag("google_wallet_horizontal_pager")
                ) { page ->
                    val card = cards[page]
                    val isCurrentPage = page == pagerState.currentPage
                    val pageOffset = (
                        (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
                    ).absoluteValue

                    val cardScale = (1f - (pageOffset.coerceIn(0f, 1f) * 0.06f)) *
                        (if (isCurrentPage) activePayScale else 1f)

                    // Fade out peeking neighbor cards while actively paying so focus is 100% on the locked card
                    val neighborAlpha by animateFloatAsState(
                        targetValue = if (isPayingOrDone && !isCurrentPage) 0.15f else 1f,
                        animationSpec = tween(250),
                        label = "neighborAlpha_$page"
                    )

                    val interactionSource = remember { MutableInteractionSource() }
                    val isPressed by interactionSource.collectIsPressedAsState()
                    val pressScale by animateFloatAsState(
                        targetValue = if (isPressed && !isPayingOrDone) 0.96f else 1f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioLowBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        label = "googleCardPressScale_$page"
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .graphicsLayer {
                                alpha = neighborAlpha
                                scaleX = cardScale * pressScale
                                scaleY = cardScale * pressScale
                                rotationX = deviceTilt.y * 3.8f
                                rotationY = (-deviceTilt.x * 4.2f) + (pageOffset * -4f)
                                cameraDistance = 16f * density
                            }
                            .combinedClickable(
                                interactionSource = interactionSource,
                                indication = null,
                                onClick = {
                                    // Choosing a card in Google Wallet automatically starts the 7s NFC -> Blue Done flow without verification!
                                    if (!isPayingOrDone) {
                                        onCardChosenPay(card)
                                    }
                                },
                                onLongClick = {
                                    if (!isPayingOrDone) {
                                        onCardLongPress(card)
                                    }
                                }
                            )
                            .drawWithContent {
                                drawContent()
                                // Animated EMV Chip & Contactless Energy Sweep across the locked card during the 7s NFC process
                                if (isCurrentPage && uiState.paymentStage == PaymentStage.NFC_HOLD_NEAR_READER) {
                                    val sweepX = size.width * (-0.2f + chipEnergyWave * 1.4f)
                                    drawRoundRect(
                                        brush = Brush.linearGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                GoogleBrightBlue.copy(alpha = 0.28f),
                                                Color.White.copy(alpha = 0.38f),
                                                GoogleBrightBlue.copy(alpha = 0.28f),
                                                Color.Transparent
                                            ),
                                            start = Offset(sweepX - 130f, 0f),
                                            end = Offset(sweepX + 130f, size.height)
                                        ),
                                        cornerRadius = CornerRadius(18.dp.toPx(), 18.dp.toPx())
                                    )
                                    // Glowing Google Blue NFC border around the locked card
                                    drawRoundRect(
                                        color = GoogleBrightBlue.copy(alpha = 0.78f),
                                        cornerRadius = CornerRadius(18.dp.toPx(), 18.dp.toPx()),
                                        style = Stroke(width = 2.6.dp.toPx())
                                    )
                                } else if (isCurrentPage && uiState.paymentStage == PaymentStage.DONE) {
                                    drawRoundRect(
                                        color = GoogleBrightBlue,
                                        cornerRadius = CornerRadius(18.dp.toPx(), 18.dp.toPx()),
                                        style = Stroke(width = 3.dp.toPx())
                                    )
                                }
                            }
                            .testTag("google_pager_card_${card.id}")
                    ) {
                        WalletCardArtwork(
                            card = card,
                            cornerRadius = 18.dp,
                            shadowElevation = if (isCurrentPage) 16.dp else 6.dp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // 4. Google Wallet Pagination Dots OR Locked Chip Status Indicator
                AnimatedContent(
                    targetState = uiState.paymentStage,
                    transitionSpec = {
                        (fadeIn(tween(200)) + scaleIn(initialScale = 0.90f)) togetherWith
                            (fadeOut(tween(150)) + scaleOut(targetScale = 0.90f))
                    },
                    label = "dotsOrLockedStatus"
                ) { currentStage ->
                    when (currentStage) {
                        PaymentStage.NFC_HOLD_NEAR_READER, PaymentStage.PROCESSING -> {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(
                                        if (uiState.larpPrefs.darkTheme) {
                                            Color(0xFF1E1F22).copy(alpha = 0.90f)
                                        } else {
                                            Color.White.copy(alpha = 0.92f)
                                        }
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = GoogleBrightBlue.copy(alpha = 0.45f),
                                        shape = RoundedCornerShape(50)
                                    )
                                    .padding(horizontal = 14.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = GoogleBrightBlue,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "Card locked for chip reader",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (uiState.larpPrefs.darkTheme) Color(0xFFD3E3FD) else GoogleBluePrimary
                                )
                            }
                        }
                        PaymentStage.DECLINED -> {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(Color(0xFFD93025))
                                    .padding(horizontal = 16.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = "Payment Declined",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                        PaymentStage.DONE -> {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(GoogleBluePrimary)
                                    .padding(horizontal = 16.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = "Paid with ${uiState.larpPrefs.currentThemeAppName}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                        PaymentStage.FACE_ID_SCANNING -> {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                cards.forEachIndexed { index, _ ->
                                    val isSelected = index == pagerState.currentPage
                                    val dotSize by animateDpAsState(
                                        targetValue = if (isSelected) 7.dp else 5.dp,
                                        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy),
                                        label = "googleDotSize_$index"
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(dotSize)
                                            .clip(CircleShape)
                                            .background(
                                                if (isSelected) {
                                                    if (uiState.larpPrefs.darkTheme) Color(0xFF8AB4F8) else GoogleBluePrimary
                                                } else {
                                                    if (uiState.larpPrefs.darkTheme) Color(0xFF444746) else GoogleLightBluePill
                                                }
                                            )
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(28.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(if (uiState.larpPrefs.darkTheme) Color(0xFF1E1F22) else GoogleLightBluePill),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CreditCard,
                            contentDescription = null,
                            tint = GoogleBluePrimary,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "No cards in Google Wallet",
                        fontSize = 19.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (uiState.larpPrefs.darkTheme) Color(0xFFE3E3E3) else Color(0xFF1F1F1F)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Tap '+ Add card' at the top to add your own card with your photo and last 4 digits.",
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        color = if (uiState.larpPrefs.darkTheme) Color(0xFFC4C7C5) else Color(0xFF444746)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(GoogleBluePrimary)
                            .liquidPressable(pressScale = 0.92f, onClick = onAddCardClick)
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Text(
                            text = "Add Card",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // Clean bottom space — no passes or extra items below the card, just the card!
            Spacer(modifier = Modifier.weight(1.15f))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AllCardsInOneStackContent(
    uiState: WalletUiState,
    deviceTilt: Offset,
    onAddCardClick: () -> Unit,
    onSearchToggle: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onMoreOptionsClick: () -> Unit,
    onCardChosenFromStack: (WalletCardEntity) -> Unit,
    onCardLongPress: (WalletCardEntity) -> Unit,
    onSetStackFilter: (StackPresetFilter) -> Unit
) {
    val stackCards = uiState.visibleStackCards
    val scrollState = rememberScrollState()
    var stackEntered by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        stackEntered = true
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(bottom = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        WalletHeaderBar(
            darkTheme = uiState.larpPrefs.darkTheme,
            appName = uiState.larpPrefs.currentThemeAppName,
            customIconPath = null,
            onAddCardClick = onAddCardClick,
            onSearchClick = onSearchToggle,
            onMoreOptionsClick = onMoreOptionsClick
        )

        AnimatedVisibility(
            visible = uiState.isSearchVisible,
            enter = slideInVertically(
                initialOffsetY = { -it / 2 },
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            ) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { -it / 2 }) + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp)
            ) {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("Search bank, card, or last 4 digits…") },
                    trailingIcon = {
                        IconButton(onClick = onSearchToggle) {
                            Icon(Icons.Default.Close, contentDescription = "Close search")
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .liquidGlassSurface(
                            shape = RoundedCornerShape(18.dp),
                            darkTheme = uiState.larpPrefs.darkTheme,
                            elevation = 4.dp
                        )
                        .testTag("wallet_search_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = uiState.stackFilter == StackPresetFilter.SCREENSHOT_2_STACK,
                        onClick = { onSetStackFilter(StackPresetFilter.SCREENSHOT_2_STACK) },
                        label = { Text("5-Card Stack") }
                    )
                    FilterChip(
                        selected = uiState.stackFilter == StackPresetFilter.ALL_CARDS,
                        onClick = { onSetStackFilter(StackPresetFilter.ALL_CARDS) },
                        label = { Text("All ${uiState.allCards.size} Cards") }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (stackCards.isNotEmpty()) {
            val peekOffsetDp = if (stackCards.size > 6) 48.dp else 58.dp
            val stackExtraHeight = peekOffsetDp * (stackCards.size - 1).coerceAtLeast(0)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = stackExtraHeight)
                    .testTag("wallet_card_stack_container")
            ) {
                stackCards.forEachIndexed { index, card ->
                    val isFrontCard = index == stackCards.lastIndex
                    val interactionSource = remember { MutableInteractionSource() }
                    val isPressed by interactionSource.collectIsPressedAsState()

                    val targetOffset = if (stackEntered) {
                        peekOffsetDp * index
                    } else {
                        peekOffsetDp * (index * 0.25f)
                    }

                    val animatedTopOffset by animateDpAsState(
                        targetValue = if (isPressed && !isFrontCard) targetOffset - 10.dp else targetOffset,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioLowBouncy,
                            stiffness = Spring.StiffnessLow
                        ),
                        label = "cardTopOffset_$index"
                    )

                    val pressScale by animateFloatAsState(
                        targetValue = if (isPressed) 0.968f else 1f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioLowBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        label = "cardPressScale_$index"
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .offset(y = animatedTopOffset)
                            .zIndex(index.toFloat())
                            .graphicsLayer {
                                scaleX = pressScale
                                scaleY = pressScale
                                rotationX = (deviceTilt.y * 2.2f) + if (isPressed) -2.5f else 0f
                                rotationY = -deviceTilt.x * 2.5f
                                cameraDistance = 16f * density
                            }
                            .combinedClickable(
                                interactionSource = interactionSource,
                                indication = null,
                                onClick = {
                                    onCardChosenFromStack(card)
                                },
                                onLongClick = {
                                    onCardLongPress(card)
                                }
                            )
                            .testTag("stack_card_${card.id}")
                    ) {
                        WalletCardArtwork(
                            card = card,
                            cornerRadius = 18.dp,
                            shadowElevation = if (isFrontCard) 14.dp else 7.dp
                        )
                    }
                }
            }
        } else {
            Spacer(modifier = Modifier.height(48.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .liquidGlassSurface(
                            shape = CircleShape,
                            darkTheme = uiState.larpPrefs.darkTheme,
                            elevation = 8.dp
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CreditCard,
                        contentDescription = null,
                        tint = IosPrimaryBlue,
                        modifier = Modifier.size(38.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "No Cards in Wallet",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Add your card by naming it and putting your own photo from your camera roll or files.",
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(20.dp))

                LiquidGlassButton(
                    onClick = onAddCardClick,
                    darkTheme = uiState.larpPrefs.darkTheme,
                    tintColor = IosPrimaryBlue,
                    modifier = Modifier
                        .fillMaxWidth(0.72f)
                        .height(50.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Add Your Card",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun ApplePayExpressContent(
    uiState: WalletUiState,
    deviceTilt: Offset,
    onBackToStack: () -> Unit,
    onCardInfoClick: (WalletCardEntity) -> Unit,
    onSwapCard: (WalletCardEntity) -> Unit,
    onStartFaceIdVerification: () -> Unit
) {
    val heroCard = uiState.activeHeroCard ?: return
    val otherCards = uiState.allCards.filter { it.id != heroCard.id }

    var touchTiltX by remember { mutableFloatStateOf(0f) }
    var touchTiltY by remember { mutableFloatStateOf(0f) }
    var isHeroPressed by remember { mutableStateOf(false) }

    val animatedTiltX by animateFloatAsState(
        targetValue = touchTiltX + (deviceTilt.y * 4.5f),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "tiltX"
    )
    val animatedTiltY by animateFloatAsState(
        targetValue = touchTiltY - (deviceTilt.x * 5.0f),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "tiltY"
    )
    val heroScale by animateFloatAsState(
        targetValue = if (isHeroPressed) 0.96f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "heroScale"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Sleek Liquid Glass top bar ("Done" pill on left, "•••" circle on right)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp, bottom = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .liquidGlassSurface(
                            shape = RoundedCornerShape(50),
                            darkTheme = uiState.larpPrefs.darkTheme,
                            elevation = 6.dp
                        )
                        .liquidPressable(pressScale = 0.90f, onClick = onBackToStack)
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .testTag("express_done_back_pill"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Done",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .liquidGlassSurface(
                            shape = CircleShape,
                            darkTheme = uiState.larpPrefs.darkTheme,
                            elevation = 6.dp
                        )
                        .liquidPressable(pressScale = 0.88f, onClick = { onCardInfoClick(heroCard) })
                        .testTag("express_card_more_pill"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreHoriz,
                        contentDescription = stringResource(R.string.cd_card_details),
                        tint = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Active Chosen Card at the top with 3D gyroscope + touch spring physics
            AnimatedContent(
                targetState = heroCard,
                transitionSpec = {
                    (fadeIn(tween(220)) +
                        scaleIn(
                            initialScale = 0.88f,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioLowBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            )
                        )) togetherWith
                        (fadeOut(tween(150)) + scaleOut(targetScale = 0.92f))
                },
                label = "heroCardSwapTransition"
            ) { currentHeroCard ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer {
                            scaleX = heroScale
                            scaleY = heroScale
                            rotationX = animatedTiltX
                            rotationY = animatedTiltY
                            cameraDistance = 14f * density
                        }
                        .pointerInput(currentHeroCard.id) {
                            detectTapGestures(
                                onPress = { offset ->
                                    isHeroPressed = true
                                    val nx = (offset.x / size.width - 0.5f) * 2f
                                    val ny = (offset.y / size.height - 0.5f) * 2f
                                    touchTiltY = nx * 7.0f
                                    touchTiltX = -ny * 7.0f
                                    tryAwaitRelease()
                                    isHeroPressed = false
                                    touchTiltX = 0f
                                    touchTiltY = 0f
                                },
                                onTap = {
                                    if (!uiState.isAutoAnimatingPayment) {
                                        onStartFaceIdVerification()
                                    }
                                },
                                onLongPress = {
                                    if (!uiState.isAutoAnimatingPayment) {
                                        onCardInfoClick(currentHeroCard)
                                    }
                                }
                            )
                        }
                        .testTag("express_hero_card")
                ) {
                    WalletCardArtwork(
                        card = currentHeroCard,
                        cornerRadius = 18.dp,
                        shadowElevation = 18.dp
                    )
                }
            }

            // Center Stage: Face ID OR Confirm with Side Button -> 7s NFC Wave -> Done Checkmark
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                ApplePayBiometricStage(
                    stage = uiState.paymentStage,
                    confirmationIconType = uiState.larpPrefs.confirmationIconType,
                    nfcProgress = uiState.nfcProgress,
                    onStageClick = {
                        if (!uiState.isAutoAnimatingPayment) {
                            onStartFaceIdVerification()
                        }
                    },
                    modifier = Modifier.offset(y = (-20).dp)
                )
            }

            Spacer(modifier = Modifier.height(92.dp))
        }

        // Right-Edge "Double Click to Pay" Bar (shown when Side Button confirmation type is selected)
        if (uiState.larpPrefs.confirmationIconType == ConfirmationIconType.SIDE_BUTTON &&
            uiState.paymentStage == PaymentStage.FACE_ID_SCANNING
        ) {
            DoubleClickToPaySideIndicator(
                darkTheme = uiState.larpPrefs.darkTheme,
                onClick = {
                    if (!uiState.isAutoAnimatingPayment) {
                        onStartFaceIdVerification()
                    }
                },
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .offset(y = (-44).dp)
            )
        }

        // Bottom Peeking Card Stack with Liquid Press Bounce (locked during 7s NFC payment)
        BottomPeekingCardStack(
            otherCards = otherCards,
            enabled = !uiState.isAutoAnimatingPayment,
            onSelectPeekingCard = onSwapCard,
            onExpandStack = onBackToStack,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun BottomPeekingCardStack(
    otherCards: List<WalletCardEntity>,
    enabled: Boolean = true,
    onSelectPeekingCard: (WalletCardEntity) -> Unit,
    onExpandStack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val nextCard = otherCards.lastOrNull()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(90.dp)
            .padding(horizontal = 18.dp)
            .liquidPressable(
                enabled = enabled,
                pressScale = 0.96f,
                onClick = {
                    if (nextCard != null) {
                        onSelectPeekingCard(nextCard)
                    } else {
                        onExpandStack()
                    }
                }
            )
            .testTag("bottom_peeking_card_stack"),
        contentAlignment = Alignment.BottomCenter
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            drawRoundRect(
                color = Color(0xFF2B88D8),
                topLeft = Offset(w * 0.015f, 0f),
                size = Size(w * 0.97f, h * 0.55f),
                cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx())
            )

            val greenTopY = 14.dp.toPx()
            val greenPath = Path().apply {
                moveTo(w * 0.008f, greenTopY + 12.dp.toPx())
                quadraticTo(w * 0.008f, greenTopY, w * 0.05f, greenTopY)
                lineTo(w * 0.41f, greenTopY)
                lineTo(w * 0.44f, greenTopY + 10.dp.toPx())
                lineTo(w * 0.56f, greenTopY + 10.dp.toPx())
                lineTo(w * 0.59f, greenTopY)
                lineTo(w * 0.95f, greenTopY)
                quadraticTo(w * 0.992f, greenTopY, w * 0.992f, greenTopY + 12.dp.toPx())
                lineTo(w * 0.992f, h)
                lineTo(w * 0.008f, h)
                close()
            }
            drawPath(path = greenPath, color = Color(0xFF42B849))

            val goldTopY = 27.dp.toPx()
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFFD9BC72),
                        Color(0xFFCFA950),
                        Color(0xFFBF963B)
                    )
                ),
                topLeft = Offset(0f, goldTopY),
                size = Size(w, h - goldTopY),
                cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx())
            )

            val goldHighlight = Path().apply {
                moveTo(w * 0.65f, goldTopY)
                quadraticTo(w * 0.60f, h * 0.65f, w * 0.56f, h)
                lineTo(w, h)
                lineTo(w, goldTopY)
                close()
            }
            drawPath(path = goldHighlight, color = Color(0xFFC29B40).copy(alpha = 0.65f))

            val creamTopY = h - 22.dp.toPx()
            drawRoundRect(
                color = Color(0xFFF3E6BF),
                topLeft = Offset(0f, creamTopY),
                size = Size(w, 22.dp.toPx()),
                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
            )

            val indicatorW = 134.dp.toPx()
            val indicatorH = 5.dp.toPx()
            drawRoundRect(
                color = Color(0xFF141416),
                topLeft = Offset((w - indicatorW) / 2f, h - 11.dp.toPx()),
                size = Size(indicatorW, indicatorH),
                cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
            )
        }
    }
}

/**
 * Upgraded Biometric Lock Screen that adapts to the active ecosystem theme
 * (Apple Pay Lock Screen vs Google Wallet Lock Screen) with custom theme app name,
 * custom theme app icon, locked card preview, and animated biometric scanner.
 */
@Composable
private fun BiometricLockedOverlay(
    isGoogleWallet: Boolean,
    appName: String,
    appIconPath: String?,
    activeCard: WalletCardEntity?,
    darkTheme: Boolean,
    confirmationIconType: ConfirmationIconType,
    onUnlockClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "lockScreenAura")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "lockPulseScale"
    )
    val radarPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "lockRadarPhase"
    )

    val accentColor = if (isGoogleWallet) GoogleBluePrimary else IosPrimaryBlue

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 480.dp)
                .liquidGlassSurface(
                    shape = RoundedCornerShape(32.dp),
                    darkTheme = darkTheme,
                    elevation = 18.dp
                )
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Theme App Icon Badge with Animated Concentric Radar Ring
            Box(
                modifier = Modifier
                    .size(104.dp)
                    .liquidPressable(pressScale = 0.90f, onClick = onUnlockClick),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    for (i in 0..2) {
                        val p = (radarPhase + i * 0.33f) % 1f
                        val r = 28.dp.toPx() + 24.dp.toPx() * p
                        drawCircle(
                            color = accentColor.copy(alpha = (1f - p) * 0.45f),
                            radius = r,
                            center = center,
                            style = Stroke(width = 2.dp.toPx())
                        )
                    }
                }
                Box(
                    modifier = Modifier.graphicsLayer {
                        scaleX = pulseScale
                        scaleY = pulseScale
                    }
                ) {
                    ThemeAppIconBadge(
                        isGoogleWallet = isGoogleWallet,
                        customIconPath = appIconPath,
                        size = 64.dp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = appName,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (isGoogleWallet) {
                    "Verify it's you to unlock your Google Wallet cards & passes"
                } else {
                    "Authenticate with Face ID or Fingerprint to access your cards"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(22.dp))

            // Frosted Locked Card Preview with Shield Overlay
            if (activeCard != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.86f)
                        .liquidPressable(pressScale = 0.95f, onClick = onUnlockClick),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier.graphicsLayer {
                            alpha = 0.38f
                        }
                    ) {
                        WalletCardArtwork(
                            card = activeCard,
                            cornerRadius = 16.dp,
                            shadowElevation = 6.dp,
                            enableLiquidShimmer = false
                        )
                    }

                    // Center Biometric Prompt Badge over the locked card
                    if (isGoogleWallet) {
                        Column(
                            modifier = Modifier
                                .liquidGlassSurface(
                                    shape = RoundedCornerShape(22.dp),
                                    darkTheme = darkTheme,
                                    elevation = 10.dp
                                )
                                .padding(horizontal = 20.dp, vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = "Unlock with Fingerprint",
                                tint = GoogleBrightBlue,
                                modifier = Modifier.size(38.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tap to verify",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (darkTheme) Color(0xFFD3E3FD) else GoogleBluePrimary
                            )
                        }
                    } else {
                        ApplePayBiometricStage(
                            stage = PaymentStage.FACE_ID_SCANNING,
                            confirmationIconType = confirmationIconType,
                            onStageClick = onUnlockClick
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            } else {
                ApplePayBiometricStage(
                    stage = PaymentStage.FACE_ID_SCANNING,
                    confirmationIconType = confirmationIconType,
                    onStageClick = onUnlockClick
                )
                Spacer(modifier = Modifier.height(20.dp))
            }

            LiquidGlassButton(
                onClick = onUnlockClick,
                darkTheme = darkTheme,
                tintColor = accentColor,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("unlock_wallet_button")
            ) {
                Icon(
                    imageVector = Icons.Default.LockOpen,
                    contentDescription = null,
                    tint = Color.White
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Unlock $appName",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
            }
        }
    }
}
